"""Helpers to read instrument workbooks: data validations (incl. x14), option lists."""
import zipfile, re, openpyxl, warnings
from openpyxl.utils import range_boundaries, column_index_from_string, get_column_letter
warnings.filterwarnings('ignore')

class WB:
    def __init__(self, path):
        self.path = path
        self.wb = openpyxl.load_workbook(path)
        self.dv = self._read_dv()
    def _read_dv(self):
        z = zipfile.ZipFile(self.path)
        wbx = z.read('xl/workbook.xml').decode()
        rels = z.read('xl/_rels/workbook.xml.rels').decode()
        rid2t = {}
        for m in re.finditer(r'<Relationship [^>]*>', rels):
            t = m.group(0)
            i = re.search(r'Id="([^"]+)"', t); g = re.search(r'Target="([^"]+)"', t)
            if i and g: rid2t[i.group(1)] = g.group(1)
        out = {}
        for m in re.finditer(r'<sheet [^>]*/>', wbx):
            t = m.group(0)
            name = re.search(r'name="([^"]+)"', t).group(1).replace('&amp;', '&')
            rid = re.search(r'r:id="([^"]+)"', t).group(1)
            p = rid2t[rid].lstrip('/'); p = p if p.startswith('xl/') else 'xl/' + p
            x = z.read(p).decode()
            lst = []
            for dv in re.finditer(r'<x14:dataValidation\b(.*?)</x14:dataValidation>', x, re.S):
                b = dv.group(1); fm = re.search(r'<xm:f>(.*?)</xm:f>', b); sq = re.search(r'<xm:sqref>(.*?)</xm:sqref>', b)
                if fm and sq: lst.append((sq.group(1), fm.group(1)))
            for dv in re.finditer(r'<dataValidation\b([^>]*)>(.*?)</dataValidation>', x, re.S):
                sq = re.search(r'sqref="([^"]+)"', dv.group(1)); fm = re.search(r'<formula1>(.*?)</formula1>', dv.group(2))
                tp = re.search(r'type="([^"]+)"', dv.group(1))
                if sq and fm and (not tp or tp.group(1) == 'list'): lst.append((sq.group(1), fm.group(1)))
            out[name] = lst
        return out
    def options(self, sheet, col, row):
        """Return list options for a cell or None."""
        c = column_index_from_string(col) if isinstance(col, str) else col
        for sq, f in self.dv.get(sheet, []):
            for rng in sq.split():
                c1, r1, c2, r2 = range_boundaries(rng)
                if c1 <= c <= c2 and r1 <= row <= r2:
                    return self.resolve(f)
        return None
    def resolve(self, f):
        f = f.replace('&quot;', '"').replace('&amp;', '&')
        if f.startswith('"'):
            return [s.strip() for s in f.strip('"').split(',')]
        m = re.match(r"'?([^'!]+)'?!\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)", f)
        if not m: return None
        sh, ca, ra, cb, rb = m.groups()
        ws = self.wb[sh]
        vals = []
        for r in range(int(ra), int(rb) + 1):
            for c in range(column_index_from_string(ca), column_index_from_string(cb) + 1):
                v = ws.cell(r, c).value
                if v is not None and str(v).strip() != '': vals.append(str(v))
        return vals
    def cell(self, sheet, ref):
        return self.wb[sheet][ref].value
    def ws(self, s): return self.wb[s]
