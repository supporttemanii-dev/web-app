"""Ambil petunjuk pengisian per butir dari versi cetak (Word) instrumen."""
import sys, re, glob, os, json, docx
def norm(s): return re.sub(r'[^a-z0-9]+', ' ', (s or '').lower()).strip()
def extract(path):
    d = docx.Document(path); out = {}
    for t in d.tables:
        for row in t.rows:
            cells = row.cells
            seen = set()
            for ci, c in enumerate(cells):
                if id(c._tc) in seen: continue
                seen.add(id(c._tc))
                paras = [p.text.strip() for p in c.paragraphs if p.text.strip()]
                if len(paras) >= 2 and len(paras[0]) < 160:
                    guide = ' '.join(p for p in paras[1:] if not re.match(r'^[☐_\s/]+$', p))
                    guide = re.sub(r'\s+', ' ', guide).strip()
                    if guide and not guide.startswith('☐') and '___' not in guide[:10]:
                        key = norm(paras[0])
                        code = cells[0].text.strip().split('\n')[0] if ci > 0 else ''
                        out.setdefault(key, guide)
                        if re.match(r'^[A-Z]\d+[a-z]?$', code): out.setdefault('code:' + code, guide)
    return out
if __name__ == '__main__':
    D = sys.argv[1]; res = {}
    for pat in ['C3_Formulir_Telaah_Catatan_Pelayanan*Cetak*', 'C4_Penilaian_Fasilitas_14CP*Cetak*', 'C5_Verifikasi_Data_Sentinel*Cetak*', 'C6_Formulir_Telaah_Kematian*', 'C6-C_Lembar*']:
        for f in glob.glob(os.path.join(D, '*' + pat + '.docx')):
            g = extract(f); res.update({k: v for k, v in g.items() if k not in res})
            print(os.path.basename(f)[:40], len(g), file=sys.stderr)
    json.dump(res, open(sys.argv[2], 'w'), ensure_ascii=False, indent=0)
