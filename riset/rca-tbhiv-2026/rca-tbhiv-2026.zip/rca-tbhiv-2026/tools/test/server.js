// Local test server: static app + /api backed by the GAS shim.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./gas-shim');
const STATE = process.env.STATE || __dirname + '/state-ui.json';
const fresh = process.argv.includes('--fresh');
if (fresh && fs.existsSync(STATE)) fs.unlinkSync(STATE);
const env = makeEnv(STATE);
if (!env.state.props.SS_MASTER) env.setup();
const ROOT = path.join(__dirname, '..', '..', 'app');
const PORT = Number(process.env.PORT || 8787);
const TYPES = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.xlsx': 'application/octet-stream' };
let offline = false;
http.createServer((req, res) => {
  if (req.url === '/__offline') { offline = true; res.end('off'); return; }
  if (req.url === '/__online') { offline = false; res.end('on'); return; }
  if (req.url.startsWith('/api')) {
    if (offline) { req.destroy(); return; }
    let body = ''; req.on('data', c => body += c); req.on('end', () => {
      let out; try { out = env.call(body); } catch (e) { out = { ok: false, error: 'shim: ' + e.message }; }
      res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(out));
    });
    return;
  }
  let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
  if (p === '/config.js') { res.writeHead(200, { 'Content-Type': 'application/javascript' }); res.end(`window.RCA_CONFIG={API_URL:'http://localhost:${PORT}/api'};`); return; }
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f)) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res);
}).listen(PORT, () => console.log('test server on ' + PORT));
