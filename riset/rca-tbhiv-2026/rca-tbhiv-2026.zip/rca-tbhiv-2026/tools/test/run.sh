#!/bin/bash
cd "$(dirname "$0")"
[ -f srv.pid ] && kill $(cat srv.pid) 2>/dev/null; fuser -k 8787/tcp >/dev/null 2>&1
sleep 0.5
nohup node server.js --fresh > server.log 2>&1 &
echo $! > srv.pid
sleep 2
rm -rf shots
timeout 300 node e2e.js > e2e.log 2>&1
tail -30 e2e.log
