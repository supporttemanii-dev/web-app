// Backend API smoke test against the GAS shim.
const { makeEnv } = require('./gas-shim');
const fs = require('fs');
const F = __dirname + '/state-api.json';
if (fs.existsSync(F)) fs.unlinkSync(F);
const env = makeEnv(F);
env.setup();
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const call = b => env.call(b);

// super admin registration
let r = call({ action: 'register', email: 'anomharjana@unud.ac.id', pin: '123456', name: 'Anom', role: 'Koordinator', code: 'SA1' });
ok(r.ok && r.data.status === 'Aktif', 'super admin sets PIN via register');
r = call({ action: 'login', email: 'anomharjana@unud.ac.id', pin: '123456' });
ok(r.ok && r.data.user.role === 'SuperAdmin', 'super admin login');
const SA = r.data.token;
// bad pin
r = call({ action: 'login', email: 'anomharjana@unud.ac.id', pin: '000000' });
ok(!r.ok && /sisa 4/.test(r.error), 'wrong pin counted');

// enumerator + coordinator
call({ action: 'register', email: 'enum1@x.id', pin: '111111', name: 'Enum Satu', role: 'Enumerator', code: 'FA1' });
call({ action: 'register', email: 'enum2@x.id', pin: '222222', name: 'Enum Dua', role: 'Enumerator', code: 'FA2' });
call({ action: 'register', email: 'koor@x.id', pin: '333333', name: 'Koor', role: 'Koordinator', code: 'K1' });
call({ action: 'register', email: 'baca@x.id', pin: '444444', name: 'Pembaca', role: 'Pembaca' });
r = call({ action: 'login', email: 'enum1@x.id', pin: '111111' });
ok(!r.ok && /menunggu/i.test(r.error), 'pending user cannot login');
['enum1@x.id', 'enum2@x.id', 'koor@x.id', 'baca@x.id'].forEach(e => {
  const x = call({ action: 'users.update', token: SA, email: e, status: 'Aktif' });
  ok(x.ok && x.data.status === 'Aktif', 'approve ' + e + ' as ' + x.data.role);
});
const tok = e => call({ action: 'login', email: e, pin: { 'enum1@x.id': '111111', 'enum2@x.id': '222222', 'koor@x.id': '333333', 'baca@x.id': '444444' }[e] }).data.token;
const E1 = tok('enum1@x.id'), E2 = tok('enum2@x.id'), K = tok('koor@x.id'), P = tok('baca@x.id');
r = call({ action: 'users.list', token: E1 });
ok(!r.ok, 'enumerator cannot list users');

r = call({ action: 'bootstrap', token: E1 });
ok(r.ok && r.data.regions.fac.length === 24, 'bootstrap 24 facilities');

// C2 upload frame A for BLL-RS with 20 rows
const rowsA = [];
for (let i = 1; i <= 20; i++) rowsA.push({ B: 'P' + String(i).padStart(3, '0'), C: 'A' + String(i).padStart(3, '0'), D: i % 2 ? 'L' : 'P', E: 30 + i,
  F: `2025-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 27) + 1).padStart(2, '0')}`, G: i % 5 ? `2025-${String((i % 12) + 1).padStart(2, '0')}-28` : '',
  H: i % 7 ? 'TB SO' : 'TB RO', I: 'Baru', J: i % 3 ? 'Mulai ARV selama pengobatan TB' : 'Belum ARV', K: '', L: i % 4 ? 'Sembuh' : 'Meninggal', N: 'Ekspor SITB' });
r = call({ action: 'c2.upload', token: K, fac: 'BLL-RS', frame: 'A', rows: rowsA });
ok(r.ok && r.data.frames.A.rows.length === 20, 'c2 upload A');
r = call({ action: 'c2.draw', token: K, fac: 'BLL-RS', frame: 'A' });
ok(r.ok, 'c2 draw A ' + (r.error || ''));
const fa = r.data.frames.A;
console.log('   U=', fa.info.U, 'N=', fa.info.N, 'P=', JSON.stringify(fa.info.P));
const sel = fa.rows.filter(x => x.acak);
console.log('   ', sel.map(x => x.c_C + ':' + x.acak).join(', '));
ok(sel.filter(x => x.acak === 'Acak inti').length === 3, '3 acak inti');
// purposive
const purp = fa.rows.filter(x => !x.acak).slice(0, 3);
purp.forEach(x => call({ action: 'c2.update', token: K, id: x.id, fields: { pilihan: 'Purposif inti', alasan: 'P5 Meninggal' } }));
r = call({ action: 'c2.update', token: K, id: fa.rows.find(x => !x.acak && !purp.includes(x)).id, fields: { pilihan: 'Purposif inti' } });
ok(!r.ok, 'purposive requires reason');
// small frame B -> census
r = call({ action: 'c2.upload', token: K, fac: 'BLL-RS', frame: 'B', rows: [1, 2, 3, 4].map(i => ({ B: 'P10' + i, C: 'B00' + i, F: '2025-03-0' + i, G: 'Baru pertama kali ARV' })) });
r = call({ action: 'c2.draw', token: K, fac: 'BLL-RS', frame: 'B' });
ok(r.data.frames.B.rows.every(x => x.acak === 'Sensus'), 'frame B census when <=6');

r = call({ action: 'units.list', token: E1, form: 'C3' });
ok(r.ok && r.data.length === 10, 'C3 units = 6 A + 4 B (got ' + (r.data || []).length + ')');
const u = r.data.find(x => x.sub === 'C3A');

// lock & save
r = call({ action: 'rec.lock', token: E1, form: 'C3', sub: 'C3A', unit: u.unit });
ok(r.ok && r.data.ok, 'enum1 locks');
r = call({ action: 'rec.lock', token: E2, form: 'C3', sub: 'C3A', unit: u.unit });
ok(r.ok && !r.data.ok && r.data.holder.name === 'Enum Satu', 'enum2 blocked by lock');
r = call({ action: 'rec.save', token: E1, form: 'C3', sub: 'C3A', unit: u.unit, baseVersion: 0, data: { U01: u.unit, A01: '2025-03-01', A01__st: 'Y', foo: '-negatif', sumber: [{ kode_sumber: 'RM1' }] }, progress: 30 });
ok(r.ok && r.data.rec.version === 1, 'save draft v1 ' + (r.error || ''));
r = call({ action: 'rec.save', token: E2, form: 'C3', sub: 'C3A', unit: u.unit, baseVersion: 0, data: { U01: u.unit } });
ok(r.ok && r.data.conflict, 'enum2 save -> conflict backup');
r = call({ action: 'heartbeat', token: E1, keys: ['C3|C3A|' + u.unit], active: true });
ok(r.ok && r.data.locks['C3|C3A|' + u.unit] === 'held', 'heartbeat holds lock');
r = call({ action: 'units.list', token: K, form: 'C3' });
ok(r.data.find(x => x.unit === u.unit).lock.name === 'Enum Satu', 'progress shows who works');
r = call({ action: 'rec.save', token: E1, form: 'C3', sub: 'C3A', unit: u.unit, baseVersion: 1, data: { U01: u.unit, A01: '2025-03-01' }, submit: true, progress: 100 });
ok(r.ok && r.data.rec.status === 'Dikirim', 'submit');
r = call({ action: 'rec.save', token: E1, form: 'C3', sub: 'C3A', unit: u.unit, baseVersion: 2, data: {} });
ok(r.ok && r.data.conflict, 'enumerator cannot edit after submit');
r = call({ action: 'rec.review', token: E1, form: 'C3', sub: 'C3A', unit: u.unit, decision: 'validate' });
ok(!r.ok, 'enumerator cannot validate');
r = call({ action: 'rec.review', token: K, form: 'C3', sub: 'C3A', unit: u.unit, decision: 'return', note: 'Cek tanggal A01' });
ok(r.ok && r.data.status === 'Dikembalikan', 'return to enumerator');
r = call({ action: 'heartbeat', token: E1, keys: [] });
ok(r.data.notif.some(n => /Cek tanggal/.test(n.msg)), 'enumerator notified');
r = call({ action: 'rec.get', token: E1, form: 'C3', sub: 'C3A', unit: u.unit });
r = call({ action: 'rec.save', token: E1, form: 'C3', sub: 'C3A', unit: u.unit, baseVersion: r.data.rec.version, data: { U01: u.unit, A01: '2025-03-02' }, submit: true });
ok(r.ok && r.data.rec.status === 'Dikirim', 'resubmit');
r = call({ action: 'rec.review', token: K, form: 'C3', sub: 'C3A', unit: u.unit, decision: 'validate' });
ok(r.ok && r.data.status === 'Valid', 'validate');
r = call({ action: 'analysis.data', token: P, forms: ['C3'] });
ok(r.ok && r.data.C3.C3A.length === 1 && !r.data.C3.C3A[0].data.U01, 'pembaca gets anonymized valid data');
r = call({ action: 'rec.get', token: P, form: 'C3', sub: 'C3A', unit: u.unit });
ok(!r.ok, 'pembaca cannot open record');
r = call({ action: 'export.form', token: E1, form: 'C3' });
ok(!r.ok, 'enumerator cannot export');
r = call({ action: 'export.form', token: K, form: 'C3' });
ok(r.ok && r.data.C3A.length === 1, 'koordinator export');
r = call({ action: 'conflict.list', token: K });
ok(r.ok && r.data.length >= 1, 'conflicts listed');

// C6 calon + blinding
r = call({ action: 'c6.calon.save', token: K, row: { kk: 'BLL', fasyankes: 'BLL-RS', kode_pasien: 'BLL-RS-P008', duplikasi: 'Ya', tb: 'Ya', hiv: 'Ya', mati: 'Ya', tgl_mati: '2025-08-01', dipilih: 'Ya', pen1: 'enum1@x.id', pen2: 'enum2@x.id' } });
ok(r.ok && r.data.some(x => x.kode_kasus === 'C6-BLL-01') && r.data.filter(x => x.kode_pasien === 'BLL-RS-P008').length === 1, 'c6 case created ' + (r.stack || r.error || JSON.stringify(r.data)));
r = call({ action: 'c6.calon.save', token: K, row: { kk: 'BLL', fasyankes: 'BLL-RS', duplikasi: 'Ya', tb: 'Tidak', hiv: 'Ya', mati: 'Ya', tgl_mati: '2025-08-01', dipilih: 'Ya' } });
ok(!r.ok, 'ineligible candidate cannot be selected');
r = call({ action: 'rec.save', token: E1, form: 'C6', sub: 'C6A', unit: 'C6-BLL-01', baseVersion: 0, data: { kecukupan: 'Memadai' } });
r = call({ action: 'rec.save', token: E1, form: 'C6', sub: 'C6B', unit: 'C6-BLL-01', baseVersion: 0, data: { peluang: 'Ya', B1: { T1: { skor: '2' } } } });
ok(r.ok && !r.data.conflict, 'pen1 saves C6B');
r = call({ action: 'rec.get', token: E2, form: 'C6', sub: 'C6B', unit: 'C6-BLL-01' });
ok(!r.ok && /tersamar/.test(r.error), 'pen2 blinded from C6B');
r = call({ action: 'units.list', token: E2, form: 'C6' });
ok(r.ok && r.data.some(x => x.sub === 'C6C') && !r.data.some(x => x.sub === 'C6B'), 'pen2 sees C6C only (second review wajib)');
r = call({ action: 'rec.table', token: E2, form: 'C6', sub: 'C6B' });
ok(r.ok && r.data.C6B.length === 0, 'pen2 table hides C6B');

// C5 sentinel
r = call({ action: 'fac.update', token: SA, code: 'BLL-RS', sentinel: true });
r = call({ action: 'c5.upload', token: K, fac: 'BLL-RS', ind: '5', rows: [{ kode_baris: 'S5-001', tgl_sis: '2025-07-10', tipe_sis: 'Baru', hiv_sis: 'Positif' }, { kode_baris: 'S5-002', tgl_sis: '2025-08-10', tipe_sis: 'Kambuh', hiv_sis: 'Kosong' }] });
ok(r.ok && r.data.added === 2, 'c5 upload rows');
r = call({ action: 'units.list', token: E1, form: 'C5' });
ok(r.ok && r.data.length === 4, 'C5 units for sentinel');

// C1 import
r = call({ action: 'c1.import', token: K, byKK: { BLL: { kedudukan: 'Capaian relatif rendah', dugaan: [{ dugaan: 'ARV terlambat', cp: 'CP6' }] } } });
ok(r.ok && /diperbarui/.test(r.data[0]), 'c1 import');
r = call({ action: 'units.list', token: E1, form: 'C7' });
ok(r.ok && r.data.length === 48 + 12, 'C7 units = 48 sesi + 12 cakupan');
r = call({ action: 'photo.upload', token: E1, form: 'C3', sub: 'C3A', unit: u.unit, b64: Buffer.from('fakejpeg').toString('base64'), confirmNoId: true });
ok(r.ok && r.data.id, 'photo upload');
const pid = r.data.id;
r = call({ action: 'photo.get', token: E1, id: pid });
ok(r.ok && Buffer.from(r.data.b64, 'base64').toString() === 'fakejpeg', 'photo get');
r = call({ action: 'logout', token: E1 });
r = call({ action: 'bootstrap', token: E1 });
ok(!r.ok && r.code === 'AUTH', 'logout invalidates token');
// C2a upload-all: deaths -> C6, sentinel -> C5
call({ action: 'fac.update', token: SA, code: 'BDG-RS', sentinel: true });
const fr = {
  A: [{ B: 'P001', C: 'A001', F: '2025-07-10', G: '2025-07-12', I: 'Baru', J: 'Belum ARV', L: 'Meninggal', M: '2025-08-01', N: 'Ekspor SITB' },
      { B: 'P002', C: 'A002', F: '2025-08-10', G: '2025-08-12', I: 'Kambuh', J: 'Mulai ARV selama pengobatan TB', L: 'Sembuh', N: 'Register TB' }],
  B: [{ B: 'P001', C: 'B001', F: '2025-07-03', G: 'Baru pertama kali ARV', I: 'Ya', K: '2025-08-01', M: 'Meninggal', N: 'Ekspor SIHA' },
      { B: 'P009', C: 'B002', F: '2025-02-03', G: 'Baru pertama kali ARV', M: 'Meninggal', N: 'Ekspor SIHA' }],
  CP3: [{ B: 'P001', C: 'C001', F: '2025-07-10', H: 'Baru', I: 'Positif', K: 'Ekspor SITB' }, { B: 'P003', C: 'C002', F: '2025-09-10', H: 'Baru', I: 'Kosong', K: 'Ekspor SITB' }]
};
r = call({ action: 'c2.uploadAll', token: K, fac: 'BDG-RS', frames: fr });
ok(r.ok && /2 baris/.test(r.data.report.frames.A), 'uploadAll frames ' + (r.stack || JSON.stringify(r.data && r.data.report)));
ok(r.data.report.c6.kematian_terdeteksi === 3 && r.data.report.c6.calon_baru === 2, 'deaths -> 2 calon (P001 merged A+B, P009)');
ok(/2 baris baru/.test(r.data.report.c5['5']) && /2 baris baru/.test(r.data.report.c5['6']) && /1 baris baru/.test(r.data.report.c5['41a']), 'sentinel C5 lists prefilled ' + JSON.stringify(r.data.report.c5));
r = call({ action: 'rec.get', token: K, form: 'C5', sub: 'C5_6', unit: 'BDG-RS' });
const rows6 = r.data.rec.data.cocok;
ok(rows6.find(x => x.kode_baris === 'S6-A002').asal === 'Telusur register', 'register-only row -> telusur register');
r = call({ action: 'c6.calon', token: K });
const auto = r.data.filter(x => /Otomatis/.test(x.asal || '') && x.fasyankes === 'BDG-RS');
ok(auto.length === 2 && auto[0].eligible === 'Tidak', 'auto calon need verification');
r = call({ action: 'c2.uploadAll', token: K, fac: 'BDG-RS', frames: fr });
ok(r.data.report.c6.calon_baru === 0, 'reupload does not duplicate calon');
call({ action: 'c2.draw', token: K, fac: 'BDG-RS', frame: 'A' });
r = call({ action: 'c6.calon', token: K });
ok(r.data.find(x => x.kode_pasien === 'BDG-RS-P001').kode_unit_c3 === 'BDG-RS-A001', 'calon auto-linked to C3 unit after draw');
r = call({ action: 'c2.uploadAll', token: K, fac: 'BDG-RS', frames: fr });
ok(/dilewati/.test(r.data.report.frames.A), 'drawn frame skipped on reupload');

// Regresi: tanggal di batas triwulan (Sheets mengubah teks menjadi Date) dan format HH/BB/TTTT
call({ action: 'fac.update', token: SA, code: 'BLL-PKM', sentinel: true });
const fr2 = {
  A: [{ B: 'Q01', C: 'A01', F: '2025-07-01', G: '2025-07-01', I: 'Baru', L: 'Sembuh', N: 'Register TB' },
      { B: 'Q02', C: 'A02', F: '30/09/2025', G: '30/09/2025', I: 'Baru', L: 'Sembuh', N: 'Register TB' }],
  B: [{ B: 'Q01', C: 'B01', F: '2025-09-30', G: 'Baru pertama kali ARV', I: 'Ya', K: '2025-07-01', M: 'On ART', N: 'Ekspor SIHA' }],
  CP3: [{ B: 'Q03', C: 'C01', F: '2025-07-01', H: 'Baru', I: 'Positif', K: 'Ekspor SITB' }]
};
r = call({ action: 'c2.uploadAll', token: K, fac: 'BLL-PKM', frames: fr2 });
const rc = r.data && r.data.report.c5 || {};
ok(r.ok && rc.rincian && rc.rincian['6'].dalam_triwulan === 2 && rc.rincian['5'].dalam_triwulan === 1 && rc.rincian['41a'].dalam_triwulan === 1, 'boundary & dd/mm dates stay in quarter ' + (r.stack || JSON.stringify(rc)));
r = call({ action: 'c2.get', token: K, fac: 'BLL-PKM', frame: 'A' });
const rowsQ = (JSON.stringify(r.data || {}).split('"frame":"A"').slice(1).join("").match(/"c_(F|G)":"[^"]*"/g) || []).slice(0, 4);
ok(rowsQ.length > 0 && rowsQ.every(x => /"\d{4}-\d\d-\d\d"/.test(x)), 'dates read back as yyyy-mm-dd ' + JSON.stringify(rowsQ).slice(0, 300));
r = call({ action: 'c5.fromC2', token: K, fac: 'BLL-PKM' });
ok(r.ok && r.data && r.data.periode, 'c5.fromC2 returns diagnostics ' + (r.stack || JSON.stringify(r.data)));

console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
process.exit(fails ? 1 : 0);
