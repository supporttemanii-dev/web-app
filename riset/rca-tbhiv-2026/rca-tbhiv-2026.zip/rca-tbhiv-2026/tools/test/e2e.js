// End-to-end UI test with Playwright against the local shim server.
const { chromium } = require('playwright');
const fs = require('fs');
const OUT = process.env.OUT || __dirname + '/shots';
fs.mkdirSync(OUT, { recursive: true });
const BASE = 'http://localhost:8787/';
const errors = [];
let step = 0;
const shot = async (p, name) => { await p.screenshot({ path: `${OUT}/${String(++step).padStart(2, '0')}-${name}.png`, fullPage: false }); };

async function newPage(browser, vp) {
  const ctx = await browser.newContext({ viewport: vp || { width: 1280, height: 860 } });
  const p = await ctx.newPage();
  p.on('pageerror', e => errors.push('pageerror: ' + e.message));
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.g|ERR_|Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
  return p;
}
async function login(p, email, pin) {
  await p.goto(BASE);
  await p.fill('#em', email); await p.fill('#pin', pin);
  await p.click('form button[type=submit]');
  await p.waitForSelector('#sidenav:not([hidden])', { timeout: 10000 });
}
async function register(p, d) {
  await p.goto(BASE);
  await p.click('text=Daftar'); await p.waitForSelector('#pin2');
  await p.fill('#nm', d.name); await p.fill('#em', d.email); await p.fill('#cd', d.code || '');
  await p.selectOption('#rl', d.role); await p.fill('#pin', d.pin); await p.fill('#pin2', d.pin);
  await p.waitForTimeout(150);
  if (await p.inputValue('#em') !== d.email) await p.fill('#em', d.email);
  if (await p.inputValue('#nm') !== d.name) await p.fill('#nm', d.name);
  await p.click('form button[type=submit]');
  await p.waitForSelector('.notice.ok, .notice.err');
  return p.textContent('.notice');
}

(async () => {
  const browser = await chromium.launch();
  const p = await newPage(browser);
  // registrations
  console.log(await register(p, { name: 'Anom Harjana', email: 'anomharjana@unud.ac.id', code: 'SA1', role: 'Koordinator', pin: '123456' }));
  await shot(p, 'register');
  console.log(await register(p, { name: 'Ayu Enumerator', email: 'ayu@x.id', code: 'FA1', role: 'Enumerator', pin: '111111' }));
  console.log(await register(p, { name: 'Budi Koordinator', email: 'budi@x.id', code: 'K1', role: 'Koordinator', pin: '222222' }));
  console.log(await register(p, { name: 'Citra Pembaca', email: 'citra@x.id', role: 'Pembaca', pin: '333333' }));
  // SA approves
  await login(p, 'anomharjana@unud.ac.id', '123456');
  await shot(p, 'home-sa');
  await p.goto(BASE + '#/admin/users'); await p.waitForSelector('table.t');
  await shot(p, 'admin-users');
  for (let i = 0; i < 3; i++) { await p.click('button.btn.ok:has-text("Setujui")'); await p.waitForTimeout(400); }
  // sentinel
  await p.goto(BASE + '#/admin/fac'); await p.waitForSelector('table.t');
  const row = p.locator('tr', { hasText: 'BLL-RS' }).last();
  await row.locator('input[type=checkbox]').check(); await row.locator('button:has-text("Simpan")').click(); await p.waitForTimeout(500);
  await shot(p, 'admin-fac');
  // C2 upload & draw
  await p.goto(BASE + '#/c2'); await p.waitForSelector('select[aria-label=Fasyankes]');
  await p.selectOption('select[aria-label=Fasyankes]', 'BLL-RS'); await p.waitForSelector('text=Unggah berkas C2a');
  {
    const [fc] = await Promise.all([p.waitForEvent('filechooser'), p.click('button:has-text("Unggah berkas C2a")')]);
    await fc.setFiles(__dirname + '/c2a_filled.xlsx');
    await p.waitForSelector('.modal table'); await shot(p, 'c2-upload-preview');
    await p.click('.modal .btn.primary:has-text("Unggah")'); await p.waitForSelector('.modal h2:has-text("Hasil unggah C2a")');
    console.log('upload result:', (await p.locator('.modal .mb').textContent()).replace(/\s+/g, ' ').slice(0, 300));
    await shot(p, 'c2-upload-result'); await p.keyboard.press('Escape');
    await p.click('button:has-text("Jalankan undian A, B, CP3")'); await p.click('.modal .btn.primary'); await p.waitForSelector('.notice.ok');
  }
  await shot(p, 'c2-drawn');
  // purposive for CP3 frame: open first non-selected row
  await p.locator('table.t tbody tr').filter({ hasNotText: 'Acak inti' }).first().click();
  await p.selectOption('.modal select >> nth=0', 'Purposif inti');
  await p.selectOption('.modal select >> nth=1', 'P6 Status HIV tidak diketahui/kosong');
  await p.click('.modal .btn.primary'); await p.waitForTimeout(600);
  // C6 calon
  await p.goto(BASE + '#/c2'); await p.click('.tabs button:has-text("Calon kematian")'); await p.click('button:has-text("+ Tambah calon")');
  const sel = async (label, v) => p.locator('.modal .f', { hasText: label }).locator('select').first().selectOption(v);
  await sel('Kab/kota', 'BLL');
  await p.locator('.modal .f', { hasText: 'Fasyankes' }).locator('input').first().fill('BLL-RS');
  await p.locator('.modal .f', { hasText: 'Kode pasien' }).locator('input').fill('BLL-RS-P008');
  await sel('Duplikasi', 'Ya'); await sel('TB terdokumentasi', 'Ya'); await sel('HIV terdokumentasi', 'Ya'); await sel('Kematian terkonfirmasi', 'Ya');
  await p.locator('.modal .f', { hasText: 'Tanggal kematian' }).locator('input').fill('2025-09-10');
  await sel('Dipilih', 'Ya');
  await sel('Penelaah 1', 'ayu@x.id'); await sel('Penelaah 2', 'budi@x.id');
  await p.click('.modal .btn.primary:has-text("Simpan")'); await p.waitForTimeout(700);
  await shot(p, 'c6-calon');
  // C1 template download + view list
  await p.goto(BASE + '#/form/C1'); await p.waitForSelector('.tile');
  await shot(p, 'c1-list');

  // Enumerator fills C3 unit A on mobile
  const m = await newPage(browser, { width: 390, height: 844 });
  await login(m, 'ayu@x.id', '111111');
  await m.goto(BASE + '#/form/C3'); await m.waitForSelector('.tile');
  await shot(m, 'm-c3-board');
  await m.locator('.tile', { hasText: 'Acak inti' }).first().click();
  await m.waitForSelector('.editor-head');
  await shot(m, 'm-c3-editor');
  const U = m.locator('[data-sec=U]');
  await U.locator('.f', { hasText: 'U08' }).locator('input').fill('25');
  await U.locator('.f', { hasText: 'U09' }).locator('select').selectOption('Dapat ditelaah');
  const Asec = m.locator('[data-sec=A]');
  await Asec.locator('.f', { hasText: 'A01 Tanggal diagnosis TB' }).locator('input[type=date]').fill('2025-03-10');
  await Asec.locator('.f', { hasText: 'A01 Tanggal diagnosis TB' }).locator('select').selectOption('Y');
  await Asec.locator('.f', { hasText: 'A01 Tanggal diagnosis TB' }).locator('input[type=text]').fill('rm1');
  await Asec.locator('.f', { hasText: 'A08 Tanggal mulai OAT' }).locator('input[type=date]').fill('2025-03-14');
  await Asec.locator('.f', { hasText: 'A08 Tanggal mulai OAT' }).locator('select').selectOption('Y');
  await Asec.locator('.f', { hasText: 'A10 Status ARV' }).locator('select').first().selectOption('Belum pernah ARV');
  await Asec.locator('.f', { hasText: 'A11 Tanggal mulai' }).locator('input[type=date]').fill('2025-04-22');
  await Asec.locator('.f', { hasText: 'A11 Tanggal mulai' }).locator('select').selectOption('Y');
  await m.locator('[data-sec=T] .f', { hasText: 'T01' }).locator('select').selectOption('Ya');
  await m.waitForTimeout(700);
  const auto = await m.locator('.f', { hasText: 'Hari mulai OAT → mulai ARV' }).locator('.auto').textContent();
  console.log('auto OAT->ARV:', auto, '| lewat:', await m.locator('.f', { hasText: 'ARV melewati batas juknis' }).locator('.auto').textContent());
  console.log('pemicu:', await m.locator('.f', { hasText: 'Pemicu pendalaman' }).locator('.auto').textContent());
  // rujukan table visible
  await m.locator('[data-sec=rujukan] button:has-text("+ Tambah baris")').click();
  await m.locator('[data-sec=rujukan] .f', { hasText: 'Tanggal rujuk' }).locator('input').fill('2025-04-01');
  await m.locator('[data-sec=Z] .f', { hasText: 'Z05' }).locator('select').selectOption('Lengkap untuk aspek yang dinilai');
  await m.click('.footerbar button:has-text("Simpan")'); await m.waitForSelector('text=Tersinkron ke server');
  await shot(m, 'm-c3-filled');
  // offline behaviour
  await fetch(BASE + '__offline');
  await m.locator('[data-sec=Z] .f', { hasText: 'Z02' }).locator('textarea').fill('Tanggal ARV di SITB 29/04/2025 berbeda dengan ikhtisar');
  await m.click('.footerbar button:has-text("Simpan")'); await m.waitForTimeout(1200);
  await shot(m, 'm-offline');
  console.log('netbar:', await m.locator('#netbar').textContent());
  await fetch(BASE + '__online');
  await m.click('.footerbar button:has-text("Simpan")'); await m.waitForSelector('text=Tersinkron ke server', { timeout: 8000 });
  // submit
  await m.click('.footerbar button:has-text("Kirim ke database")');
  await m.waitForSelector('.modal'); await shot(m, 'm-submit-confirm');
  await m.click('.modal .btn.primary:has-text("Kirim")'); await m.waitForSelector('.tile');
  console.log('after submit url', m.url());

  // coordinator: progress dashboard + validate
  const k = await newPage(browser);
  await login(k, 'budi@x.id', '222222');
  await k.goto(BASE + '#/progress/C3'); await k.waitForSelector('.kpis');
  await shot(k, 'progress');
  await k.locator('.tile[data-st=Dikirim]').first().click(); await k.waitForSelector('.footerbar');
  await k.click('.footerbar button:has-text("Tandai Valid")'); await k.click('.modal .btn.ok'); await k.waitForSelector('.st-Valid');
  await k.goto(BASE + '#/progress/C3'); await k.waitForSelector('.kpis');
  await k.click('button:has-text("Unit A · Episode TB-HIV")'); await k.waitForSelector('.modal table');
  await shot(k, 'data-table'); await k.keyboard.press('Escape');
  await k.goto(BASE + '#/analysis'); await k.waitForSelector('.anl');
  await k.click('.tabs button:has-text("C3")'); await k.waitForSelector('.anl h3');
  await shot(k, 'analysis-c3');
  // C4 editor with matrix
  await k.goto(BASE + '#/edit/C4/C4/BLL-RS'); await k.waitForSelector('[data-sec=matriks_cp]');
  await k.click('button:has-text("Isi n/N dari C3")'); await k.waitForTimeout(300);
  await k.locator('[data-sec=matriks_cp]').scrollIntoViewIfNeeded();
  await shot(k, 'c4-matriks');
  // C5 sentinel table
  await k.goto(BASE + '#/edit/C5/C5_5/BLL-RS'); await k.waitForSelector('.biglist');
  await shot(k, 'c5-cocok');
  // C6 blinding: budi is pen2 -> C6B hidden in list
  await k.goto(BASE + '#/form/C6'); await k.waitForSelector('.board, .notice');
  console.log('budi sees C6 tiles:', await k.locator('.tile .s').allTextContents());
  await k.goto(BASE + '#/edit/C6/C6B/C6-BLL-01'); await k.waitForSelector('.notice.err');
  console.log('C6B for pen2:', await k.locator('.notice.err').textContent());
  // open every sub-form editor to catch render errors
  for (const path of ['C1/C1/BLL', 'C3/C3B/BLL-RS-B001', 'C3/C3CP3/BLL-RS-C' , 'C5/C5ID/BLL-RS', 'C5/C5_6/BLL-RS', 'C5/C5_41a/BLL-RS', 'C6/C6A/C6-BLL-01', 'C6/C6P/C6-BLL-01', 'C7/C7S/BAL-W1', 'C7/C7K/BLL', 'C4/C4/BLL-PKM']) {
    let pth = path;
    if (path.endsWith('BLL-RS-C')) { const u = await (await fetch(BASE + 'api', { method: 'POST', body: JSON.stringify({ action: 'units.list', form: 'C3', token: await k.evaluate(() => RCA.state.token) }) })).json(); pth = 'C3/C3CP3/' + u.data.find(x => x.sub === 'C3CP3').unit; }
    await k.goto(BASE + '#/edit/' + pth); await k.waitForSelector('.footerbar', { timeout: 15000 });
    const n = await k.locator('details.sec').count();
    console.log('editor', pth, 'sections', n);
    if (path === 'C6/C6A/C6-BLL-01' || path === 'C1/C1/BLL' || path === 'C7/C7S/BAL-W1') await shot(k, 'ed-' + path.split('/')[1]);
  }
  // C1 template download
  await k.goto(BASE + '#/form/C1'); await k.waitForSelector('.tile');
  await k.click('button:has-text("Unggah/unduh templat C1")');
  const [dl] = await Promise.all([k.waitForEvent('download'), k.click('.modal .btn.primary:has-text("Unduh templat")')]);
  await dl.saveAs(__dirname + '/c1_template.xlsx'); console.log('c1 template saved');
  // reader
  const r = await newPage(browser);
  await login(r, 'citra@x.id', '333333');
  await shot(r, 'reader-home');
  await r.goto(BASE + '#/analysis'); await r.waitForSelector('.anl');
  // report
  await k.goto(BASE + '#/report'); await k.waitForSelector('.report');
  await shot(k, 'report');
  const [pdf] = await Promise.all([k.waitForEvent('download'), k.click('button:has-text("Simpan PDF")')]);
  await pdf.saveAs(__dirname + '/laporan.pdf');
  const [xl] = await Promise.all([k.waitForEvent('download'), k.click('button:has-text("Simpan Excel")')]);
  await xl.saveAs(__dirname + '/laporan.xlsx'); console.log('report saved');
  await k.goto(BASE + '#/c2/c6'); await k.waitForSelector('table.t');
  console.log('calon rows:', await k.locator('table.t tbody tr').count(), 'auto:', await k.locator('table.t tbody tr', { hasText: 'Otomatis' }).count());
  // tooltip on mobile
  await m.goto(BASE + '#/edit/C3/C3B/BLL-RS-B005'); await m.waitForSelector('[data-sec=B]');
  await m.locator('[data-sec=B] .f', { hasText: 'B08' }).locator('.tipbtn').click();
  await m.locator('[data-sec=B] .f', { hasText: 'B08' }).scrollIntoViewIfNeeded(); await shot(m, 'm-tooltip');
  await m.goto(BASE + '#/edit/C5/C5_6/BLL-RS'); await m.waitForSelector('.indpanel'); await shot(m, 'm-c5-indicator');
  // dark + large font on mobile
  await m.goto(BASE + '#/prefs'); await m.click('text=Gelap'); await m.locator('input[type=range]').fill('1.25');
  await m.goto(BASE + '#/form/C3'); await m.waitForSelector('.tile');
  await shot(m, 'm-dark-large');
  await m.goto(BASE + '#/help'); await shot(m, 'm-help');
  console.log('\nERRORS:', errors.length ? errors.join('\n') : 'none');
  await browser.close();
})().catch(e => { console.error('FAILED', e); console.log('ERRORS:', errors.join('\n')); process.exit(1); });
