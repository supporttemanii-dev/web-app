// Minimal in-memory emulation of the Google Apps Script services used by Code.gs (for local testing only).
const crypto = require('crypto');
const fs = require('fs');
const vm = require('vm');

function makeEnv(stateFile) {
  let state = { ss: {}, props: {}, files: {}, folders: {} };
  if (stateFile && fs.existsSync(stateFile)) state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  const save = () => stateFile && fs.writeFileSync(stateFile, JSON.stringify(state));
  const uuid = () => crypto.randomUUID();

  class Range {
    constructor(sh, r, c, nr, nc) { Object.assign(this, { sh, r, c, nr, nc }); }
    getValues() {
      const out = [];
      for (let i = 0; i < this.nr; i++) {
        const row = []; const src = this.sh.d.data[this.r - 1 + i] || [];
        for (let j = 0; j < this.nc; j++) { const v = src[this.c - 1 + j]; row.push(v === undefined || v === null ? '' : (v && v.__d !== undefined ? new Date(v.__d) : v)); }
        out.push(row);
      }
      return out;
    }
    setValues(vals) {
      for (let i = 0; i < vals.length; i++) {
        const ri = this.r - 1 + i; while (this.sh.d.data.length <= ri) this.sh.d.data.push([]);
        const row = this.sh.d.data[ri];
        for (let j = 0; j < vals[i].length; j++) {
          let v = vals[i][j];
          let m;
          if (typeof v === 'string' && v.startsWith("'")) v = v.slice(1);
          // tiru Google Sheets: teks mirip tanggal diubah menjadi Date (tengah malam zona spreadsheet, +08:00)
          else if (typeof v === 'string' && (m = v.trim().match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) v = { __d: Date.UTC(+m[1], m[2] - 1, +m[3]) - 8 * 3600000 };
          else if (typeof v === 'string' && (m = v.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/))) v = { __d: Date.UTC(+m[3], m[1] - 1, +m[2]) - 8 * 3600000 };
          else if (v instanceof Date) v = { __d: v.getTime() };
          else if (typeof v === 'string' && v.startsWith('=')) throw new Error('Formula parse error: ' + v.slice(0, 30));
          if (typeof v === 'string' && v.length > 50000) throw new Error('Cell exceeds 50000 chars');
          row[this.c - 1 + j] = v;
        }
      }
      this.sh.d.maxCol = Math.max(this.sh.d.maxCol, this.c - 1 + vals[0].length);
      return this;
    }
    setFontWeight() { return this; }
    setNumberFormat() { return this; }
  }
  class Sheet {
    constructor(d, ss) { this.d = d; this.ss = ss; }
    getParent() { return this.ss; }
    getName() { return this.d.name; }
    getLastRow() { let n = this.d.data.length; while (n > 0 && !(this.d.data[n - 1] || []).some(v => v !== '' && v !== undefined && v !== null)) n--; return n; }
    getLastColumn() { let m = 0; this.d.data.forEach(r => { for (let j = r.length - 1; j >= 0; j--) if (r[j] !== '' && r[j] !== undefined && r[j] !== null) { m = Math.max(m, j + 1); break; } }); return m; }
    getMaxColumns() { return Math.max(this.d.maxCol, 26); }
    insertColumnsAfter(a, n) { this.d.maxCol = Math.max(this.d.maxCol, 26) + n; }
    getRange(r, c, nr, nc) { return new Range(this, r, c, nr || 1, nc || 1); }
    getDataRange() { return this.getRange(1, 1, Math.max(this.getLastRow(), 1), Math.max(this.getLastColumn(), 1)); }
    setFrozenRows() {}
    deleteRow(n) { this.d.data.splice(n - 1, 1); }
  }
  class SS {
    constructor(id) { this.id = id; }
    get d() { return state.ss[this.id]; }
    getId() { return this.id; }
    getSheetByName(n) { const s = this.d.sheets.find(x => x.name === n); return s ? new Sheet(s, this) : null; }
    insertSheet(n) { const s = { name: n, data: [], maxCol: 26 }; this.d.sheets.push(s); return new Sheet(s, this); }
    getSheets() { return this.d.sheets.map(s => new Sheet(s, this)); }
    getSpreadsheetTimeZone() { return this.d.tz || 'Asia/Makassar'; }
    setSpreadsheetTimeZone(t) { this.d.tz = t; }
    deleteSheet(sh) { this.d.sheets = this.d.sheets.filter(s => s.name !== sh.getName()); }
    getUrl() { return 'mem://ss/' + this.id; }
  }
  const SpreadsheetApp = {
    create(name) { const id = 'ss_' + uuid().slice(0, 8); state.ss[id] = { name, sheets: [{ name: 'Sheet1', data: [], maxCol: 26 }] }; return new SS(id); },
    openById(id) { if (!state.ss[id]) throw new Error('No ss ' + id); return new SS(id); }
  };
  class File {
    constructor(id) { this.id = id; }
    getId() { return this.id; } getName() { return state.files[this.id].name; }
    moveTo(f) { state.files[this.id] = state.files[this.id] || {}; state.files[this.id].parent = f.getId(); }
    setDescription(d) { state.files[this.id].desc = d; }
    getBlob() { const f = state.files[this.id]; return { getBytes: () => Array.from(Buffer.from(f.b64 || '', 'base64')) }; }
    getMimeType() { return state.files[this.id].mime || 'application/octet-stream'; }
    getParents() { const p = state.files[this.id].parent; return { next: () => new Folder(p) }; }
  }
  class Folder {
    constructor(id) { this.id = id; }
    getId() { return this.id; } getUrl() { return 'mem://folder/' + this.id; }
    createFolder(n) { const id = 'fo_' + uuid().slice(0, 8); state.folders[id] = { name: n, parent: this.id }; return new Folder(id); }
    createFile(blob) { const id = 'fi_' + uuid().slice(0, 8); state.files[id] = { name: blob.name, mime: blob.mime, b64: blob.b64, parent: this.id }; return new File(id); }
  }
  const DriveApp = {
    createFolder(n) { const id = 'fo_' + uuid().slice(0, 8); state.folders[id] = { name: n }; return new Folder(id); },
    getFolderById(id) { return new Folder(id); },
    getFileById(id) { if (!state.files[id]) state.files[id] = {}; return new File(id); }
  };
  const toSigned = buf => Array.from(buf).map(b => (b > 127 ? b - 256 : b));
  const Utilities = {
    getUuid: uuid,
    DigestAlgorithm: { SHA_256: 'sha256', MD5: 'md5' }, Charset: { UTF_8: 'utf8' },
    computeDigest(alg, s) { return toSigned(crypto.createHash(alg).update(String(s), 'utf8').digest()); },
    base64Encode(bytes) { return Buffer.from(bytes.map(b => b & 255)).toString('base64'); },
    base64EncodeWebSafe(bytes) { return Buffer.from(bytes.map(b => b & 255)).toString('base64url'); },
    base64Decode(s) { return toSigned(Buffer.from(s, 'base64')); },
    newBlob(bytes, mime, name) { return { b64: Buffer.from(bytes.map(b => b & 255)).toString('base64'), mime, name }; },
    formatDate(d, tz, f) {
      const x = new Date(new Date(d).getTime() + 8 * 3600000), z = n => String(n).padStart(2, '0');
      const map = { yyyy: x.getUTCFullYear(), MM: z(x.getUTCMonth() + 1), dd: z(x.getUTCDate()), HH: z(x.getUTCHours()), mm: z(x.getUTCMinutes()), ss: z(x.getUTCSeconds()) };
      return String(f || 'yyyy-MM-dd HH:mm').replace(/yyyy|MM|dd|HH|mm|ss/g, k => map[k]);
    }
  };
  const cache = {};
  const ctx = {
    SpreadsheetApp, DriveApp, Utilities,
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => state.props[k] || null, setProperty: (k, v) => { state.props[k] = v; } }) },
    CacheService: { getScriptCache: () => ({ get: k => cache[k] || null, put: (k, v) => { cache[k] = v; }, remove: k => { delete cache[k]; } }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    ContentService: { createTextOutput: s => ({ content: s, setMimeType() { return this; } }), MimeType: { JSON: 'json' } },
    Session: { getScriptTimeZone: () => 'Asia/Makassar' },
    Logger: { log: (...a) => console.log('[GAS]', ...a) },
    console
  };
  vm.createContext(ctx);
  const dir = __dirname + '/../../gas/';
  vm.runInContext('var DEBUG = true;\n' + fs.readFileSync(dir + 'Seed.gs', 'utf8') + '\n' + fs.readFileSync(dir + 'Code.gs', 'utf8'), ctx, { filename: 'Code.gs' });
  return {
    ctx, state, save,
    // fresh per-request caches like a new GAS execution
    call(body) {
      vm.runInContext('_ss = {}; _tbl = {}; _regions = null;', ctx);
      const res = ctx.doPost({ postData: { contents: typeof body === 'string' ? body : JSON.stringify(body) } });
      save();
      return JSON.parse(res.content);
    },
    setup() { vm.runInContext('_ss = {}; _tbl = {}; _regions = null;', ctx); const r = ctx.setup(); save(); return r; }
  };
}
module.exports = { makeEnv };
