"""Generate app/js/schema.js from the RCA TB-HIV instrument workbooks.

Run:  python3 -I gen_schema.py <attachments_dir> <out_js>
The Excel workbooks remain the single source of truth for labels, codes and option lists.
"""
import sys, os, re, json, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from xl import WB
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI

D = sys.argv[1]
OUT = sys.argv[2]
def f(pat):
    hits = sorted(glob.glob(os.path.join(D, '*' + pat + '*.xlsx')))
    if not hits: sys.exit('Berkas instrumen tidak ditemukan: ' + pat)
    return hits[-1]

c3 = WB(f('C3_Formulir_Telaah_Catatan_Pelayanan*Excel'))
c4 = WB(f('C4_Penilaian_Fasilitas_14CP*Excel'))
c5 = WB(f('C5_Verifikasi_Data_Sentinel*Excel'))
c6 = WB(f('C6_Register_Telaah_Kematian'))
c7 = WB(f('C7_Daftar_Sesi_Wawancara_FGD'))
c2a = WB(f('C2a_Templat_Kerangka_Sampel'))
c2b = WB(f('C2b_Daftar_Induk_Sampel'))

def clean(s):
    return re.sub(r'\s+', ' ', str(s or '')).strip()

def slug(s, n=40):
    s = clean(s).lower()
    s = re.sub(r'\(.*?\)', '', s)
    s = re.sub(r'[^a-z0-9]+', '_', s).strip('_')
    return s[:n].strip('_')

NUM_HINT = ('durasi', 'umur', '(menit)', '(tahun)', 'jumlah', 'cd4 awal', 'skor kaskade', 'n kerangka', 'n seluruh', 'u acak', 'interval')
TXT_HINT = ('alasan', 'uraian', 'pertanyaan', 'konteks', 'mekanisme', 'pemeriksaan diagnostik', 'dukungan', 'efek samping',
            'catatan', 'keterangan', 'penjelasan', 'ringkasan', 'masalah', 'praktik', 'dugaan', 'bukti', 'temuan', 'rantai', 'informasi',
            'hambatan', 'refleksi', 'usulan', 'kejadian', 'perspektif', 'kronologi', 'respons', 'peluang', 'faktor penyumbang')

def guess_type(label, opts):
    l = label.lower()
    if opts: return 'select'
    if re.match(r'^(tanggal|tgl)\b', l) and ' dan ' not in l: return 'date'
    if any(h in l for h in NUM_HINT): return 'number'
    if any(h in l for h in TXT_HINT): return 'textarea'
    return 'text'

def fld(k, l, t='text', o=None, **kw):
    d = {'k': k, 'l': clean(l), 't': t}
    if o: d['o'] = o
    d.update({a: b for a, b in kw.items() if b is not None})
    return d

ST_OPTS = ['Y', 'TL', 'TC', 'TBL', 'BD']

# ---------------------------------------------------------------- C3
AUTO_A = {'BY': 'hari_dx_oat', 'BZ': 'hari_oat_arv', 'CA': 'arv_lewat', 'CB': 'hari_dx_teshiv', 'CC': 'kelompok',
          'CD': 'cek_A', 'CE': 'pemicu_A', 'DK': 'cp6', 'DO': 'hari_terduga_dx', 'DT': 'cp6_pnpk'}
AUTO_B = {'BQ': 'hari_arv_skr', 'BR': 'hari_skr_dx', 'BS': 'hari_arv_tpt', 'BT': 'hari_layak_tpt', 'BU': 'kelompok',
          'BV': 'cek_B', 'BW': 'pemicu_B', 'CW': 'tpt_matang', 'CX': 'cp7', 'CY': 'cp2'}
SEC_TITLES_A = {'U': 'U · Identitas dan riwayat HIV', 'A': 'A · Episode TB-HIV (inti)', 'T': 'T · Kesinambungan (inti)',
                'Z': 'Z · Penutupan', 'AUTO': 'Hitungan otomatis dan pemicu', 'P': 'P · Pendalaman (unit purposif atau ada pemicu)',
                'CD4': 'CD4 (bersyarat: ARV >14 hari setelah OAT atau belum dimulai)'}
SEC_TITLES_B = dict(SEC_TITLES_A); SEC_TITLES_B['B'] = 'B · Riwayat ARV dan TPT (inti)'
SEC_TITLES_B['AUTO'] = 'Hitungan otomatis, pemicu, kematangan TPT'
PREFILL = {'U01': 'unit_code', 'U02': 'patient_code', 'U03': 'selection', 'U04': 'reason', 'U05': 'period', 'U06': 'user_code', 'U07': 'today'}
HELP = {
 'U09': 'Akses unit: Dapat ditelaah / Sebagian / Tidak dapat ditelaah. Bila terbatas, isi U10.',
 'Z05': 'Status telaah. TC hanya menjadi insiden pelayanan setelah penelusuran sumber selesai (Lengkap untuk aspek yang dinilai).',
 'Z06': 'Wajib untuk unit purposif dan unit acak yang memunculkan pemicu (lihat kotak Pemicu pendalaman).',
 'A00': 'Tanggal pertama tercatat sebagai terduga TB (register TBC.06/SITB atau permintaan pemeriksaan TB). Tulis BD bila tidak ditemukan.',
 'A11': 'Batas ARV: TB SO 14 hari, TB RO 56 hari setelah OAT (Juknis Kolaborasi TBC-HIV 2023).',
 'U13': 'Bila hanya bulan/tahun diketahui: kosongkan tanggal, St = Y, tulis --/BB/TTTT di Z02. Jangan memakai tanggal entri sistem.',
}

def c3_unit(sheet, autos, titles, frame):
    ws = c3.ws(sheet)
    fields = {}
    order = []
    last = None
    for c in range(1, ws.max_column + 1):
        h = ws.cell(4, c).value
        if h is None: continue
        h = clean(h); col = L(c)
        if col in autos:
            k = 'auto_' + autos[col]
            fields[k] = fld(k, h, 'auto', fn=autos[col]); order.append(('AUTO', k)); continue
        m = re.match(r'^St (\w+)$', h)
        if m and m.group(1) in fields:
            fields[m.group(1)]['st'] = True; continue
        m = re.match(r'^Sumber (\w+)$', h)
        if m and m.group(1) in fields:
            fields[m.group(1)]['src'] = True; continue
        if h.startswith('CD4 awal'):
            k = 'CD4'; fields[k] = fld(k, h, 'number'); order.append(('CD4', k)); continue
        if h == 'Tanggal CD4':
            fields['CD4_tgl'] = fld('CD4_tgl', h, 'date'); order.append(('CD4', 'CD4_tgl')); continue
        if h == 'Status CD4':
            fields['CD4_status'] = fld('CD4_status', h, 'select', c3.options(sheet, col, 6)); order.append(('CD4', 'CD4_status')); continue
        if h == 'Sumber CD4':
            fields['CD4_src'] = fld('CD4_src', h, 'text'); order.append(('CD4', 'CD4_src')); continue
        m = re.match(r'^([A-Z]\d+[a-z]?) (.*)$', h)
        if not m:
            print('skip', sheet, col, h); continue
        code, lab = m.group(1), m.group(2)
        opts = c3.options(sheet, col, 6)
        t = guess_type(lab, opts)
        if code == 'Z04': t, opts = 'multi', ['C4', 'C5/WP3', 'C6', 'C7']
        if code in ('Z07',): t = 'text'
        fx = fld(code, f'{code} {lab}', t, opts)
        if code in PREFILL: fx['pre'] = PREFILL[code]
        if code in HELP: fx['h'] = HELP[code]
        fields[code] = fx
        sec = code[0]
        if code == 'A00': sec = 'A'
        order.append((sec, code))
    # status/source options
    for k, v in fields.items():
        if v.get('st'): v['so'] = ST_OPTS
    # build sections preserving first-appearance order, but put A00 first in A
    secs = []
    seen = {}
    for sec, k in order:
        if sec not in seen:
            seen[sec] = {'type': 'fields', 'id': sec, 'title': titles.get(sec, sec), 'fields': []}
            secs.append(seen[sec])
        seen[sec]['fields'].append(fields[k])
    for s in secs:
        if s['id'] == 'A':
            s['fields'].sort(key=lambda x: 0 if x['k'] == 'A00' else 1)
        if s['id'] == 'P':
            s['collapsed'] = True
            s['note'] = 'Wajib untuk unit purposif dan untuk unit acak yang memunculkan pemicu. Unit acak tanpa pemicu tidak perlu pendalaman.'
        if s['id'] == 'CD4':
            s['collapsed'] = True
    # reorder: U, A/B, T, Z, AUTO, P, CD4
    pri = {'U': 0, 'A': 1, 'B': 1, 'T': 2, 'Z': 3, 'AUTO': 4, 'CD4': 5, 'P': 6}
    secs.sort(key=lambda s: pri.get(s['id'], 9))
    return secs

def c3_table(sheet, key, title, skip_auto=True, when=None, note=None):
    ws = c3.ws(sheet)
    cols = []
    for c in range(2, ws.max_column + 1):
        h = ws.cell(4, c).value
        if h is None: continue
        h = clean(h)
        if '(otomatis)' in h or 'otomatis' in h.lower() or h.startswith('Hari ') or h.startswith('Selesai ≤') or h.startswith('Kembali ≤'):
            continue
        opts = c3.options(sheet, L(c), 6)
        cols.append(fld(slug(h, 24) or 'c%d' % c, h, guess_type(h, opts), opts))
    s = {'type': 'table', 'id': key, 'k': key, 'title': title, 'cols': cols}
    if when: s['when'] = when
    if note: s['note'] = note
    return s

SUMBER = c3_table('Sumber', 'sumber', 'Sumber yang dibuka untuk unit ini',
                  note='Kode sumber: W keterangan petugas; RM rekam medis; TB kartu/register TB; HIV ikhtisar/register HIV; LAB; FAR farmasi; TPT; RUJ rujukan; KOM komunitas; SITB; SIHA; LAIN. Beri nomor bila lebih dari satu (RM1, RM2).')
RUJUKAN = c3_table('Rujukan', 'rujukan', 'Kejadian rujukan (isi bila T01 = Ya)', when={'k': 'T01', 'eq': 'Ya'})
INTERUPSI = c3_table('Interupsi', 'interupsi', 'Kejadian interupsi (isi bila T02 = Ya)', when={'k': 'T02', 'eq': 'Ya'},
                     note='Bila TB dan ARV (atau ARV dan TPT) terputus bersamaan dengan tanggal obat terakhir yang sama, catat satu baris dengan layanan gabungan.')
PHOTOS = {'type': 'photos', 'id': 'foto', 'title': 'Foto pendukung (opsional)',
          'note': 'Foto dikompres otomatis. Potong dan tutup (blur) nama, NIK, nomor RM, alamat, atau wajah sebelum mengunggah.'}

C3A = c3_unit('Unit_A', AUTO_A, SEC_TITLES_A, 'A') + [SUMBER, RUJUKAN, INTERUPSI, PHOTOS]
C3B = c3_unit('Unit_B', AUTO_B, SEC_TITLES_B, 'B') + [SUMBER, RUJUKAN, INTERUPSI, PHOTOS]

def cp3_fields():
    ws = c3.ws('CP3_Register'); out = []
    keys = {}
    for c in range(2, ws.max_column + 1):
        h = ws.cell(4, c).value
        if not h: continue
        h = clean(h); col = L(c)
        if col == 'S': out.append(fld('auto_cp3_mek', h, 'auto', fn='cp3_mek')); continue
        if col == 'T': out.append(fld('auto_hari_dx_tes', h, 'auto', fn='hari_dx_tes')); continue
        opts = c3.options('CP3_Register', col, 6)
        k = 'R_' + col
        t = guess_type(h, opts)
        if 'Tanggal tes atau dokumentasi' in h: t = 'date'
        fx = fld(k, h, t, opts)
        if col == 'B': fx['pre'] = 'unit_code'
        if col == 'C': fx['pre'] = 'selection'
        if col == 'D': fx['pre'] = 'hiv_status'
        if col == 'E': fx['pre'] = 'tb_dx_date'
        if col == 'O': fx['pre'] = 'user_code'
        if col == 'P': fx['pre'] = 'today'
        out.append(fx)
    return out
CP3 = [{'type': 'fields', 'id': 'CP3', 'title': 'Penelusuran status HIV episode TB (tingkat register: kartu/register TB, register lab/KTS, SITB)',
        'note': "Mekanisme: 'Pelayanan' = kesenjangan pada penawaran atau pelaksanaan tes; 'Pencatatan' = tes/status terdokumentasi di sumber tetapi kosong/berbeda di SITB (teruskan ke C5/WP3); 'Belum dapat dipastikan' = bukti tidak cukup.",
        'fields': cp3_fields()}, PHOTOS]

C3_PARAM = {}
ws = c3.ws('Parameter')
for r in range(5, 22):
    a, b = ws.cell(r, 1).value, ws.cell(r, 2).value
    if a and b is not None:
        C3_PARAM[clean(a)] = b.strftime('%Y-%m-%d') if hasattr(b, 'strftime') else b
TPT_MATANG = {}
for r in range(15, 19):
    TPT_MATANG[ws.cell(r, 2).value] = ws.cell(r, 3).value.strftime('%Y-%m-%d')

# ---------------------------------------------------------------- C4
def kv_rows(wb, sheet, r1, r2, valcol='B', prefix='', textarea=False, extra_cols=None):
    ws = wb.ws(sheet); out = []
    for r in range(r1, r2 + 1):
        lab = ws.cell(r, 1).value
        if not lab: continue
        lab = clean(lab)
        opts = wb.options(sheet, valcol, r)
        t = 'select' if opts else ('date' if lab.lower().startswith('tanggal') and ' dan ' not in lab.lower() else ('textarea' if textarea or len(lab) > 60 else 'text'))
        if '(otomatis)' in lab: continue
        out.append(fld(prefix + slug(lab, 30), lab, t, opts))
    return out

def matrix(wb, sheet, hdr, r1, r2, c1, c2, key, title, ro_cols=(), extra=None, note=None):
    ws = wb.ws(sheet)
    cols = []
    for c in range(c1, c2 + 1):
        h = ws.cell(hdr, c).value
        if h is None: continue
        h = clean(h); col = L(c)
        opts = wb.options(sheet, col, r1)
        if col in ro_cols:
            cols.append(fld('ro_' + col, h, 'ro')); continue
        t = guess_type(h, opts)
        if h.lower().startswith('isian') or h.startswith('E1') or h.startswith('E2'): t = 'textarea'
        if 'Kode bukti' in h: t = 'text'
        cols.append(fld(slug(h, 26) or col, h, t, opts))
    rows = []
    for r in range(r1, r2 + 1):
        lab = ws.cell(r, 1).value
        if not lab: continue
        row = {'k': slug(lab, 30), 'l': clean(lab)}
        vals = {}
        for c in range(c1, c2 + 1):
            if L(c) in ro_cols:
                vals['ro_' + L(c)] = clean(ws.cell(r, c).value)
        if vals: row['v'] = vals
        rows.append(row)
    s = {'type': 'matrix', 'id': key, 'k': key, 'title': title, 'rows': rows, 'cols': cols}
    if note: s['note'] = note
    if extra: s.update(extra)
    return s

def table(wb, sheet, hdr, key, title, c1=1, c2=None, skip=(), note=None, maxrows=None, data_row=None, colkeys=None):
    ws = wb.ws(sheet)
    c2 = c2 or ws.max_column
    cols = []
    for c in range(c1, c2 + 1):
        h = ws.cell(hdr, c).value
        if h is None: continue
        h = clean(h); col = L(c)
        if col in skip or '(otomatis)' in h: continue
        opts = wb.options(sheet, col, data_row or hdr + 1)
        k = (colkeys or {}).get(col) or slug(h, 26) or col
        cols.append(fld(k, h, guess_type(h, opts), opts))
    s = {'type': 'table', 'id': key, 'k': key, 'title': title, 'cols': cols}
    if note: s['note'] = note
    if maxrows: s['max'] = maxrows
    return s

C4_ID = kv_rows(c4, 'Identitas', 4, 20)
for x in C4_ID:
    if x['l'].startswith('Kode fasyankes RCA'): x['pre'] = 'facility_code'
    if x['l'].startswith('Kode kab/kota'): x['pre'] = 'kk_code'
    if x['l'].startswith('Fasilitas sentinel'): x['pre'] = 'sentinel_yn'
C4_LAYANAN = matrix(c4, 'Identitas', 23, 24, 38, 2, 5, 'layanan', 'A1 · Layanan yang tersedia (konfirmasi dengan petugas dan dokumen)')
C4_DUGAAN = table(c4, 'Dugaan_C1', 4, 'dugaan', 'A3 · Dugaan dari C1 yang diuji di fasyankes ini', c1=2, maxrows=4,
                  note='Salin dugaan penyebab awal dari C1 (tombol "Ambil dari C1"). Dugaan yang dibantah sama pentingnya dengan yang didukung.', data_row=5)
C4_DUGAAN['prefill'] = 'c1_dugaan'
C4_ALUR = table(c4, 'Alur', 4, 'alur', 'B · Peta alur pelayanan dan pembagian tanggung jawab',
                note='Tiga jalur: (1) pasien TB ke tes HIV dan ARV; (2) ODHIV ke skrining TB, pemeriksaan, dan TPT; (3) rujukan keluar-masuk. Foto sketsa didaftarkan di Daftar bukti.')
C4_DOK = matrix(c4, 'Dokumen_Stok', 4, 5, 14, 2, 5, 'dokumen', 'D1 · SOP dan dokumen')
C4_STOK = matrix(c4, 'Dokumen_Stok', 16, 17, 25, 2, 5, 'stok', 'D2 · Ketersediaan obat dan bahan',
                 note='Kartu stok atau catatan elektronik yang sah. Ingatan petugas dicatat sebagai keterangan belum terverifikasi (W).')
C4_D3 = matrix(c4, 'Diagnostik_Pencatatan', 4, 5, 8, 2, 3, 'd3', 'D3 · Diagnostik dan pengiriman spesimen')
C4_D4 = matrix(c4, 'Diagnostik_Pencatatan', 10, 11, 15, 2, 3, 'd4', 'D4 · Pencatatan dan pelaporan')
C4_D5 = matrix(c4, 'Diagnostik_Pencatatan', 17, 18, 21, 2, 3, 'd5', 'D5 · Privasi, kerahasiaan, dan akses')
C4_OBS = matrix(c4, 'Observasi', 4, 5, 11, 2, 4, 'observasi', 'E · Observasi sesi pelayanan',
                note='Sekurang-kurangnya satu sesi TB dan satu sesi HIV. Kehadiran pengamat dimintakan izin pasien (C8); bila menolak, pakai simulasi.')
C4_WWP = table(c4, 'Wawancara', 4, 'ww_peserta', 'F · Wawancara singkat petugas (2–3 per fasyankes)', maxrows=6, data_row=5)
ws = c4.ws('Wawancara')
C4_WWQ = [clean(ws.cell(r, 1).value) for r in range(9, 17) if ws.cell(r, 1).value]
C4_WWP['note'] = 'Pertanyaan inti: ' + ' '.join(C4_WWQ)
C4_WWK = table(c4, 'Wawancara', 18, 'ww_keterangan', 'F · Ringkasan keterangan petugas per CP', data_row=19)

# Matriks CP
ws = c4.ws('Matriks_CP')
acu = c4.ws('Acuan_CP')
acuan = {}
for r in range(5, 20):
    cp = acu.cell(r, 1).value
    if cp: acuan[cp] = {'q': clean(acu.cell(r, 4).value), 'cek': str(acu.cell(r, 5).value or '').strip(), 'cat': clean(acu.cell(r, 7).value)}
mcols = []
AUTO_M = {'N': 'm_status', 'V': 'm_saran'}
C3N = {'P': 'c3_acak_N', 'Q': 'c3_acak_n', 'R': 'c3_purp_N', 'S': 'c3_purp_n', 'T': 'c3_bd'}
for c in range(2, ws.max_column + 1):
    h = ws.cell(4, c).value
    if not h: continue
    h = clean(h); col = L(c)
    if col in ('B', 'C', 'H', 'J', 'L'):
        mcols.append(fld('ro_' + col, h, 'ro')); continue
    if col in AUTO_M:
        mcols.append(fld('auto_' + AUTO_M[col], h, 'auto', fn=AUTO_M[col])); continue
    if col in C3N:
        mcols.append(fld(C3N[col], h, 'number', c3fill=True)); continue
    opts = c4.options('Matriks_CP', col, 5)
    k = {'D': 'keberlakuan', 'E': 'alasan_keberlakuan', 'F': 'pj', 'G': 'periode', 'I': 'M1', 'K': 'M2', 'M': 'M3', 'O': 'kecukupan',
         'U': 'kode_unit_contoh', 'W': 'klasifikasi', 'X': 'alasan_beda', 'Y': 'masalah', 'Z': 'praktik_baik', 'AA': 'faktor',
         'AB': 'akses_keadilan', 'AC': 'dugaan', 'AD': 'alternatif', 'AE': 'keyakinan', 'AF': 'kode_bukti', 'AG': 'perlu_pendalaman',
         'AH': 'diteruskan'}.get(col, slug(h))
    t = guess_type(h, opts)
    if k == 'faktor': t, opts = 'multi', ['F1 Penyelenggaraan pelayanan', 'F2 Tenaga kesehatan', 'F3 Sistem informasi', 'F4 Diagnostik', 'F5 Obat dan teknologi lain', 'F6 Pembiayaan', 'F7 Kepemimpinan dan tata kelola']
    if k == 'diteruskan': t, opts = 'multi', ['C5', 'C6', 'C7', 'WP3', 'Dinkes', 'WP7']
    if k == 'akses_keadilan': t = 'textarea'
    if k in ('pj', 'periode', 'kode_unit_contoh', 'kode_bukti'): t = 'text'
    mcols.append(fld(k, h, t, opts))
mrows = []
for r in range(5, 20):
    cp = ws.cell(r, 1).value
    if not cp: continue
    v = {}
    for col in ('B', 'C', 'H', 'J', 'L'):
        v['ro_' + col] = clean(ws[col + str(r)].value)
    row = {'k': cp, 'l': cp + ' ' + clean(ws['B' + str(r)].value), 'v': v}
    if cp in acuan: row['info'] = acuan[cp]
    pre = {}
    if ws['D' + str(r)].value: pre['keberlakuan'] = ws['D' + str(r)].value
    for col, k in (('I', 'M1'), ('K', 'M2'), ('M', 'M3')):
        if ws[col + str(r)].value: pre[k] = ws[col + str(r)].value
    if pre: row['pre'] = pre
    mrows.append(row)
C4_MATRIKS = {'type': 'matrix', 'id': 'matriks_cp', 'k': 'matriks_cp', 'title': 'Matriks CP · bukti minimum, status pemeriksaan, dan penilaian',
              'rows': mrows, 'cols': mcols, 'c3fill': True,
              'note': ws['A21'].value and clean(ws['A21'].value)}
C4_PEND = table(c4, 'Pendalaman_CP', 4, 'pendalaman_cp', 'Pendalaman CP (hanya bila "Perlu Pendalaman_CP" = Ya)', data_row=5)
C4_BUKTI = table(c4, 'Daftar_Bukti', 4, 'daftar_bukti', 'Daftar bukti (untuk telaah jarak jauh)', data_row=5,
                 note='Satu baris per bukti. Foto dokumen tidak boleh memuat identitas pasien. Jenis: D dokumen; R register; K unit C3; O observasi; S simulasi; W wawancara; X sumber luar.')
C4_KES = kv_rows(c4, 'Kesimpulan', 5, 16, textarea=True)

C4 = [
  {'type': 'fields', 'id': 'identitas', 'title': 'A · Identitas dan profil fungsi fasilitas', 'fields': C4_ID},
  C4_LAYANAN, C4_DUGAAN, C4_ALUR, C4_DOK, C4_STOK, C4_D3, C4_D4, C4_D5, C4_OBS, C4_WWP, C4_WWK, C4_MATRIKS, C4_PEND, C4_BUKTI,
  {'type': 'fields', 'id': 'kesimpulan', 'title': 'J · Kesimpulan fasyankes, tindak lanjut, dan pemeriksaan mutu', 'fields': C4_KES},
  PHOTOS]

# ---------------------------------------------------------------- C5
C5_ID = kv_rows(c5, 'Identitas', 4, 28)
for x in C5_ID:
    if x['l'] == 'Kode fasyankes RCA': x['pre'] = 'facility_code'
    if x['l'].startswith('Provinsi'): x['pre'] = 'region_text'
C5_JEJAK = kv_rows(c5, 'Identitas', 30, 34) + kv_rows(c5, 'Identitas', 37, 39)
INDS = [('5', 'TB/HIV-5'), ('6', 'TB/HIV-6'), ('41a', 'TB/HIV-4.1a')]
C5_MET = []
for code, name in INDS:
    C5_MET += [
      fld(f'met_{code}', f'{name}: Metode ditetapkan', 'select', ['Sensus', 'Satu bulan', 'Sampel'],
          h='Sensus bila daftar sistem ≤40; bila lebih, undi satu dari tiga bulan; bila bulan itu masih >40, gunakan sampel (target 30 per arah).'),
      fld(f'bulan_{code}', f'{name}: Nomor bulan hasil undian (1/2/3 dari awal triwulan)', 'select', ['1', '2', '3']),
      fld(f'u1_{code}', f'{name}: U acak arah 1 (0 ≤ U < 1; bekukan angka)', 'number'),
      fld(f'model_{code}', f'{name}: Model ditetapkan (A / B / C / BD)', 'select', ['A', 'B', 'C', 'BD'],
          h='A: sumber independen lengkap untuk periode efektif. B: jejak sebagian. C: hanya penjelasan petugas. BD: belum dapat dipastikan.'),
      fld(f'jejak_{code}', f'{name}: Jejak independen indikator/periode', 'select', ['Lengkap', 'Sebagian', 'Tidak ada', 'BD']),
      fld(f'buktimodel_{code}', f'{name}: Kode bukti penetapan model dan cakupan sumber', 'text'),
      fld(f'kerangka2_{code}', f'{name}: Kode kerangka sumber arah 2 dan cakupannya', 'text'),
      fld(f'n2_{code}', f'{name}: N seluruh entri kerangka sumber arah 2', 'number'),
      fld(f'u2_{code}', f'{name}: U acak arah 2 (0 ≤ U < 1; bekukan angka)', 'number'),
      fld(f'lap_num_{code}', f'{name}: Pembilang dilaporkan (rekap resmi periode efektif)', 'number'),
      fld(f'lap_den_{code}', f'{name}: Penyebut dilaporkan (rekap resmi periode efektif)', 'number'),
    ]
C5_PARAM = [
  fld('tw_awal', 'Awal triwulan verifikasi', 'date', h='Pilihan awal triwulan III 2025 (1 Juli–30 September 2025). Ubah bila triwulan lain dipilih dan catat alasannya.'),
  fld('tw_akhir', 'Akhir triwulan verifikasi', 'date'),
  fld('tpt_akhir', 'Akhir jendela mulai TPT untuk pembilang TB/HIV-4.1a', 'date'),
]
C5_ALUR = table(c5, 'Alur_Pencatatan', 4, 'alur_pencatatan', 'Alur pencatatan dari sumber ke SITB/SIHA dan rekap kab/kota', data_row=5)
C5_ALUR['cols'][0]['t'] = 'select'; C5_ALUR['cols'][0]['o'] = ['TB/HIV-5', 'TB/HIV-6', 'TB/HIV-4.1a']
ws = c5.ws('Sistem_Data')
C5_SIS = {'type': 'matrix', 'id': 'sistem_data', 'k': 'sistem_data', 'title': 'Penilaian sistem pengelolaan data',
          'rows': [{'k': 'q%d' % r, 'l': clean(ws.cell(r, 1).value) + ' · ' + clean(ws.cell(r, 2).value)} for r in range(5, 18)],
          'cols': [fld('nilai', 'Penilaian', 'select', ['Ya', 'Sebagian', 'Tidak', 'BD']), fld('bukti', 'Bukti (kode)', 'text'), fld('ket', 'Keterangan', 'textarea')],
          'note': 'Ya / Sebagian / Tidak / BD dengan bukti. Keterangan petugas tanpa dokumen dicatat sebagai W.'}
C5_TL = table(c5, 'Tindak_Lanjut', 4, 'tindak_lanjut', 'Pertanyaan tindak lanjut berkode (sampai 30 November 2026)', data_row=5)
C5ID = [
  {'type': 'fields', 'id': 'identitas', 'title': 'Identitas sentinel, akses, dan cakupan verifikasi', 'fields': C5_ID},
  {'type': 'fields', 'id': 'parameter', 'title': 'Parameter periode', 'fields': C5_PARAM},
  {'type': 'fields', 'id': 'jejak', 'title': 'C · Pemeriksaan awal ketersediaan jejak', 'fields': C5_JEJAK},
  {'type': 'fields', 'id': 'metode', 'title': 'D–E · Metode, periode efektif, dan model bukti per indikator', 'fields': C5_MET},
  C5_ALUR, C5_SIS, C5_TL, PHOTOS]

def c5_cocok(sheet, code, name, keys, note):
    ws = c5.ws(sheet); cols = []
    for c in range(2, ws.max_column + 1):
        h = ws.cell(4, c).value
        if not h: continue
        h = clean(h); col = L(c)
        if col not in keys: continue
        k = keys[col]
        if k.startswith('auto_'):
            cols.append(fld(k, h, 'auto', fn='c5_' + k[5:])); continue
        opts = c5.options(sheet, col, 6)
        t = guess_type(h, opts)
        if ': sistem' in h or ': sumber' in h:
            t = 'date' if h.lower().startswith('tanggal') else t
        if k in ('kode_baris', 'kode_unit_c3', 'kode_pasien', 'kode_sumber', 'bukti', 'tl_kode', 'kode_jejak'): t = 'text'
        if k == 'no_urut2': t = 'number'
        cols.append(fld(k, h, t, opts))
    return {'type': 'table', 'id': 'cocok', 'k': 'cocok', 'title': f'Lembar pencocokan {name}', 'cols': cols, 'big': True,
            'note': note, 'summary': ['kode_baris', 'asal', 'auto_status']}

K5 = {'B': 'kode_baris', 'C': 'kode_unit_c3', 'D': 'kode_pasien', 'E': 'asal', 'F': 'ada_sistem', 'G': 'sumber_diperiksa', 'H': 'ada_sumber',
      'I': 'kode_sumber', 'J': 'tgl_sis', 'K': 'tgl_src', 'L': 'tipe_sis', 'M': 'tipe_src', 'N': 'hiv_sis', 'O': 'hiv_src',
      'P': 'auto_D_sis', 'Q': 'auto_D_src', 'R': 'auto_N_sis', 'S': 'auto_N_src', 'T': 'auto_status', 'U': 'jenis', 'V': 'tgl_entri',
      'W': 'penjelasan', 'X': 'bukti', 'Y': 'konfirmasi', 'Z': 'tl_kode', 'AA': 'selesai', 'AB': 'jejak', 'AC': 'hasil_jejak', 'AD': 'artefak',
      'AG': 'no_urut2', 'AI': 'kode_jejak', 'AJ': 'butir_jejak', 'AF': 'auto_terpilih', 'AN': 'auto_lengkap'}
K6 = {'B': 'kode_baris', 'C': 'kode_unit_c3', 'D': 'kode_pasien', 'E': 'asal', 'F': 'ada_sistem', 'G': 'sumber_diperiksa', 'H': 'ada_sumber',
      'I': 'kode_sumber', 'J': 'tgl_sis', 'K': 'tgl_src', 'L': 'tipe_sis', 'M': 'tipe_src', 'N': 'hiv_sis', 'O': 'hiv_src', 'P': 'arv_sis', 'Q': 'arv_src',
      'R': 'auto_D_sis', 'S': 'auto_D_src', 'T': 'auto_N_sis', 'U': 'auto_N_src', 'V': 'auto_status', 'W': 'jenis', 'X': 'tgl_entri',
      'Y': 'penjelasan', 'Z': 'bukti', 'AA': 'konfirmasi', 'AB': 'tl_kode', 'AC': 'selesai', 'AD': 'jejak', 'AE': 'hasil_jejak', 'AF': 'artefak',
      'AI': 'no_urut2', 'AK': 'kode_jejak', 'AL': 'butir_jejak', 'AH': 'auto_terpilih', 'AP': 'auto_lengkap'}
K41 = {'B': 'kode_baris', 'C': 'kode_unit_c3', 'D': 'kode_pasien', 'E': 'asal', 'F': 'ada_sistem', 'G': 'sumber_diperiksa', 'H': 'ada_sumber',
       'I': 'kode_sumber', 'J': 'tgl_sis', 'K': 'tgl_src', 'L': 'masuk_sis', 'M': 'masuk_src', 'N': 'tpt_sis', 'O': 'tpt_src',
       'P': 'auto_D_sis', 'Q': 'auto_D_src', 'R': 'auto_N_sis', 'S': 'auto_N_src', 'T': 'auto_status', 'U': 'jenis', 'V': 'tgl_entri',
       'W': 'penjelasan', 'X': 'bukti', 'Y': 'konfirmasi', 'Z': 'tl_kode', 'AA': 'selesai', 'AB': 'jejak', 'AC': 'hasil_jejak', 'AD': 'artefak',
       'AG': 'no_urut2', 'AI': 'kode_jejak', 'AJ': 'butir_jejak', 'AF': 'auto_terpilih', 'AN': 'auto_lengkap'}
c5n = lambda s: clean(c5.ws(s)['A2'].value)
C5_5 = [c5_cocok('Cocok_TBHIV5', '5', 'TB/HIV-5: status HIV pada episode TB baru dan kambuh', K5, c5n('Cocok_TBHIV5')), PHOTOS]
C5_6 = [c5_cocok('Cocok_TBHIV6', '6', 'TB/HIV-6: ARV pada episode TB-HIV baru dan kambuh', K6, c5n('Cocok_TBHIV6')), PHOTOS]
C5_41 = [c5_cocok('Cocok_TBHIV4.1a', '41a', 'TB/HIV-4.1a: inisiasi TPT pada peserta baru ARV', K41, c5n('Cocok_TBHIV4.1a')), PHOTOS]
C5_PARAMS = {}
ws = c5.ws('Parameter')
for r in range(5, 13):
    a, b = ws.cell(r, 1).value, ws.cell(r, 2).value
    if a: C5_PARAMS[clean(a)] = b.strftime('%Y-%m-%d') if hasattr(b, 'strftime') else b

# ---------------------------------------------------------------- C6
P6 = lambda col: c6.resolve(f"Pilihan!${col}$2:${col}$13")
SKOR = ['1', '2', '3', '4', '5', 'BD']
FASE = [('T1', 'T1 Akses dan diagnosis', 'Gejala dan kontak awal, pemeriksaan, penyampaian hasil, keputusan diagnosis TB dan HIV'),
        ('T2', 'T2 Awal terapi', 'Mulai OAT dan ARV, paduan dan dosis, kotrimoksazol, penundaan dan alasannya'),
        ('T3', 'T3 Pemantauan', 'Pemantauan klinis dan laboratorium TB dan HIV, tindak lanjut hasil, kepatuhan, interupsi'),
        ('T4', 'T4 Rujukan', 'Keputusan rujukan, penyelesaian, umpan balik'),
        ('T5', 'T5 Penanganan saat kondisi memburuk', 'Pengenalan tanda bahaya, eskalasi, tata laksana menjelang kematian')]
DELAY = [('d1', '1 Mencari pelayanan (dari gejala ke kontak pertama)'), ('d2', '2 Mencapai layanan yang tepat (rujukan, akses, biaya, jarak)'), ('d3', '3 Memperoleh tata laksana memadai di fasyankes')]
def skor_matrix(key, title):
    return {'type': 'matrix', 'id': key, 'k': key, 'title': title,
            'rows': [{'k': k, 'l': l, 'v': {'ro_cak': c}} for k, l, c in FASE],
            'cols': [fld('ro_cak', 'Cakupan', 'ro'), fld('skor', 'Skor 1–5 / BD', 'select', SKOR, req=True), fld('alasan', 'Alasan penilaian (wajib) dan bukti (tanggal, kode sumber)', 'textarea', req=True)],
            'note': 'Skala: 1 sangat buruk; 2 buruk; 3 memadai; 4 baik; 5 sangat baik; BD tidak dapat dinilai. Nilai keputusan berdasarkan informasi yang tersedia bagi petugas saat itu dan pedoman yang berlaku pada periode pelayanan.'}
def delay_matrix(key, title):
    return {'type': 'matrix', 'id': key, 'k': key, 'title': title, 'rows': [{'k': k, 'l': l} for k, l in DELAY],
            'cols': [fld('nilai', 'Penilaian', 'select', ['Ada', 'Tidak', 'BD']), fld('bukti', 'Bukti dan perkiraan lama', 'textarea')]}
KOMP = ['IRIS / sindrom pulih imun', 'Toksisitas / efek samping obat', 'Interaksi obat', 'Kegagalan terapi TB', 'Kegagalan virologis', 'Infeksi oportunistik lain / progresi penyakit']
SUMBER_DAFTAR = ['Laporan program', 'Register TB/HIV', 'Register kematian RS', 'Rawat inap/ringkasan pulang', 'Rujukan', 'SITB/SIHA']
def st(k, l, t='text', o=None, **kw):
    x = fld(k, l, t, o, **kw); x['st'] = True; x['src'] = True; x['so'] = ST_OPTS; return x
C6A = [
  {'type': 'fields', 'id': 'reg', 'title': 'Data kasus (register C6)', 'fields': [
     fld('kode_kasus', 'Kode kasus C6', 'text', pre='unit_code'),
     fld('kode_unit_c3', 'Kode unit C3 bila sama', 'text', pre='c3_link', h='Bila kasus juga ditelaah di C3, fakta C3 dipakai kembali; jumlah pasien tidak digandakan.'),
     fld('kode_pasien', 'Kode pasien (kode fasyankes + kode penghubung, contoh BLL-RS-P008)', 'text', pre='patient_code'),
     fld('fasyankes', 'Fasyankes (kode)', 'text', pre='facility_code'),
     fld('pengambil', 'Pengambil data (kode)', 'text', pre='user_code'),
     fld('tgl_ambil', 'Tanggal pengambilan data', 'date', pre='today'),
     fld('durasi', 'Durasi (menit)', 'number')]},
  {'type': 'fields', 'id': 'A1', 'title': 'A1 · Kelayakan dan identitas kasus (tanpa pengenal langsung)', 'fields': [
     fld('sumber_daftar', 'Sumber daftar calon', 'multi', SUMBER_DAFTAR),
     fld('reg_rs_belum', 'Ditemukan dari register kematian RS dan belum dinotifikasi', 'select', ['Ya', 'Tidak']),
     fld('duplikasi', 'Duplikasi diperiksa', 'select', ['Ya', 'Tidak']), fld('duplikat_dari', 'Duplikat dari (kode calon)', 'text'),
     fld('dok_tb', 'Dokumentasi TB', 'select', ['Ya', 'Tidak']), fld('dok_hiv', 'Dokumentasi HIV', 'select', ['Ya', 'Tidak']), fld('dok_sumber', 'Sumber dokumentasi TB/HIV', 'text'),
     fld('mati_konf', 'Status kematian terkonfirmasi', 'select', ['Ya', 'Tidak']), fld('tgl_mati', 'Tanggal kematian', 'date'), fld('mati_sumber', 'Sumber konfirmasi kematian', 'text'),
     fld('periode', 'Periode', 'select', ['Januari 2025–Juni 2026', 'Perluasan 2024']),
     fld('umur', 'Umur saat kematian (tahun)', 'number'), fld('jk', 'Jenis kelamin', 'select', ['L', 'P'])]},
  {'type': 'table', 'id': 'A2', 'k': 'A2', 'title': 'A2 · Sumber dokumen yang diperiksa', 'cols': [
     fld('kode', 'Kode sumber', 'text'), fld('jenis', 'Jenis (RM jalan/inap, register TB/HIV, lab, farmasi, rujukan, ringkasan pulang, dokumen kematian)', 'text'),
     fld('fas', 'Fasilitas (kode)', 'text'), fld('rentang', 'Rentang tanggal', 'text'), fld('akses', 'Akses', 'select', ['Lengkap', 'Sebagian', 'Belum'])]},
  {'type': 'fields', 'id': 'A3', 'title': 'A3 · Data kunci (isi yang tercatat; beri kode sumber dan status)', 'fields': [
     st('gejala_tgl', 'Tanggal gejala pertama', 'date'), st('kontak_tgl', 'Tanggal kontak pertama terkait TB', 'date'), fld('kontak_fas', 'Fasilitas kontak pertama', 'text'),
     st('dx_tb_tgl', 'Tanggal diagnosis TB', 'date'),
     fld('dx_tb_dasar', 'Dasar diagnosis TB', 'select', ['Bakteriologis', 'Klinis']), fld('dx_tb_lokasi', 'Lokasi TB', 'multi', ['Paru', 'Ekstraparu', 'Meningitis/SSP']),
     fld('dx_tb_res', 'Resistansi', 'select', ['SO', 'RO']), fld('dx_tb_tipe', 'Tipe pasien', 'select', ['Baru', 'Kambuh', 'Lain']),
     st('dx_hiv_tgl', 'Tanggal diagnosis HIV', 'date'), fld('dx_hiv_waktu', 'Diagnosis HIV', 'select', ['Sebelum episode TB', 'Selama episode']),
     fld('ranap', 'Rawat inap saat awal', 'select', ['Ya', 'Tidak']), fld('stadium', 'Stadium klinis', 'text'), fld('cd4', 'CD4 (sel/µL)', 'number'), fld('cd4_tgl', 'Tanggal CD4', 'date'),
     fld('io_lain', 'IO lain', 'text'), fld('gizi', 'Status gizi/IMT', 'text'), fld('komorbid', 'Komorbid', 'text'),
     st('oat_tgl', 'Tanggal mulai OAT', 'date', h="Tulis 'Tidak dimulai' di catatan hanya bila terdokumentasi belum pernah OAT."),
     fld('oat_tidak', 'OAT tidak pernah dimulai (terdokumentasi)', 'select', ['Ya', 'Tidak']), fld('oat_paduan', 'Paduan OAT', 'text'), fld('oat_perubahan', 'Perubahan/interupsi OAT', 'textarea'),
     st('arv_status', 'Status ARV saat TB', 'select', ['Sedang ARV', 'Pernah ARV, terputus', 'Belum pernah ARV', 'Belum pasti']),
     st('arv_tgl', 'Tanggal mulai/ulang ARV', 'date'), fld('arv_paduan', 'Paduan ARV', 'text'),
     fld('ppk', 'Kotrimoksazol (PPK)', 'select', ['Ya', 'Tidak']), fld('ppk_tgl', 'Tanggal PPK', 'date'), fld('vl', 'Viral load', 'text'), fld('vl_tgl', 'Tanggal VL', 'date'),
     fld('komplikasi', 'Komplikasi tercatat di rekam medis', 'multi', ['IRIS', 'ESO/toksisitas', 'Interaksi obat', 'Kegagalan terapi TB', 'Kegagalan virologis', 'Lainnya']),
     fld('komplikasi_lain', 'Komplikasi lainnya', 'text'),
     fld('rujukan', 'Rujukan dan kehadiran di tujuan', 'textarea'), fld('interupsi', 'Interupsi, kepatuhan, penelusuran', 'textarea'),
     st('bahaya_tgl', 'Tanggal tanda bahaya pertama', 'date'), fld('bahaya_respons', 'Respons terhadap perburukan', 'textarea'),
     fld('mati_tempat', 'Tempat kematian', 'select', ['RS', 'Fasyankes lain', 'Rumah', 'TC']), fld('mati_sebab', 'Sebab kematian tercatat', 'text'),
     fld('auto_kategori', 'Kategori waktu kematian (otomatis)', 'auto', fn='c6_kategori'),
     fld('auto_oat_arv', 'Hari OAT → ARV (otomatis)', 'auto', fn='c6_oat_arv')]},
  {'type': 'table', 'id': 'kronologi', 'k': 'kronologi', 'title': 'A4 · Kronologi bertanggal',
   'note': 'Satu baris per kejadian, sejak gejala atau kontak awal sampai kematian. Tahap: AD akses dan diagnosis; AT awal terapi; PM pemantauan; RJ rujukan; PB perburukan. Keterangan petugas diberi sumber W.',
   'cols': [fld('tgl', 'Tanggal', 'date'), fld('fas', 'Fasilitas (kode)', 'text'), fld('tahap', 'Tahap', 'select', ['AD', 'AT', 'PM', 'RJ', 'PB']),
            fld('kejadian', 'Kejadian, temuan klinis, pemeriksaan, keputusan, terapi', 'textarea'), fld('sumber', 'Sumber', 'text'),
            fld('status', 'Status', 'select', ST_OPTS), fld('catatan', 'Catatan pengambil data', 'textarea')]},
  {'type': 'table', 'id': 'A5', 'k': 'A5', 'title': 'A5 · Bagian yang tidak tersedia dan klarifikasi petugas', 'cols': [
     fld('info', 'Informasi yang tidak ditemukan (dan sumber yang sudah diperiksa)', 'textarea'),
     fld('w', 'Keterangan petugas (W): siapa, tanggal, isi ringkas', 'textarea'), fld('dampak', 'Dampak terhadap penilaian', 'textarea')]},
  {'type': 'fields', 'id': 'A6', 'title': 'A6 · Pemeriksaan kecukupan oleh penelaah klinis', 'fields': [
     fld('kecukupan', 'Kecukupan kronologi', 'select', ['Memadai', 'Terbatas', 'Tidak memadai'], h='Tidak memadai: kasus dicatat sebagai keterbatasan, tidak dinilai.'),
     fld('fase_terbatas', 'Fase yang tidak dapat dinilai (bila terbatas)', 'text'),
     fld('salinan', 'Salinan tanpa pengenal untuk penilaian kedua: kode berkas, oleh, tanggal', 'text'),
     fld('penelaah_cek', 'Penelaah klinis (kode), tanggal', 'text')]},
  PHOTOS]
B4_COLS = [fld('masalah', 'Masalah klinis atau pelayanan', 'textarea'), fld('fase', 'Fase', 'select', [x[1] for x in FASE]),
           fld('respons', 'Respons pelayanan', 'textarea'), fld('penyumbang', 'Faktor penyumbang', 'textarea'),
           fld('faktor', 'Faktor sistem (F1–F7)', 'multi', P6('Q')),
           fld('klas', 'Klasifikasi', 'select', P6('N')), fld('bukti', 'Bukti dan penjelasan alternatif', 'textarea'),
           fld('peluang', 'Peluang perbaikan dan pihak yang dapat menindaklanjuti', 'textarea'), fld('pihak', 'Pihak', 'select', P6('S')),
           fld('keyakinan', 'Keyakinan', 'select', ['Tinggi', 'Sedang', 'Rendah'])]
C6B = [
  {'type': 'fields', 'id': 'hdr', 'title': 'Penelaah 1', 'fields': [fld('penelaah1', 'Penelaah 1 (kode)', 'text', pre='user_code'), fld('tgl', 'Tanggal', 'date', pre='today'), fld('durasi', 'Durasi penilaian (menit)', 'number')]},
  skor_matrix('B1', 'B1 · Skor mutu pelayanan per fase'),
  delay_matrix('B2', 'B2 · Tiga keterlambatan'),
  {'type': 'matrix', 'id': 'B3', 'k': 'B3', 'title': 'B3 · Komplikasi: diagnosis tercatat dibedakan dari interpretasi penelaah',
   'rows': [{'k': slug(x, 20), 'l': x} for x in KOMP],
   'cols': [fld('rm', 'Tercatat di RM', 'select', ['Ya', 'Tidak']), fld('interp', 'Interpretasi penelaah', 'select', ['Mungkin', 'Tidak mungkin', 'BD']),
            fld('bukti', 'Bukti: hubungan waktu, obat, temuan, respons; penjelasan lain', 'textarea')]},
  {'type': 'table', 'id': 'B4', 'k': 'B4', 'title': 'B4 · Masalah, faktor penyumbang, dan peluang perbaikan', 'cols': B4_COLS,
   'note': 'Klasifikasi faktor penyumbang (V13 Bagian 11): Terverifikasi; Mungkin berperan; Belum cukup bukti; Bukti bertentangan. Faktor sistem sama dengan C4.'},
  {'type': 'fields', 'id': 'B5', 'title': 'B5 · Sebab kematian dan kesimpulan', 'fields': [
     fld('sebab', 'Sebab kematian tercatat dan sumbernya', 'textarea'),
     fld('hubungan', 'Dugaan hubungan dengan TB (bukan penetapan sebab resmi)', 'select', ['Terkait TB', 'Terkait HIV atau IO lain', 'Sebab lain', 'Belum dapat ditentukan']),
     fld('peluang', 'Peluang perbaikan pelayanan', 'select', ['Ya', 'Tidak', 'BD'], req=True, h='Ya = wajib penilaian kedua.'),
     fld('panel_q', 'Pertanyaan untuk panel', 'textarea')]}]
C6C = [
  {'type': 'fields', 'id': 'hdr', 'title': 'Penelaah 2 (penilaian kedua, tanpa melihat penilaian pertama)', 'fields': [
     fld('kode_berkas', 'Kode berkas kronologi', 'text'), fld('penelaah2', 'Penelaah 2 (kode)', 'text', pre='user_code'), fld('tgl', 'Tanggal', 'date', pre='today'),
     fld('durasi', 'Durasi (menit)', 'number'),
     fld('pernyataan', 'Pernyataan', 'multi', ['Saya tidak melihat penilaian pertama sebelum menyelesaikan lembar ini', 'Saya tidak terlibat dalam pelayanan pasien ini'], req=True),
     fld('kecukupan', 'Kecukupan kronologi untuk dinilai', 'select', ['Memadai', 'Terbatas', 'Tidak memadai']), fld('fase_terbatas', 'Fase terbatas', 'text')]},
  skor_matrix('C1', 'C1 · Skor mutu pelayanan per fase'),
  delay_matrix('C2', 'C2 · Tiga keterlambatan'),
  {'type': 'fields', 'id': 'C3', 'title': 'C3 · Kesimpulan', 'fields': [
     fld('peluang', 'Peluang perbaikan pelayanan', 'select', ['Ya', 'Tidak', 'BD'], req=True),
     fld('faktor1', 'Faktor penyumbang utama 1 (tahap T1–T5, faktor sistem F1–F7, bukti)', 'textarea'),
     fld('faktor2', 'Faktor penyumbang utama 2', 'textarea'), fld('faktor3', 'Faktor penyumbang utama 3', 'textarea'),
     fld('keyakinan', 'Keyakinan keseluruhan', 'select', ['Tinggi', 'Sedang', 'Rendah']), fld('panel_q', 'Hal yang perlu dibahas di panel', 'textarea')]}]
FAKTOR_COLS = table(c6, 'Faktor', 4, 'faktor', 'Faktor penyumbang dan peluang perbaikan (setelah panel)', c1=2, data_row=5)
C6P = [
  {'type': 'fields', 'id': 'panel', 'title': 'Lembar panel daring penelaah klinis', 'fields': [
     fld('tgl', 'Tanggal panel', 'date'), fld('peserta', 'Peserta (kode)', 'text'),
     fld('alasan', 'Alasan dibahas', 'multi', ['Perbedaan penilaian', 'Kematian dini', 'Implikasi program luas']),
     fld('implikasi_luas', 'Implikasi program luas (isi)', 'select', ['Ya', 'Tidak']),
     fld('ringkasan', 'Ringkasan perbedaan penilaian pertama dan kedua (fase, skor, peluang perbaikan)', 'textarea'),
     fld('hasil', 'Hasil pembahasan', 'select', P6('R')),
     fld('klas_akhir', 'Klasifikasi akhir faktor penyumbang (rujuk nomor masalah B4)', 'textarea'),
     fld('peluang_akhir', 'Peluang perbaikan akhir', 'select', ['Ya', 'Tidak', 'BD']),
     fld('implikasi', 'Peluang perbaikan akhir dan implikasi program', 'textarea'),
     fld('pengelola', 'Pengelola program yang diundang (tidak ikut menetapkan klasifikasi)', 'text')]},
  FAKTOR_COLS]

C6_CALON_COLS = []
ws = c6.ws('Daftar_Calon')
CKEY = {'A': 'kk', 'B': 'fasyankes', 'C': 'kode_calon', 'D': 'kode_pasien', 'E': 'sumber', 'F': 'reg_rs', 'G': 'duplikasi', 'H': 'tb', 'I': 'hiv',
        'J': 'mati', 'K': 'tgl_mati', 'M': 'kecukupan', 'O': 'dipilih', 'P': 'alasan', 'Q': 'kode_kasus', 'R': 'kode_unit_c3', 'S': 'status', 'T': 'alasan_gagal', 'U': 'duplikat_dari'}
for c in range(1, ws.max_column + 1):
    h = ws.cell(4, c).value; col = L(c)
    if not h or col not in CKEY: continue
    opts = c6.options('Daftar_Calon', col, 5)
    t = 'date' if col == 'K' else ('select' if opts else 'text')
    C6_CALON_COLS.append(fld(CKEY[col], clean(h), t, opts))
C6_PARAMS = {}
ws = c6.ws('Parameter')
for r in range(5, 11):
    a, b = ws.cell(r, 1).value, ws.cell(r, 2).value
    if a: C6_PARAMS[clean(a)] = b.strftime('%Y-%m-%d') if hasattr(b, 'strftime') else b
C6_RAND = [c6.ws('Kasus').cell(r, 24).value for r in range(5, 75)]

# ---------------------------------------------------------------- C7
ws = c7.ws('Daftar_Sesi')
C7_SESSIONS = []
for r in range(15, 63):
    if ws.cell(r, 1).value:
        C7_SESSIONS.append({'code': ws.cell(r, 1).value, 'kk': ws.cell(r, 2).value, 'target': clean(ws.cell(r, 3).value)})
C7_TARGET = {ws.cell(r, 1).value: clean(ws.cell(r, 2).value) for r in range(5, 12)}
C7S = [
  {'type': 'fields', 'id': 'daftar', 'title': 'Baris Daftar Sesi C7', 'fields': [
     fld('kode_sesi', 'Kode sesi', 'text', pre='unit_code'), fld('kk', 'Kab/kota', 'text', pre='kk_code'), fld('sasaran', 'Informan sasaran', 'textarea', pre='target'),
     fld('tanggal', 'Tanggal', 'date', h='Sesi dianggap terlaksana bila Tanggal diisi.'), fld('jumlah', 'Jumlah peserta', 'number'),
     fld('bersedia', 'Semua bersedia', 'select', ['Ya', 'Tidak']), fld('direkam', 'Direkam', 'select', ['Ya', 'Tidak']),
     fld('lembar_selesai', 'Lembar catatan sesi selesai', 'select', ['Ya', 'Tidak']),
     fld('catatan', 'Catatan (pengganti, alasan batal, perubahan metode)', 'textarea'),
     fld('perspektif', 'Perspektif yang benar-benar tercakup (mis. pasien putus berobat, menolak TPT, populasi kunci)', 'textarea'),
     fld('pengalaman', 'Pengalaman langsung, keterangan organisasi, atau keduanya', 'select', ['Langsung', 'Organisasi', 'Keduanya']),
     fld('rekrutmen_gagal', 'Rekrutmen tidak berhasil (siapa, jumlah, alasan)', 'textarea')]},
  {'type': 'fields', 'id': 'lembar', 'title': 'Lembar catatan sesi', 'note': 'Diisi pencatat dan diperiksa pewawancara paling lambat 24 jam setelah sesi. Jangan menulis nama peserta.', 'fields': [
     fld('jenis', 'Jenis', 'select', ['W', 'F1', 'F2']), fld('jam', 'Tanggal, jam mulai–selesai', 'text'), fld('tempat', 'Tempat atau mode', 'text'),
     fld('pewawancara', 'Pewawancara/fasilitator', 'text', pre='user_code'), fld('pencatat', 'Pencatat', 'text'),
     fld('bahasa', 'Bahasa / penerjemah', 'text')]},
  {'type': 'table', 'id': 'peserta', 'k': 'peserta', 'title': 'Peserta (berkode, tanpa nama)', 'note': 'Kode peserta sama dengan kode sesi; untuk diskusi, kode sesi ditambah urutan duduk (misalnya BAL-F2-04). Ragu atau diam berarti tidak bersedia.',
   'cols': [fld('kode', 'Kode peserta', 'text'), fld('peran', 'Peran', 'text'), fld('kesediaan', 'Kesediaan lisan', 'select', ['Ya', 'Tidak']),
            fld('rekam', 'Izin rekam', 'select', ['Ya', 'Tidak']), fld('jalur', 'Jalur rekrutmen', 'text'),
            fld('pengalaman', 'Pengalaman relevan, sukarela (mis. pernah putus obat, menolak TPT, populasi kunci)', 'textarea')]},
  {'type': 'table', 'id': 'keterangan', 'k': 'keterangan', 'title': 'Keterangan utama per pertanyaan/CP',
   'cols': [fld('no', 'No. pertanyaan / CP', 'text'), fld('ket', 'Keterangan utama', 'textarea'), fld('contoh', 'Contoh konkret (tanpa pengenal)', 'textarea'),
            fld('waktu', 'Bulan/tahun kejadian; sesudah 30/06/2026?', 'text'),
            fld('verifikasi', 'Perlu diverifikasi dengan', 'multi', ['C3', 'C4', 'C5', 'C6', 'WP3']),
            fld('keyakinan', 'Keyakinan pencatat', 'select', ['Tinggi', 'Sedang', 'Rendah'])]},
  {'type': 'fields', 'id': 'refleksi', 'title': 'Ringkasan dan refleksi', 'fields': [
     fld('luar_dugaan', 'Hal di luar dugaan awal', 'textarea'), fld('praktik_baik', 'Praktik yang berjalan baik', 'textarea'),
     fld('usulan', 'Usulan perbaikan, pihak pelaksana, dan apa yang dapat menghambat pelaksanaannya', 'textarea'),
     fld('permintaan', 'Permintaan peserta (tidak dipakai, bantuan rujukan)', 'textarea'),
     fld('refleksi', 'Refleksi pewawancara (hubungan dengan peserta, gangguan, mutu rekaman)', 'textarea')]},
  {'type': 'table', 'id': 'tema', 'k': 'tema', 'title': 'Tema dan kutipan kunci (matriks tema berkode)',
   'cols': [fld('tema', 'Tema', 'text'), fld('cp', 'CP / faktor terkait', 'text'), fld('kutipan', 'Kutipan kunci (tanpa pengenal)', 'textarea'), fld('catatan', 'Catatan analitik', 'textarea')]}]
ws = c7.ws('Cakupan')
C7K = [{'type': 'fields', 'id': 'cakupan', 'title': 'Cakupan perspektif kab/kota (isi setiap akhir hari)',
        'note': clean(ws['A2'].value),
        'fields': [fld(slug(ws.cell(4, c).value, 24), clean(ws.cell(4, c).value), 'select' if c < 11 else 'textarea', ['Ya', 'Sebagian', 'Tidak'] if c < 11 else None) for c in range(2, 12)]}]

# ---------------------------------------------------------------- C1
C1 = [
  {'type': 'fields', 'id': 'hdr', 'title': 'Identitas kab/kota dan pendalaman', 'fields': [
     fld('provinsi', 'Provinsi', 'text', pre='province_name'), fld('kedudukan', 'Kedudukan', 'select', ['Capaian relatif rendah', 'Capaian relatif tinggi']),
     fld('skor', 'Skor kaskade', 'number'), fld('pasangan', 'Pasangan kab/kota (skor)', 'text'),
     fld('tgl_pendalaman', 'Tanggal pendalaman', 'date'), fld('peserta', 'Peserta daerah (jabatan)', 'textarea'),
     fld('ringkasan', 'Ringkasan kontras dengan pasangan', 'textarea')]},
  {'type': 'table', 'id': 'indikator', 'k': 'indikator', 'title': '1 · Profil ringkas: indikator, pembilang, penyebut, sumber, periode, keterbatasan',
   'note': 'Bedakan rekap sistem asal, hasil pemadanan, dan verifikasi sumber. Konfirmasi angka saat pendalaman.',
   'cols': [fld('indikator', 'Indikator', 'text'), fld('nilai', 'Nilai kab/kota', 'text'), fld('pembilang', 'Pembilang', 'number'), fld('penyebut', 'Penyebut', 'number'),
            fld('provinsi', 'Provinsi', 'text'), fld('pasangan', 'Pasangan', 'text'), fld('sumber', 'Sumber', 'text'), fld('periode', 'Periode', 'text'),
            fld('keterbatasan', 'Keterbatasan rekap daerah', 'textarea'),
            fld('konfirmasi', 'Status konfirmasi', 'select', ['Dikonfirmasi', 'Dikoreksi', 'Belum dapat dipastikan']),
            fld('nilai_konf', 'Angka dikonfirmasi/dikoreksi', 'text'), fld('ket_konf', 'Sumber dan penjelasan perbedaan', 'textarea')]},
  {'type': 'table', 'id': 'wp23', 'k': 'wp23', 'title': 'Hasil WP2–WP3 yang telah tersedia',
   'cols': [fld('analisis', 'Analisis/indikator', 'text'), fld('hasil', 'Hasil', 'textarea'), fld('tanggal', 'Tanggal/versi data', 'text'), fld('implikasi', 'Implikasi untuk kunjungan', 'textarea')]},
  {'type': 'table', 'id': 'masalah', 'k': 'masalah', 'title': '2 · Masalah dari profil awal', 'cols': [fld('masalah', 'Masalah', 'textarea')]},
  {'type': 'table', 'id': 'dugaan', 'k': 'dugaan', 'title': '3 · Dugaan penyebab awal (2–4; untuk diuji, belum merupakan akar masalah)', 'max': 4,
   'cols': [fld('dugaan', 'Dugaan penyebab awal', 'textarea'), fld('cp', 'CP terkait', 'text'), fld('fokus', 'Fokus penelusuran', 'textarea'),
            fld('bukti', 'Bukti yang diperlukan', 'textarea'), fld('status', 'Status', 'select', ['Belum diuji', 'Didukung', 'Dibantah', 'Belum cukup bukti'])]},
  {'type': 'table', 'id': 'belum_jelas', 'k': 'belum_jelas', 'title': '4 · Informasi yang belum jelas', 'cols': [fld('info', 'Informasi', 'textarea'), fld('rencana', 'Rencana klarifikasi', 'textarea')]},
  {'type': 'table', 'id': 'pertanyaan', 'k': 'pertanyaan', 'title': '5 · Pertanyaan untuk partisipan kunjungan lapangan',
   'cols': [fld('kelompok', 'Kelompok partisipan', 'text'), fld('pertanyaan', 'Pertanyaan', 'textarea')]},
  {'type': 'table', 'id': 'sumber', 'k': 'sumber', 'title': '6 · Sumber yang harus disiapkan',
   'cols': [fld('sumber', 'Sumber', 'textarea'), fld('status', 'Status', 'select', ['Tersedia', 'Sebagian', 'Belum tersedia']), fld('pic', 'PIC', 'text'), fld('tenggat', 'Tenggat', 'date')]},
  {'type': 'table', 'id': 'kandidat', 'k': 'kandidat', 'title': '7 · Kandidat fasyankes dan sentinel',
   'cols': [fld('fasyankes', 'Fasyankes', 'text'), fld('jenis', 'Jenis', 'select', ['RS', 'Pkm']), fld('tbhiv', 'TB-HIV 2025 (2026)', 'text'),
            fld('status_hiv', 'Status HIV', 'text'), fld('arv', 'ARV', 'text'), fld('berhasil', 'Berhasil Jan–Ags (n)', 'text'),
            fld('tpt_baru', 'TPT ODHIV baru (n)', 'text'), fld('tpt_art', 'TPT dlm ART', 'text'), fld('skor', 'Skor usulan', 'text'),
            fld('sentinel', 'Kandidat sentinel', 'select', ['Ya', 'Tidak']), fld('catatan', 'Catatan', 'textarea')]},
  {'type': 'fields', 'id': 'kesiapan', 'title': 'Kesiapan lapangan (tidak menunggu pemadanan nasional)', 'fields': [
     fld('informan', 'Kandidat informan', 'textarea'), fld('kecukupan', 'Kecukupan sumber kasus (A, B, CP3, kematian)', 'textarea'),
     fld('penghubung', 'Petugas penghubung (jabatan)', 'textarea'), fld('akses_dok', 'Akses dokumen (rekam medis, register)', 'select', ['Tersedia', 'Sebagian', 'Belum tersedia']),
     fld('akses_sitb', 'Akses SITB lokal', 'select', ['Fasyankes', 'Dinas kesehatan', 'Belum tersedia']),
     fld('akses_siha', 'Akses SIHA lokal', 'select', ['Fasyankes', 'Dinas kesehatan', 'Belum tersedia']), fld('izin', 'Status izin', 'textarea')]},
  {'type': 'table', 'id': 'usulan_fokus', 'k': 'usulan_fokus', 'title': '8 · Usulan fokus kunjungan',
   'cols': [fld('fokus', 'Fokus (titik penilaian)', 'text'), fld('alasan', 'Alasan dari profil awal', 'textarea')]},
  {'type': 'table', 'id': 'fokus_sepakat', 'k': 'fokus_sepakat', 'title': '9 · Fokus kunjungan yang disepakati (diisi saat pendalaman)',
   'cols': [fld('fokus', 'Fokus/CP', 'text'), fld('fasyankes', 'Fasyankes', 'text'), fld('bukti', 'Bukti dan catatan yang diperiksa', 'textarea'),
            fld('informan', 'Informan', 'text'), fld('pic', 'PIC daerah', 'text'), fld('hasil', 'Hasil pendalaman', 'textarea')]},
  {'type': 'fields', 'id': 'hasil', 'title': 'Hasil pendalaman dan keputusan', 'note': 'Kabupaten/kota tetap mengikuti keputusan SWG 2 Oktober 2026.', 'fields': [
     fld('fas_utama', 'Fasyankes utama (RS dan Puskesmas): nama, status usulan/disepakati, tanggal keputusan', 'textarea'),
     fld('sentinel', 'Keputusan sentinel', 'textarea'),
     fld('pj', 'Penanggung jawab', 'text'), fld('tindak_lanjut', 'Tindak lanjut dan tenggat', 'textarea'),
     fld('catatan', 'Catatan lain', 'textarea')]}]

# ---------------------------------------------------------------- C2 frames (upload template)
def frame_cols(sheet, last):
    ws = c2a.ws(sheet); cols = []
    for c in range(2, CI(last) + 1):
        h = clean(ws.cell(4, c).value)
        opts = c2a.options(sheet, L(c), 6)
        t = 'date' if h.lower().startswith('tanggal') else ('number' if h.startswith('Umur') else ('select' if opts else 'text'))
        cols.append(fld(L(c), h, t, opts))
    return cols
C2_FRAMES = {
  'A': {'sheet': 'A_TBHIV', 'title': 'Kerangka A: episode TB-HIV', 'crit': clean(c2a.ws('A_TBHIV')['A3'].value), 'cols': frame_cols('A_TBHIV', 'O'), 'date': 'F', 'tgl2': 'G'},
  'B': {'sheet': 'B_ARV', 'title': 'Kerangka B: riwayat pengobatan ARV', 'crit': clean(c2a.ws('B_ARV')['A3'].value), 'cols': frame_cols('B_ARV', 'O'), 'date': 'F'},
  'CP3': {'sheet': 'CP3_TB', 'title': 'Kerangka CP3: episode TB untuk penetapan status HIV', 'crit': clean(c2a.ws('CP3_TB')['A3'].value), 'cols': frame_cols('CP3_TB', 'L'), 'date': 'F'},
}
pl = c2b.ws('Pilihan')
def col_vals(ws, col):
    return [str(x) for x in [ws.cell(r, CI(col)).value for r in range(2, 20)] if x is not None]
C2_OPTS = {'SelOpt': col_vals(pl, 'O'), 'Alasan': col_vals(pl, 'P'), 'Akses': col_vals(pl, 'Q'), 'Telaah': col_vals(pl, 'R')}
ws = c2b.ws('Angka_acak')
ANGKA = {}
for r in range(5, 80):
    k = ws.cell(r, 1).value
    if k: ANGKA[k] = ws.cell(r, 7).value

# ---------------------------------------------------------------- regions & facilities
PROV = [('SUT', 'Sumatera Utara'), ('DKI', 'DKI Jakarta'), ('JBR', 'Jawa Barat'), ('JTM', 'Jawa Timur'), ('BAL', 'Bali'), ('PPA', 'Papua')]
KK = [('DLS', 'Kabupaten Deli Serdang', 'SUT', 'Rendah', 'RS Umum Haji Medan', 'Puskesmas Lubuk Pakam'),
      ('MDN', 'Kota Medan', 'SUT', 'Tinggi', 'RS Santa Elisabeth Medan', 'Puskesmas Helvetia'),
      ('JTI', 'Kota Jakarta Timur', 'DKI', 'Rendah', 'RS Hermina Jatinegara', 'Puskesmas Kecamatan Kramat Jati'),
      ('JPS', 'Kota Jakarta Pusat', 'DKI', 'Tinggi', 'RSPAD Gatot Soebroto', 'Puskesmas Kecamatan Kemayoran'),
      ('IDM', 'Kabupaten Indramayu', 'JBR', 'Rendah', 'RSUD Pantura M.A. Sentot Patrol', 'Puskesmas Bongas'),
      ('BGR', 'Kabupaten Bogor', 'JBR', 'Tinggi', 'RSUD Cibinong', 'Puskesmas Cileungsi'),
      ('SDA', 'Kabupaten Sidoarjo', 'JTM', 'Rendah', 'RS Siti Khodijah Muhammadiyah Sepanjang', 'Puskesmas Tanggulangin'),
      ('SBY', 'Kota Surabaya', 'JTM', 'Tinggi', 'RSUD Husada Prima', 'Puskesmas Kedungdoro'),
      ('BLL', 'Kabupaten Buleleng', 'BAL', 'Rendah', 'RSUD Buleleng', 'Puskesmas Sawan I'),
      ('BDG', 'Kabupaten Badung', 'BAL', 'Tinggi', 'RSD Mangusada', 'Puskesmas Kuta I'),
      ('KJP', 'Kota Jayapura', 'PPA', 'Rendah', 'RS Dian Harapan', 'Puskesmas Hamadi'),
      ('KBJ', 'Kabupaten Jayapura', 'PPA', 'Tinggi', 'RSUD Yowari Sentani', 'Puskesmas Depapre')]
REGIONS = {'prov': [{'code': a, 'name': b} for a, b in PROV],
           'kk': [{'code': a, 'name': b, 'prov': c, 'capaian': d} for a, b, c, d, e, g in KK],
           'fac': [x for a, b, c, d, e, g in KK for x in ({'code': a + '-RS', 'name': '', 'kk': a, 'type': 'RS', 'slot': 1, 'sentinel': False},
                                                          {'code': a + '-PKM', 'name': '', 'kk': a, 'type': 'Puskesmas', 'slot': 2, 'sentinel': False})]}

SCHEMA = {
  'version': '2026-10-31',
  'forms': {
    'C1': {'title': 'C1 Profil awal dan lembar pendalaman', 'unit': 'kk', 'sub': [{'id': 'C1', 'title': 'Profil dan lembar pendalaman kab/kota', 'sections': C1}]},
    'C2': {'title': 'C2 Daftar sampel dan kode bukti', 'unit': 'special'},
    'C3': {'title': 'C3 Telaah catatan pelayanan', 'unit': 'c2unit', 'sub': [
        {'id': 'C3A', 'frame': 'A', 'title': 'Unit A · Episode TB-HIV', 'sections': C3A},
        {'id': 'C3B', 'frame': 'B', 'title': 'Unit B · Riwayat ARV dan TPT', 'sections': C3B},
        {'id': 'C3CP3', 'frame': 'CP3', 'title': 'CP3 · Penetapan status HIV pada episode TB', 'sections': CP3}]},
    'C4': {'title': 'C4 Penilaian fasilitas dan 14 CP', 'unit': 'fac', 'sub': [{'id': 'C4', 'title': 'Penilaian fasilitas dan 14 CP', 'sections': C4}]},
    'C5': {'title': 'C5 Verifikasi data sentinel', 'unit': 'sentinel', 'sub': [
        {'id': 'C5ID', 'title': 'Identitas, metode, dan sistem data', 'sections': C5ID},
        {'id': 'C5_5', 'ind': '5', 'title': 'Pencocokan TB/HIV-5', 'sections': C5_5},
        {'id': 'C5_6', 'ind': '6', 'title': 'Pencocokan TB/HIV-6', 'sections': C5_6},
        {'id': 'C5_41a', 'ind': '41a', 'title': 'Pencocokan TB/HIV-4.1a', 'sections': C5_41}]},
    'C6': {'title': 'C6 Telaah kematian', 'unit': 'c6case', 'sub': [
        {'id': 'C6A', 'title': 'Bagian A · Kronologi', 'sections': C6A},
        {'id': 'C6B', 'title': 'Bagian B · Penilaian pertama', 'sections': C6B, 'blind': 'reviewer2'},
        {'id': 'C6C', 'title': 'C6-C · Penilaian kedua (tersamar)', 'sections': C6C, 'only': 'reviewer2'},
        {'id': 'C6P', 'title': 'Panel dan faktor penyumbang', 'sections': C6P, 'coordOnly': True}]},
    'C7': {'title': 'C7 Wawancara mendalam dan diskusi kelompok', 'unit': 'c7', 'sub': [
        {'id': 'C7S', 'title': 'Sesi wawancara/diskusi', 'sections': C7S},
        {'id': 'C7K', 'title': 'Cakupan perspektif kab/kota', 'sections': C7K, 'unit': 'kk'}]},
  },
  'c2': {'frames': C2_FRAMES, 'opts': C2_OPTS, 'angka_acak': ANGKA, 'c6_calon_cols': C6_CALON_COLS},
  'params': {'c3': C3_PARAM, 'tpt_matang': TPT_MATANG, 'c5': C5_PARAMS, 'c6': C6_PARAMS, 'c6_rand': C6_RAND},
  'c7': {'sessions': C7_SESSIONS, 'target': C7_TARGET},
  'regions': REGIONS,
}

# ---- petunjuk dari versi cetak (Word): ditambahkan ke h bila tersedia
try:
    from guide import extract, norm as gnorm
    GUIDE = {}
    for pat in ['C3_Formulir_Telaah_Catatan_Pelayanan*Cetak*', 'C4_Penilaian_Fasilitas_14CP*Cetak*', 'C5_Verifikasi_Data_Sentinel*Cetak*', 'C6_Formulir_Telaah_Kematian*', 'C6-C_Lembar*']:
        for fp in glob.glob(os.path.join(D, '*' + pat + '.docx')):
            for k, v in extract(fp).items(): GUIDE.setdefault(k, v)
except Exception as e:
    print('guide skipped', e); GUIDE = {}; gnorm = lambda x: x
def _addguide(fx):
    code = (re.match(r'^([A-Z]\d+[a-z]?)\s', fx['l']) or [None, None])[1]
    lab = re.sub(r'^[A-Z]\d+[a-z]?\s', '', fx['l'])
    g = GUIDE.get('code:' + code) if code else None
    g = g or GUIDE.get(gnorm(lab))
    if g and g not in fx.get('h', ''):
        fx['h'] = (fx['h'] + ' ' if fx.get('h') else '') + g
_ng = 0
for fm in SCHEMA['forms'].values():
    for sb in fm.get('sub', []):
        for sec in sb['sections']:
            for fx in sec.get('fields', []) + sec.get('cols', []):
                before = fx.get('h'); _addguide(fx); _ng += fx.get('h') != before
print('guidance added', _ng)

def _uniq(items, key='k'):
    seen = {}
    for it in items:
        k = it[key]
        if k in seen:
            seen[k] += 1; it[key] = f"{k}_{seen[k]}"
        else:
            seen[k] = 1
for fm in SCHEMA['forms'].values():
    for sb in fm.get('sub', []):
        allf = [x for s in sb['sections'] if s['type'] == 'fields' for x in s['fields']]
        _uniq(allf)
        for s in sb['sections']:
            if s.get('cols'): _uniq(s['cols'])
            if s.get('rows'): _uniq(s['rows'])
        ids = [s for s in sb['sections']]
        _uniq(ids, 'id')
_uniq(C6_CALON_COLS)

with open(OUT, 'w') as fh:
    fh.write('/* Dihasilkan otomatis dari instrumen RCA TB-HIV 2026 (gen_schema.py). Ubah instrumen lalu jalankan ulang generator,\n   atau edit langsung bila hanya perubahan kecil. */\n')
    fh.write('window.RCA_SCHEMA = ' + json.dumps(SCHEMA, ensure_ascii=False, indent=1, default=str) + ';\n')
# stats
def count(secs):
    n = 0
    for s in secs:
        n += len(s.get('fields', [])) + len(s.get('cols', [])) * (len(s.get('rows', [])) or 1)
    return n
for fid, fm in SCHEMA['forms'].items():
    for sb in fm.get('sub', []):
        print(fid, sb['id'], 'sections', len(sb['sections']), 'items', count(sb['sections']))
print('bytes', os.path.getsize(OUT))

# ---------------------------------------------------------------- GAS seed
GAS = os.path.join(os.path.dirname(OUT), '..', '..', 'gas', 'Seed.gs')
with open(GAS, 'w') as fh:
    fh.write('/** Data awal (dihasilkan otomatis dari instrumen). Jangan diubah setelah undian C2 dimulai. */\n')
    fh.write('var SEED = ' + json.dumps({'regions': REGIONS, 'angka_acak': ANGKA, 'c7_sessions': C7_SESSIONS,
                                         'c6_rand': C6_RAND, 'c6_params': C6_PARAMS, 'c3_params': C3_PARAM},
                                        ensure_ascii=False, indent=1, default=str) + ';\n')
print('seed', os.path.getsize(GAS))
