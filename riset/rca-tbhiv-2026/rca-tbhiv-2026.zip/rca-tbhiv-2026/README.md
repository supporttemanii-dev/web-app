# RCA TB-HIV 2026 · Aplikasi Pengumpulan Data Lapangan

Aplikasi web (HP, tablet, laptop) untuk alur C1–C7 RCA TB-HIV 2026. Tampilan di **GitHub Pages**, server dan basis data di **Google Apps Script + Google Spreadsheet** (satu spreadsheet per formulir).

```
rca-tbhiv-2026/
├── app/        → unggah isi folder ini ke repositori GitHub Pages
│   ├── index.html, config.js (isi API_URL), css/, js/, vendor/, templates/
│   └── js/schema.js  (variabel C1–C7, dihasilkan dari instrumen Excel)
├── gas/        → salin ke proyek Google Apps Script
│   ├── Code.gs, Seed.gs, appsscript.json
└── tools/      → generator skema dari instrumen (Python), bila instrumen direvisi
```

## 1. Deploy server (Google Apps Script)

1. Masuk dengan akun pemilik data (anomharjana@unud.ac.id). Buka https://script.google.com › **Proyek baru**. Beri nama "RCA TB-HIV 2026 Server".
2. Ganti isi `Code.gs` dengan isi `gas/Code.gs`. Tambah berkas skrip baru bernama `Seed` dan tempel isi `gas/Seed.gs`.
3. **Setelan proyek** (ikon roda gigi) › centang *Tampilkan file manifes "appsscript.json"* › ganti isinya dengan `gas/appsscript.json`.
4. Pilih fungsi `setup` di bilah atas › **Jalankan** › izinkan akses (Spreadsheet dan Drive). Fungsi ini membuat folder **"RCA TB-HIV 2026 - Data (PRIVAT)"** berisi spreadsheet Master, C1–C7, dan folder Foto. Jalankan sekali saja (aman bila terulang).
5. **Terapkan › Deployment baru** › jenis **Aplikasi web**:
   - Jalankan sebagai: **Saya**
   - Yang memiliki akses: **Siapa saja** (Anyone)
   Salin **URL aplikasi web** (berakhiran `/exec`).
6. Setiap kali `Code.gs` diubah: **Terapkan › Kelola deployment › Edit › Versi: Versi baru** (URL tetap sama).

> Bila opsi "Siapa saja" tidak muncul, admin Google Workspace Unud membatasi Web App untuk akun domain. Minta admin mengizinkan, atau jalankan server dari akun Gmail khusus proyek (pengguna Gmail pribadi tetap dapat masuk karena login aplikasi memakai email + PIN, bukan akun Google).

## 2. Deploy tampilan (GitHub Pages)

1. Buat repositori, misalnya `rca-tbhiv-2026`. Unggah **isi folder `app/`** ke root repositori.
2. Edit `config.js`: `API_URL: 'https://script.google.com/macros/s/…/exec'`.
3. **Settings › Pages** › Source: *Deploy from a branch* › Branch `main` / root › Save. Alamat aplikasi: `https://<akun>.github.io/rca-tbhiv-2026/`.
4. Buka alamat tersebut. Di HP dapat ditambahkan ke layar utama (Add to Home Screen).

## 3. Penggunaan pertama

1. Super Admin (anomharjana@unud.ac.id dan bettyoktaviana@gmail.com) sudah tercatat. Pilih **Daftar** dengan email tersebut untuk menetapkan PIN 6 angka; akun langsung aktif.
2. Anggota tim mendaftar (nama, email, kode petugas, institusi, peran, PIN). Super Admin menyetujui di **Admin › Akun dan persetujuan** dan dapat mengubah peran, kode petugas, menonaktifkan, atau mengatur ulang PIN.
3. Di **Admin › Fasyankes dan sentinel**: sesuaikan nama 24 fasyankes (terisi dari usulan C1) dan tandai **satu sentinel per provinsi**. Tetapkan **perluasan A/B per provinsi** sebelum undian.

## 4. Alur kerja di aplikasi

| Tahap | Menu | Siapa |
|---|---|---|
| Profil kab/kota | **C1** (isi langsung, atau *Unggah/unduh templat C1* Excel) | Koordinator |
| Kerangka & undian | **C2 › Kerangka dan undian C3**: pilih fasyankes › **Unggah berkas C2a** (lembar A_TBHIV, B_ARV, CP3_TB dibaca sekaligus) › **Jalankan undian**; tetapkan purposif + alasan, pengganti, akses, status telaah. Pasien yang tercatat **Meninggal** di C2a otomatis menjadi **calon C6** (status "Belum diperiksa"); bila fasyankes sentinel, baris triwulan verifikasi otomatis masuk **daftar sistem C5** | Koordinator |
| Calon kematian | **C2 › Calon kematian C6**: kelayakan dihitung otomatis; calon terpilih mendapat kode kasus `C6-KK-nn`; tetapkan penelaah 1 dan 2 | Koordinator |
| Daftar sentinel | **C2 › Daftar sistem sentinel C5**: unduh templat, unggah ekspor SITB/SIHA satu triwulan per indikator | Koordinator |
| Sesi kualitatif | **C2 › Sesi wawancara C7**: 48 sesi dari Daftar Sesi sudah tersedia; tambah sesi pengganti | Koordinator |
| Lembar penghubung | **C2 › Lembar penghubung kode**: daftar kode unit terpilih per fasyankes (cetak/Excel) untuk dicocokkan petugas dengan NIK/no. RM di fasyankes | Koordinator → fasyankes |
| Telaah lapangan | **C3, C4, C5, C6, C7**: buka unit pada papan register, isi, *Kirim ke database* | Enumerator |
| Pemeriksaan | **Dashboard Progress**: antrean *Dikirim*, tabel semua variabel, *Kembalikan* (wajib catatan; enumerator mendapat notifikasi) atau *Tandai Valid* | Koordinator |
| Analisis | **Dashboard Analisis**: hanya data Valid; Pembaca menerima data tanpa kode | Semua |
| Laporan | **Dashboard Laporan**: laporan otomatis menurut Protokol V13 (pelaksanaan, Q1–Q6, 14 CP, sentinel, kematian, kualitatif, bahan sintesis WP7, keterbatasan); **Simpan PDF** dan **Simpan Excel** (satu lembar per tabel); dapat difilter per provinsi | Semua |

Status rekaman: **Belum → Draf → Dikirim → (Dikembalikan → Dikirim) → Valid**. Rekaman Valid terkunci; koordinator dapat *Buka kembali*. Setiap simpan/kirim/tinjau tercatat di lembar **Riwayat** (spreadsheet formulir) dan **Audit** (Master).

### Ketentuan yang sudah diterapkan dari instrumen
- **Undian C2b**: identik dengan rumus Excel C2b (titik awal U dari lembar Angka_acak seed 20261012, interval N/3, P1/P3/P5 inti, P2/P4/P6 perluasan atau cadangan 1–3, P7–P12 cadangan 4–9, sensus bila baris 2025 ≤ 6, CP3 hanya status tercatat untuk acak). Sudah diuji silang dengan LibreOffice terhadap berkas C2b asli: posisi terpilih sama persis.
- **C3**: 105/101 butir Unit A/B dan CP3_Register dengan status bukti Y/TL/TC/TBL/BD + kode sumber; hitungan otomatis (selang hari, ARV melewati batas 14/56 hari, CP6/CP7/CP2, PNPK sensitivitas, kematangan TPT, mekanisme CP3), *Cek isian* dan *Pemicu pendalaman*; tabel Sumber, Rujukan (bila T01 = Ya), Interupsi (bila T02 = Ya).
- **C4**: identitas, layanan, dugaan C1 (tombol *Ambil dari C1*), alur, dokumen/stok, diagnostik-pencatatan, observasi, wawancara singkat, **Matriks 14 CP + R6** (acuan per CP, status pemeriksaan dan saran klasifikasi otomatis, tombol *Isi n/N dari C3*), pendalaman, daftar bukti, kesimpulan.
- **C5**: identitas/akses/jejak, metode per indikator (sensus/satu bulan/sampel, U acak), model bukti A/B/C/BD; lembar pencocokan dua arah per indikator dengan D/N sistem-sumber, status pencocokan, sampel arah 1 `INT((j+U)×N/n)+1`, dan **faktor verifikasi** (hanya model A, sensus, seluruh sumber diperiksa).
- **C6**: Bagian A kronologi, B penilaian pertama, **C6-C penilaian kedua tersamar** (server menolak menampilkan Bagian B kepada penelaah 2), penentuan otomatis penilaian kedua (wajib bila peluang perbaikan; acak ≥30% kasus lain memakai angka acak tetap), lembar panel dengan perbandingan skor, kappa dikotomi di dashboard.
- **C7**: baris Daftar Sesi + Lembar catatan sesi (peserta berkode, keterangan per CP, refleksi, tema dan kutipan), cakupan perspektif per kab/kota.

## 5. Petunjuk pengisian
Setiap isian memiliki tombol **?** berisi petunjuk dari versi cetak instrumen, contoh isian, cara hitung (untuk kolom otomatis), dan penjelasan istilah (St, kode sumber, CP, TPT, FV, dll.). Tombol *Tampilkan semua petunjuk* membuka semuanya sekaligus. Definisi TB/HIV-5, TB/HIV-6, dan TB/HIV-4.1a tampil di formulir C5 dan di C2 › Daftar sistem sentinel. Isi glosarium dan contoh dapat diubah di `app/js/help.js`.

## 6. Kunci unit, offline, dan foto
- Membuka unit = mengunci untuk pengguna itu; papan register menampilkan inisialnya (hijau berdenyut = aktif; kuning = tidak aktif/kemungkinan offline). Detak dikirim tiap 60 detik; **kunci lepas setelah 5 menit tanpa aktivitas** (peringatan 1 menit sebelumnya). Bila pengguna kembali online dan unit belum diambil orang lain, kunci kembali kepadanya; bila sudah diambil, isiannya disimpan sebagai **versi cadangan** yang dapat dibandingkan dan dipilih koordinator di Dashboard Progress.
- Setiap perubahan tersimpan di perangkat (IndexedDB) dan disinkronkan tiap ±25 detik. Saat offline muncul pita kuning; *Kirim final* memerlukan koneksi.
- Foto opsional: dikompres (sisi terpanjang 1.600 px, JPEG ±200–400 KB), alat **potong** dan **tutup/blur**, centang konfirmasi "nama/NIK tidak terlihat" wajib. Disimpan di folder Drive privat, hanya ditampilkan melalui server kepada pengguna yang masuk.

## 7. Keamanan data
- Spreadsheet dan folder Drive **tidak perlu dibagikan** ke siapa pun selain pemilik. Pengguna aplikasi tidak pernah membuka spreadsheet; semua akses lewat server dengan token sesi (12 jam).
- PIN disimpan sebagai hash SHA-256 + salt + pepper; 5 kali salah → akun dikunci 15 menit.
- Peran dicek di server: Pembaca hanya menerima data Valid tanpa kode; ekspor Excel hanya Koordinator/Super Admin.
- Aplikasi menolak unggahan kerangka yang judul kolomnya mirip identitas (nama/NIK/no. RM/alamat/telepon) atau berisi angka 16 digit.
- Kode GitHub bersifat publik, tetapi tidak berisi data. URL server terlihat, namun tanpa token tidak ada data yang dapat dibaca.

## 8. Mengubah instrumen atau menambah analisis
- Perubahan kecil (label, pilihan): edit `app/js/schema.js` langsung.
- Revisi instrumen Excel: jalankan `python3 tools/gen_schema.py <folder_instrumen> app/js/schema.js` (memerlukan `openpyxl`); generator juga memperbarui `gas/Seed.gs`. Nama berkas instrumen dicari berdasarkan pola nama yang sama.
- Analisis baru: tambahkan objek di `app/js/analysis-custom.js` (sudah ada contoh dan tiga placeholder). Muncul di tab *Analisis tambahan*.

## 9. Yang perlu Anda periksa sebelum dipakai di lapangan
- Nama 24 fasyankes dan 6 sentinel (terisi dari **usulan awal** di C1 Revisi 2; ubah di Admin).
- Kuota: Apps Script akun Workspace cukup untuk ±15 pengguna serentak; setiap simpan memerlukan 1–3 detik.
- Uji coba satu putaran penuh dengan data dummy (daftar → undian → isi → kirim → kembalikan → valid) sebelum kunjungan, lalu hapus isi lembar data (kecuali Master › Users/Faskes) bila ingin mulai bersih.
