/**
 * RCA TB-HIV 2026 · Server Google Apps Script
 * ------------------------------------------------------------
 * Satu proyek Apps Script mengelola:
 *   - Spreadsheet MASTER  : akun, sesi, wilayah, fasyankes, kunci unit, notifikasi, log audit, konflik
 *   - Spreadsheet C1 … C7 : satu spreadsheet per formulir (satu lembar per sub-formulir + Riwayat)
 *   - Folder Drive privat : foto pendukung
 * Aplikasi web (GitHub Pages) memanggil Web App ini dengan POST (Content-Type: text/plain).
 *
 * Langkah awal: jalankan fungsi setup() sekali dari editor Apps Script, lalu Deploy > New deployment > Web app
 * (Execute as: Me, Who has access: Anyone). Lihat README.
 */

var APP = {
  NAME: 'RCA TB-HIV 2026',
  LOCK_MIN: 5,              // kunci unit lepas setelah 5 menit tanpa aktivitas
  SESSION_HOURS: 12,
  MAX_FAIL: 5,
  FAIL_LOCK_MIN: 15,
  SUPER_ADMINS: ['anomharjana@unud.ac.id', 'bettyoktaviana@gmail.com'],
  ROLES: ['SuperAdmin', 'Koordinator', 'Enumerator', 'Pembaca'],
  DATA_CHUNKS: 12,          // 12 x 45.000 karakter per rekaman
  CHUNK: 45000
};
var FORMS = ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7'];
var SUBS = { C1: ['C1'], C3: ['C3A', 'C3B', 'C3CP3'], C4: ['C4'], C5: ['C5ID', 'C5_5', 'C5_6', 'C5_41a'],
             C6: ['C6A', 'C6B', 'C6C', 'C6P'], C7: ['C7S', 'C7K'] };
var FRAME_SUB = { A: 'C3A', B: 'C3B', CP3: 'C3CP3' };
var STATUS = { DRAFT: 'Draf', SENT: 'Dikirim', RETURNED: 'Dikembalikan', VALID: 'Valid' };
var REC_BASE = ['unit', 'sub', 'fac', 'kk', 'prov', 'status', 'version', 'owner', 'owner_name', 'updated_by', 'updated_name',
                'updated_at', 'submitted_at', 'validated_by', 'validated_at', 'return_note', 'progress'];

/* ============================================================ ENTRY POINTS */
function doGet(e) {
  return json_({ ok: true, app: APP.NAME, ready: !!prop_('SS_MASTER'), time: now_() });
}

function doPost(e) {
  var req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'Permintaan tidak valid' }); }
  try {
    var h = API[req.action];
    if (!h) throw err_('Aksi tidak dikenal: ' + req.action);
    var ctx = { req: req };
    if (!h.pub) {
      ctx.user = auth_(req.token);
      if (h.roles && h.roles.indexOf(ctx.user.role) < 0) throw err_('Akses ditolak untuk peran ' + ctx.user.role);
    }
    var out;
    if (h.write) {
      var lock = LockService.getScriptLock();
      lock.waitLock(25000);
      try { out = h.fn(req, ctx); } finally { lock.releaseLock(); }
    } else out = h.fn(req, ctx);
    return json_({ ok: true, data: out, time: now_() });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err), code: err && err.code || '', stack: (typeof DEBUG !== 'undefined' && DEBUG) ? String(err.stack) : undefined });
  }
}

/* ============================================================ SETUP */
function setup() {
  var p = PropertiesService.getScriptProperties();
  if (!p.getProperty('PEPPER')) p.setProperty('PEPPER', Utilities.getUuid() + Utilities.getUuid());
  var folderId = p.getProperty('FOLDER');
  var folder;
  if (folderId) folder = DriveApp.getFolderById(folderId);
  else { folder = DriveApp.createFolder('RCA TB-HIV 2026 - Data (PRIVAT)'); p.setProperty('FOLDER', folder.getId()); }
  if (!p.getProperty('PHOTOS')) p.setProperty('PHOTOS', folder.createFolder('Foto').getId());
  ['MASTER'].concat(FORMS).forEach(function (n) {
    if (!p.getProperty('SS_' + n)) {
      var ss = SpreadsheetApp.create('RCA TB-HIV 2026 - ' + (n === 'MASTER' ? 'Master' : n));
      DriveApp.getFileById(ss.getId()).moveTo(folder);
      try { ss.setSpreadsheetTimeZone(Session.getScriptTimeZone()); } catch (e) { }
      p.setProperty('SS_' + n, ss.getId());
    }
  });
  // Master sheets
  var M = 'MASTER';
  tbl_(M, 'Users', ['email', 'name', 'code', 'role', 'role_req', 'status', 'institution', 'phone', 'pin_hash', 'salt', 'fails', 'lock_until', 'created', 'approved_by', 'approved_at', 'last_login']);
  tbl_(M, 'Sessions', ['token', 'email', 'created', 'expires', 'last_seen', 'agent']);
  tbl_(M, 'Locks', ['key', 'email', 'name', 'since', 'last_beat', 'last_act']);
  tbl_(M, 'Notif', ['id', 'to', 'from', 'from_name', 'created', 'form', 'sub', 'unit', 'msg', 'read']);
  tbl_(M, 'Audit', ['ts', 'email', 'action', 'target', 'detail']);
  tbl_(M, 'Konflik', ['id', 'ts', 'form', 'sub', 'unit', 'email', 'name', 'reason', 'base_version', 'server_version', 'status', '_data']);
  var prov = tbl_(M, 'Provinsi', ['code', 'name']);
  var kk = tbl_(M, 'KabKota', ['code', 'name', 'prov', 'capaian']);
  var fac = tbl_(M, 'Faskes', ['code', 'name', 'kk', 'type', 'slot', 'sentinel']);
  if (!prov.rows.length) SEED.regions.prov.forEach(function (r) { prov.append(r); });
  if (!kk.rows.length) SEED.regions.kk.forEach(function (r) { kk.append(r); });
  if (!fac.rows.length) SEED.regions.fac.forEach(function (r) { r.sentinel = r.sentinel ? 'Ya' : 'Tidak'; fac.append(r); });
  var cfg = tbl_(M, 'Config', ['key', 'value', 'note']);
  if (!cfg.find('key', 'perluasan')) cfg.append({ key: 'perluasan', value: '{}', note: 'Perluasan per provinsi (JSON), ditetapkan sebelum undian' });
  APP.SUPER_ADMINS.forEach(function (em) {
    var U = tbl_(M, 'Users');
    if (!U.find('email', em)) U.append({ email: em, name: em.split('@')[0], role: 'SuperAdmin', status: 'Menunggu PIN', created: now_() });
  });
  // Form sheets
  Object.keys(SUBS).forEach(function (f) {
    SUBS[f].forEach(function (s) { recTbl_(f, s); });
    tbl_(f, 'Riwayat', ['ts', 'sub', 'unit', 'email', 'action', 'status', 'version', 'note', 'snapshot']);
  });
  // C2 sheets
  tbl_('C2', 'Kerangka', C2_COLS);
  tbl_('C2', 'Undian', ['fac', 'frame', 'U', 'perluasan', 'rekap', 'tanggal_undian', 'oleh', 'versi', 'catatan']);
  tbl_('C2', 'Calon_C6', ['id', 'kk', 'fasyankes', 'kode_calon', 'kode_pasien', 'sumber', 'reg_rs', 'duplikasi', 'tb', 'hiv', 'mati', 'tgl_mati',
    'kecukupan', 'dipilih', 'alasan', 'kode_kasus', 'kode_unit_c3', 'status', 'alasan_gagal', 'duplikat_dari', 'pen1', 'pen2', 'updated_by', 'updated_at']);
  var ses = tbl_('C2', 'Sesi_C7', ['code', 'kk', 'prov', 'target', 'tambahan', 'catatan', 'updated_by', 'updated_at']);
  if (!ses.rows.length) SEED.c7_sessions.forEach(function (s) { ses.append({ code: s.code, kk: s.kk, prov: s.code.split('-')[0], target: s.target }); });
  tbl_('C2', 'Riwayat', ['ts', 'sub', 'unit', 'email', 'action', 'status', 'version', 'note', 'snapshot']);
  // remove default empty "Sheet1"
  ['MASTER'].concat(FORMS).forEach(function (n) {
    var ss = ss_(n); var s1 = ss.getSheetByName('Sheet1') || ss.getSheetByName('Lembar1');
    if (s1 && ss.getSheets().length > 1) ss.deleteSheet(s1);
  });
  Logger.log('Setup selesai. Folder data: ' + folder.getUrl());
  return 'OK';
}

/** Pemeliharaan: kosongkan nama fasyankes dan status sentinel di spreadsheet Master
 *  (dipakai bila setup() sudah pernah dijalankan dengan nama usulan). Jalankan sekali dari editor. */
function kosongkanNamaFaskesDanSentinel() {
  var F = tbl_('MASTER', 'Faskes');
  F.rows.forEach(function (f) { F.update(f, { name: '', sentinel: 'Tidak' }); });
  Logger.log('Nama fasyankes dikosongkan dan sentinel dilepas untuk ' + F.rows.length + ' fasyankes.');
}

/* ============================================================ API */
var API = {
  ping: { pub: true, fn: function () { return { app: APP.NAME, ready: !!prop_('SS_MASTER') }; } },

  register: { pub: true, write: true, fn: function (r) {
    var email = normEmail_(r.email), pin = String(r.pin || '');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw err_('Format email tidak valid');
    if (!/^\d{6}$/.test(pin)) throw err_('PIN harus 6 digit angka');
    var name = clean_(r.name, 80); if (!name) throw err_('Nama wajib diisi');
    var role = r.role; if (['Koordinator', 'Enumerator', 'Pembaca'].indexOf(role) < 0) throw err_('Peran tidak valid');
    var U = tbl_('MASTER', 'Users');
    var u = U.find('email', email);
    var salt = Utilities.getUuid();
    if (u) {
      if (u.status === 'Menunggu PIN' && APP.SUPER_ADMINS.indexOf(email) >= 0) {
        U.update(u, { name: name, code: clean_(r.code, 12) || u.code, institution: clean_(r.institution, 120), phone: clean_(r.phone, 30),
          pin_hash: hash_(pin, salt), salt: salt, status: 'Aktif', approved_by: 'sistem', approved_at: now_() });
        audit_(email, 'register', 'SuperAdmin', 'PIN Super Admin ditetapkan');
        return { status: 'Aktif', message: 'Akun Super Admin aktif. Silakan masuk.' };
      }
      if (u.status === 'Ditolak' || u.status === 'Menunggu') {
        U.update(u, { name: name, role_req: role, code: clean_(r.code, 12), institution: clean_(r.institution, 120), phone: clean_(r.phone, 30),
          pin_hash: hash_(pin, salt), salt: salt, status: 'Menunggu', created: now_() });
        audit_(email, 'register', role, 'pendaftaran ulang');
        return { status: 'Menunggu', message: 'Pendaftaran diperbarui dan menunggu persetujuan Super Admin.' };
      }
      throw err_('Email sudah terdaftar. Hubungi Super Admin bila lupa PIN.');
    }
    U.append({ email: email, name: name, code: clean_(r.code, 12), role: '', role_req: role, status: 'Menunggu', institution: clean_(r.institution, 120),
      phone: clean_(r.phone, 30), pin_hash: hash_(pin, salt), salt: salt, fails: 0, created: now_() });
    audit_(email, 'register', role, '');
    notifyAdmins_('Pendaftaran baru: ' + name + ' (' + email + ') meminta peran ' + role);
    return { status: 'Menunggu', message: 'Pendaftaran terkirim. Akun aktif setelah disetujui Super Admin.' };
  } },

  login: { pub: true, write: true, fn: function (r) {
    var email = normEmail_(r.email), pin = String(r.pin || '');
    var U = tbl_('MASTER', 'Users'); var u = U.find('email', email);
    if (!u) throw err_('Email atau PIN salah');
    if (u.status === 'Menunggu PIN') throw err_('Akun Super Admin belum memiliki PIN. Silakan daftar dengan email ini untuk menetapkan PIN.');
    if (u.status === 'Menunggu') throw err_('Akun masih menunggu persetujuan Super Admin');
    if (u.status !== 'Aktif') throw err_('Akun tidak aktif (' + u.status + ')');
    if (u.lock_until && new Date(u.lock_until) > new Date()) throw err_('Terlalu banyak percobaan. Coba lagi setelah ' + fmtTime_(u.lock_until));
    if (hash_(pin, u.salt) !== u.pin_hash) {
      var fails = Number(u.fails || 0) + 1;
      var upd = { fails: fails };
      if (fails >= APP.MAX_FAIL) { upd.lock_until = new Date(Date.now() + APP.FAIL_LOCK_MIN * 60000).toISOString(); upd.fails = 0; }
      U.update(u, upd); audit_(email, 'login_gagal', '', 'percobaan ' + fails);
      throw err_(fails >= APP.MAX_FAIL ? 'PIN salah 5 kali. Akun dikunci ' + APP.FAIL_LOCK_MIN + ' menit.' : 'Email atau PIN salah (sisa ' + (APP.MAX_FAIL - fails) + ' percobaan)');
    }
    U.update(u, { fails: 0, lock_until: '', last_login: now_() });
    var token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
    var S = tbl_('MASTER', 'Sessions');
    S.append({ token: hash_(token, 'sess'), email: email, created: now_(), expires: new Date(Date.now() + APP.SESSION_HOURS * 3600000).toISOString(), last_seen: now_(), agent: clean_(r.agent, 120) });
    pruneSessions_(S);
    audit_(email, 'login', '', '');
    return { token: token, user: publicUser_(u) };
  } },

  logout: { write: true, fn: function (r, c) {
    var S = tbl_('MASTER', 'Sessions'); var s = S.find('token', hash_(r.token, 'sess'));
    if (s) S.remove(s);
    releaseAllLocks_(c.user.email);
    CacheService.getScriptCache().remove('t_' + hash_(r.token, 'sess'));
    return true;
  } },

  bootstrap: { fn: function (r, c) {
    return { user: c.user, regions: regions_(), users: userDirectory_(c.user), notif: myNotif_(c.user.email),
             perluasan: JSON.parse(cfg_('perluasan') || '{}'), lockMin: APP.LOCK_MIN };
  } },

  /** heartbeat: memperpanjang sesi & kunci unit; mengembalikan notifikasi baru dan status kunci */
  heartbeat: { write: true, fn: function (r, c) {
    var L = tbl_('MASTER', 'Locks');
    var keys = r.keys || [], res = {};
    var t = now_();
    keys.forEach(function (k) {
      var l = L.find('key', k);
      if (l && l.email === c.user.email && !expired_(l)) {
        var upd = { last_beat: t }; if (r.active) upd.last_act = t;
        L.update(l, upd); res[k] = 'held';
      } else if (l && l.email !== c.user.email && !expired_(l)) res[k] = 'taken:' + l.name;
      else {
        // kunci lepas: ambil kembali bila belum diambil orang lain
        if (l) L.remove(l);
        L.append({ key: k, email: c.user.email, name: c.user.name, since: t, last_beat: t, last_act: t });
        res[k] = 'reacquired';
      }
    });
    return { locks: res, notif: myNotif_(c.user.email) };
  } },

  'notif.read': { write: true, fn: function (r, c) {
    var N = tbl_('MASTER', 'Notif');
    N.rows.forEach(function (n) { if (n.to === c.user.email && (r.all || (r.ids || []).indexOf(n.id) >= 0) && n.read !== 'Ya') N.update(n, { read: 'Ya' }); });
    return true;
  } },

  /* ------------------------------ admin */
  'users.list': { roles: ['SuperAdmin'], fn: function () {
    return tbl_('MASTER', 'Users').rows.map(publicUser_);
  } },
  'users.update': { roles: ['SuperAdmin'], write: true, fn: function (r, c) {
    var U = tbl_('MASTER', 'Users'); var u = U.find('email', normEmail_(r.email));
    if (!u) throw err_('Pengguna tidak ditemukan');
    var upd = {};
    if (r.status) {
      if (['Aktif', 'Ditolak', 'Nonaktif', 'Menunggu'].indexOf(r.status) < 0) throw err_('Status tidak valid');
      upd.status = r.status;
      if (r.status === 'Aktif') { upd.approved_by = c.user.email; upd.approved_at = now_(); if (!u.role && !r.role) upd.role = u.role_req; }
    }
    if (r.role) { if (APP.ROLES.indexOf(r.role) < 0) throw err_('Peran tidak valid'); upd.role = r.role; }
    if (r.code !== undefined) upd.code = clean_(r.code, 12);
    if (r.name) upd.name = clean_(r.name, 80);
    if (u.email === c.user.email && (upd.status && upd.status !== 'Aktif' || upd.role && upd.role !== 'SuperAdmin')) throw err_('Tidak dapat menurunkan akun sendiri');
    U.update(u, upd);
    if (upd.status && upd.status !== 'Aktif') killSessions_(u.email);
    audit_(c.user.email, 'users.update', u.email, JSON.stringify(upd));
    if (upd.status === 'Aktif') notify_(u.email, c.user, '', '', '', 'Akun Anda telah disetujui sebagai ' + (upd.role || u.role || u.role_req) + '.');
    return publicUser_(U.find('email', u.email));
  } },
  'users.resetPin': { roles: ['SuperAdmin'], write: true, fn: function (r, c) {
    var U = tbl_('MASTER', 'Users'); var u = U.find('email', normEmail_(r.email));
    if (!u) throw err_('Pengguna tidak ditemukan');
    var pin = String(Math.floor(100000 + Math.random() * 900000)); var salt = Utilities.getUuid();
    U.update(u, { pin_hash: hash_(pin, salt), salt: salt, fails: 0, lock_until: '' });
    killSessions_(u.email);
    audit_(c.user.email, 'users.resetPin', u.email, '');
    return { pin: pin };
  } },
  'users.changePin': { write: true, fn: function (r, c) {
    var U = tbl_('MASTER', 'Users'); var u = U.find('email', c.user.email);
    if (hash_(String(r.old || ''), u.salt) !== u.pin_hash) throw err_('PIN lama salah');
    if (!/^\d{6}$/.test(String(r.pin || ''))) throw err_('PIN baru harus 6 digit');
    var salt = Utilities.getUuid(); U.update(u, { pin_hash: hash_(String(r.pin), salt), salt: salt });
    audit_(c.user.email, 'users.changePin', '', ''); return true;
  } },
  'fac.update': { roles: ['SuperAdmin', 'Koordinator'], write: true, fn: function (r, c) {
    var F = tbl_('MASTER', 'Faskes'); var f = F.find('code', r.code);
    if (!f) throw err_('Fasyankes tidak ditemukan');
    var upd = {};
    if (r.name !== undefined) upd.name = clean_(r.name, 120);
    if (r.type) upd.type = r.type;
    if (r.sentinel !== undefined) upd.sentinel = r.sentinel ? 'Ya' : 'Tidak';
    F.update(f, upd); audit_(c.user.email, 'fac.update', r.code, JSON.stringify(upd));
    _regions = null;
    if (upd.sentinel === 'Ya') { try { c5AutoFromC2_(r.code, c.user); } catch (e) { } }
    return regions_();
  } },
  'config.perluasan': { roles: ['SuperAdmin', 'Koordinator'], write: true, fn: function (r, c) {
    var p = JSON.parse(cfg_('perluasan') || '{}'); p[r.prov] = r.value ? 'Ya' : 'Tidak';
    cfgSet_('perluasan', JSON.stringify(p)); audit_(c.user.email, 'perluasan', r.prov, p[r.prov]); return p;
  } },
  'audit.list': { roles: ['SuperAdmin', 'Koordinator'], fn: function (r) {
    var rows = tbl_('MASTER', 'Audit').rows; return rows.slice(Math.max(0, rows.length - (r.limit || 300))).reverse();
  } },

  /* ------------------------------ units & records */
  'units.list': { fn: function (r, c) { return unitsList_(r.form, c.user); } },

  'rec.get': { fn: function (r, c) {
    if (c.user.role === 'Pembaca') throw err_('Pembaca hanya dapat melihat dashboard agregat');
    checkBlind_(r.form, r.sub, r.unit, c.user);
    var T = recTbl_(r.form, r.sub); var row = T.find('unit', r.unit);
    var rec = row ? recOut_(row) : null;
    var lock = lockInfo_(key_(r.form, r.sub, r.unit));
    return { rec: rec, lock: lock, related: related_(r.form, r.sub, r.unit, c.user) };
  } },

  'rec.lock': { write: true, fn: function (r, c) {
    if (['Enumerator', 'Koordinator', 'SuperAdmin'].indexOf(c.user.role) < 0) throw err_('Peran ini tidak dapat mengisi formulir');
    checkBlind_(r.form, r.sub, r.unit, c.user);
    var k = key_(r.form, r.sub, r.unit);
    var L = tbl_('MASTER', 'Locks'); var l = L.find('key', k);
    if (l && l.email !== c.user.email && !expired_(l)) {
      if (r.force && ['Koordinator', 'SuperAdmin'].indexOf(c.user.role) >= 0) {
        audit_(c.user.email, 'lock.force', k, 'dari ' + l.email); L.remove(l);
        notify_(l.email, c.user, r.form, r.sub, r.unit, 'Kunci unit ' + r.unit + ' dilepas oleh koordinator. Draf Anda tetap tersimpan di perangkat.');
      } else return { ok: false, holder: lockOut_(l) };
    }
    if (l) L.remove(l);
    var t = now_();
    L.append({ key: k, email: c.user.email, name: c.user.name, since: t, last_beat: t, last_act: t });
    return { ok: true };
  } },

  'rec.unlock': { write: true, fn: function (r, c) {
    var L = tbl_('MASTER', 'Locks'); var l = L.find('key', key_(r.form, r.sub, r.unit));
    if (l && (l.email === c.user.email || ['Koordinator', 'SuperAdmin'].indexOf(c.user.role) >= 0)) L.remove(l);
    return true;
  } },

  'rec.save': { write: true, fn: function (r, c) { return recSave_(r, c.user); } },

  'rec.review': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var T = recTbl_(r.form, r.sub); var row = T.find('unit', r.unit);
    if (!row) throw err_('Rekaman belum ada');
    var upd = { version: Number(row.version || 0) + 1, updated_by: c.user.email, updated_name: c.user.name, updated_at: now_() };
    var msg;
    if (r.decision === 'return') {
      if (!r.note) throw err_('Catatan wajib diisi saat mengembalikan');
      upd.status = STATUS.RETURNED; upd.return_note = clean_(r.note, 2000);
      msg = 'Dikembalikan untuk dicek ulang: ' + upd.return_note;
    } else if (r.decision === 'validate') {
      if (row.status !== STATUS.SENT) throw err_('Hanya rekaman berstatus Dikirim yang dapat divalidasi');
      upd.status = STATUS.VALID; upd.validated_by = c.user.email; upd.validated_at = now_(); upd.return_note = '';
      msg = 'Dinyatakan Valid';
    } else if (r.decision === 'reopen') {
      upd.status = STATUS.RETURNED; upd.return_note = clean_(r.note || 'Dibuka kembali oleh koordinator', 2000);
      upd.validated_by = ''; upd.validated_at = ''; msg = 'Dibuka kembali: ' + upd.return_note;
    } else throw err_('Keputusan tidak dikenal');
    T.update(row, upd);
    history_(r.form, r.sub, r.unit, c.user.email, 'review:' + r.decision, upd.status, upd.version, r.note || '', null);
    audit_(c.user.email, 'rec.review', key_(r.form, r.sub, r.unit), r.decision);
    var targets = {}; [row.owner, row.updated_by].forEach(function (e) { if (e && e !== c.user.email) targets[e] = 1; });
    Object.keys(targets).forEach(function (e) { notify_(e, c.user, r.form, r.sub, r.unit, msg); });
    return recOut_(T.find('unit', r.unit));
  } },

  'rec.history': { roles: ['Koordinator', 'SuperAdmin', 'Enumerator'], fn: function (r) {
    return tbl_(r.form, 'Riwayat').rows.filter(function (h) { return h.unit === r.unit && h.sub === r.sub; })
      .map(function (h) { return { ts: h.ts, email: h.email, action: h.action, status: h.status, version: h.version, note: h.note }; }).reverse();
  } },

  /** semua rekaman satu formulir (untuk Dashboard Progress & tabel isian) */
  'rec.table': { fn: function (r, c) {
    var subs = r.sub ? [r.sub] : SUBS[r.form] || [];
    var out = {};
    subs.forEach(function (s) {
      var rows = recTbl_(r.form, s).rows.map(recOut_);
      if (c.user.role === 'Pembaca' || r.validOnly) rows = rows.filter(function (x) { return x.status === STATUS.VALID; });
      if (c.user.role === 'Pembaca') rows = rows.map(anonymize_);
      if (r.form === 'C6' && s === 'C6B') rows = rows.filter(function (x) { return !isPen2_(x.unit, c.user.email); });
      out[s] = rows;
    });
    return out;
  } },

  /** data valid untuk Dashboard Analisis */
  'analysis.data': { fn: function (r, c) {
    var out = {};
    (r.forms || ['C1', 'C3', 'C4', 'C5', 'C6', 'C7']).forEach(function (f) {
      out[f] = {};
      (SUBS[f] || []).forEach(function (s) {
        var rows = recTbl_(f, s).rows.map(recOut_).filter(function (x) { return x.status === STATUS.VALID; });
        if (c.user.role === 'Pembaca') rows = rows.map(anonymize_);
        out[f][s] = rows;
      });
    });
    out.C2 = c2Summary_(c.user.role === 'Pembaca');
    return out;
  } },

  'conflict.list': { roles: ['Koordinator', 'SuperAdmin'], fn: function () {
    return tbl_('MASTER', 'Konflik').rows.filter(function (x) { return x.status !== 'Selesai'; }).map(function (x) {
      var o = {}; Object.keys(x).forEach(function (k) { if (k !== '_data' && k !== '_row') o[k] = x[k]; }); return o; });
  } },
  'conflict.get': { roles: ['Koordinator', 'SuperAdmin'], fn: function (r) {
    var x = tbl_('MASTER', 'Konflik').find('id', r.id); if (!x) throw err_('Tidak ditemukan');
    return { meta: x, data: JSON.parse(x._data || '{}') };
  } },
  'conflict.resolve': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var K = tbl_('MASTER', 'Konflik'); var x = K.find('id', r.id); if (!x) throw err_('Tidak ditemukan');
    if (r.use) {
      var T = recTbl_(x.form, x.sub); var row = T.find('unit', x.unit);
      var data = JSON.parse(x._data || '{}');
      writeRec_(x.form, x.sub, x.unit, row, data, { status: row ? row.status : STATUS.DRAFT, user: c.user, action: 'konflik:pakai' });
    }
    K.update(x, { status: 'Selesai' }); audit_(c.user.email, 'conflict.resolve', r.id, r.use ? 'pakai' : 'abaikan');
    return true;
  } },

  /* ------------------------------ photos */
  'photo.upload': { roles: ['Enumerator', 'Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    if (!r.b64 || r.b64.length > 4 * 1024 * 1024) throw err_('Foto kosong atau terlalu besar (maks ±3 MB)');
    if (r.confirmNoId !== true) throw err_('Konfirmasi bahwa nama/NIK tidak terlihat wajib dicentang');
    var blob = Utilities.newBlob(Utilities.base64Decode(r.b64), 'image/jpeg', safeName_(r.form + '_' + r.sub + '_' + r.unit + '_' + Date.now() + '.jpg'));
    var file = DriveApp.getFolderById(prop_('PHOTOS')).createFile(blob);
    file.setDescription('Diunggah oleh ' + c.user.email + ' ' + now_() + ' | ' + clean_(r.caption, 200));
    audit_(c.user.email, 'photo.upload', key_(r.form, r.sub, r.unit), file.getId());
    return { id: file.getId(), name: file.getName(), ts: now_(), by: c.user.name };
  } },
  'photo.get': { fn: function (r, c) {
    if (c.user.role === 'Pembaca') throw err_('Akses ditolak');
    var file = DriveApp.getFileById(r.id);
    if (file.getParents().next().getId() !== prop_('PHOTOS')) throw err_('Akses ditolak');
    return { b64: Utilities.base64Encode(file.getBlob().getBytes()), mime: file.getMimeType() };
  } },

  /* ------------------------------ C2: kerangka, undian, pilihan */
  'c2.get': { fn: function (r, c) {
    if (c.user.role === 'Pembaca') throw err_('Akses ditolak');
    return c2Get_(r.fac);
  } },
  'c2.overview': { fn: function (r, c) { return c2Summary_(c.user.role === 'Pembaca'); } },
  'c2.upload': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    uploadFrame_(r.fac, r.frame, r.rows, r.newVersion, r.reason, c.user);
    c6AutoFromC2_(r.fac, c.user); c5AutoFromC2_(r.fac, c.user);
    return c2Get_(r.fac);
  } },
  /** unggah satu berkas C2a: lembar A_TBHIV, B_ARV, CP3_TB sekaligus; lalu otomatis isi calon C6 dan daftar sentinel C5 */
  'c2.uploadAll': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var fac = facByCode_(r.fac); if (!fac) throw err_('Fasyankes tidak dikenal');
    var rep = { frames: {}, c6: null, c5: null };
    ['A', 'B', 'CP3'].forEach(function (fr) {
      var rows = (r.frames || {})[fr];
      if (!rows) { rep.frames[fr] = 'tidak ada lembar'; return; }
      var D = tbl_('C2', 'Undian'); var d = D.rows.filter(function (x) { return x.fac === r.fac && x.frame === fr; })[0];
      if (d && d.tanggal_undian && !r.newVersion) { rep.frames[fr] = 'dilewati: undian sudah dilakukan ' + fmtTime_(d.tanggal_undian); return; }
      var n = uploadFrame_(r.fac, fr, rows, r.newVersion, r.reason, c.user);
      rep.frames[fr] = n + ' baris diunggah';
    });
    rep.c6 = c6AutoFromC2_(r.fac, c.user);
    rep.c5 = c5AutoFromC2_(r.fac, c.user);
    return { c2: c2Get_(r.fac), report: rep };
  } },
  'c5.fromC2': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) { return c5AutoFromC2_(r.fac, c.user, true); } },
  'c2.draw': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var D = tbl_('C2', 'Undian'); var d = D.rows.filter(function (x) { return x.fac === r.fac && x.frame === r.frame; })[0];
    if (!d) throw err_('Unggah kerangka terlebih dahulu');
    if (d.tanggal_undian) throw err_('Undian sudah dilakukan');
    var fac = facByCode_(r.fac);
    var per = JSON.parse(cfg_('perluasan') || '{}')[kkByCode_(fac.kk).prov] || 'Tidak';
    D.update(d, { tanggal_undian: now_(), oleh: c.user.email, perluasan: per, rekap: r.rekap === undefined ? d.rekap : r.rekap,
                  U: SEED.angka_acak[fac.kk + '|' + fac.slot + '|' + r.frame] });
    audit_(c.user.email, 'c2.draw', r.fac + '|' + r.frame, 'perluasan ' + per);
    c5AutoFromC2_(r.fac, c.user);
    return c2Get_(r.fac);
  } },
  'c2.rekap': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var D = tbl_('C2', 'Undian'); var d = D.rows.filter(function (x) { return x.fac === r.fac && x.frame === r.frame; })[0];
    if (!d) throw err_('Unggah kerangka terlebih dahulu');
    D.update(d, { rekap: r.rekap }); return c2Get_(r.fac);
  } },
  'c2.update': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var K = tbl_('C2', 'Kerangka'); var x = K.find('id', r.id); if (!x) throw err_('Baris tidak ditemukan');
    var allowed = ['pilihan', 'alasan', 'keterangan', 'akses', 'telaah', 'diganti', 'catatan'];
    var upd = {};
    allowed.forEach(function (k) { if (r.fields && r.fields[k] !== undefined) upd['s_' + k] = clean_(r.fields[k], 500); });
    if (upd.s_pilihan && /purposif|Pengganti purposif/i.test(upd.s_pilihan) && !(upd.s_alasan || x.s_alasan)) throw err_('Alasan purposif wajib diisi');
    K.update(x, upd);
    audit_(c.user.email, 'c2.update', r.id, JSON.stringify(upd));
    return c2Get_(x.fac);
  } },

  /* ------------------------------ C6 calon */
  'c6.calon': { fn: function (r, c) {
    if (c.user.role === 'Pembaca') throw err_('Akses ditolak');
    return calonList_();
  } },
  'c6.calon.save': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var C = tbl_('C2', 'Calon_C6');
    var x = r.row || {};
    var cur = x.id ? C.find('id', x.id) : null;
    if (!cur && x.kode_pasien) cur = C.find('kode_pasien', clean_(x.kode_pasien, 300)) || null;   // calon otomatis dari C2a dengan kode pasien sama → diperbarui, bukan diduplikasi
    var o = {};
    ['kk', 'fasyankes', 'kode_calon', 'kode_pasien', 'sumber', 'reg_rs', 'duplikasi', 'tb', 'hiv', 'mati', 'tgl_mati', 'kecukupan', 'dipilih', 'alasan',
     'kode_unit_c3', 'status', 'alasan_gagal', 'duplikat_dari', 'pen1', 'pen2'].forEach(function (k) { if (x[k] !== undefined) o[k] = clean_(x[k], 300); });
    if (o.pen1) o.pen1 = normEmail_(o.pen1); if (o.pen2) o.pen2 = normEmail_(o.pen2);
    if (o.pen1 && o.pen2 && o.pen1 === o.pen2) throw err_('Penelaah 1 dan 2 harus berbeda');
    o.updated_by = c.user.email; o.updated_at = now_();
    var merged = cur ? Object.assign({}, cur, o) : o;
    if (merged.dipilih === 'Ya') {
      var el = calonEligible_(merged);
      if (el !== 'Ya') throw err_('Calon belum memenuhi syarat: periksa duplikasi, dokumentasi TB/HIV, kematian terkonfirmasi, dan periode');
      if (!merged.kode_kasus) merged.kode_kasus = o.kode_kasus = nextCaseCode_(merged.kk, C);
    }
    if (cur) C.update(cur, o); else { o.id = Utilities.getUuid().slice(0, 8); if (!o.kode_calon) o.kode_calon = nextCalonCode_(o.kk, C); C.append(o); }
    audit_(c.user.email, 'c6.calon.save', o.kode_calon || (cur && cur.kode_calon), JSON.stringify(o).slice(0, 300));
    return calonList_();
  } },

  /* ------------------------------ C5 daftar sistem */
  'c5.upload': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var sub = { '5': 'C5_5', '6': 'C5_6', '41a': 'C5_41a' }[r.ind]; if (!sub) throw err_('Indikator tidak dikenal');
    var fac = facByCode_(r.fac); if (!fac || fac.sentinel !== 'Ya') throw err_('Fasyankes bukan sentinel');
    var k = key_('C5', sub, r.fac); var l = lockInfo_(k);
    if (l && l.email !== c.user.email) throw err_('Unit sedang dikerjakan ' + l.name + '. Coba lagi setelah kunci lepas.');
    var T = recTbl_('C5', sub); var row = T.find('unit', r.fac);
    var data = row ? recData_(row) : {};
    data.cocok = data.cocok || [];
    var have = {}; data.cocok.forEach(function (x) { have[x.kode_baris] = 1; });
    var added = 0;
    (r.rows || []).forEach(function (x) {
      if (!x.kode_baris || have[x.kode_baris]) return;
      var o = { asal: x.asal || 'Daftar sistem', ada_sistem: 'Ya' };
      Object.keys(x).forEach(function (kk) { o[kk] = clean_(x[kk], 200); });
      data.cocok.push(o); have[x.kode_baris] = 1; added++;
    });
    writeRec_('C5', sub, r.fac, row, data, { status: row ? row.status : STATUS.DRAFT, user: c.user, action: 'unggah daftar sistem (' + added + ' baris)' });
    return { added: added, total: data.cocok.length };
  } },

  /* ------------------------------ C1 impor dari templat */
  'c1.import': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var T = recTbl_('C1', 'C1'); var res = [];
    Object.keys(r.byKK || {}).forEach(function (kk) {
      if (!kkByCode_(kk)) { res.push(kk + ': kode tidak dikenal'); return; }
      var l = lockInfo_(key_('C1', 'C1', kk));
      if (l && l.email !== c.user.email) { res.push(kk + ': dilewati, sedang dikerjakan ' + l.name); return; }
      var row = T.find('unit', kk); var data = row ? recData_(row) : {};
      if (row && row.status === STATUS.VALID) { res.push(kk + ': dilewati, sudah Valid'); return; }
      var inc = r.byKK[kk];
      Object.keys(inc).forEach(function (k) { data[k] = inc[k]; });
      writeRec_('C1', 'C1', kk, row, data, { status: row ? row.status : STATUS.DRAFT, user: c.user, action: 'impor templat C1' });
      res.push(kk + ': diperbarui');
    });
    return res;
  } },

  /* ------------------------------ C7 sesi */
  'c7.addSession': { roles: ['Koordinator', 'SuperAdmin'], write: true, fn: function (r, c) {
    var S = tbl_('C2', 'Sesi_C7');
    var code = clean_(r.code, 20).toUpperCase(); if (!/^[A-Z]{3}-[WF]\d+$/.test(code)) throw err_('Format kode sesi: PRV-W6 atau PRV-F3');
    if (S.find('code', code)) throw err_('Kode sesi sudah ada');
    S.append({ code: code, kk: clean_(r.kk, 10), prov: code.split('-')[0], target: clean_(r.target, 300), tambahan: 'Ya', catatan: clean_(r.catatan, 300), updated_by: c.user.email, updated_at: now_() });
    audit_(c.user.email, 'c7.addSession', code, ''); return true;
  } },

  /* ------------------------------ ekspor */
  'export.form': { roles: ['Koordinator', 'SuperAdmin'], fn: function (r, c) {
    audit_(c.user.email, 'export', r.form, '');
    if (r.form === 'C2') {
      return { Kerangka: tbl_('C2', 'Kerangka').rows.map(strip_), Undian: tbl_('C2', 'Undian').rows.map(strip_), Calon_C6: tbl_('C2', 'Calon_C6').rows.map(strip_),
               Sesi_C7: tbl_('C2', 'Sesi_C7').rows.map(strip_), Terpilih: c2SelectedAll_() };
    }
    if (r.form === 'MASTER') return { Users: tbl_('MASTER', 'Users').rows.map(publicUser_), Audit: tbl_('MASTER', 'Audit').rows.map(strip_) };
    var out = {};
    (SUBS[r.form] || []).forEach(function (s) { out[s] = recTbl_(r.form, s).rows.map(recOut_); });
    return out;
  } }
};

/* ============================================================ RECORDS */
function recTbl_(form, sub) {
  var heads = REC_BASE.slice();
  for (var i = 1; i <= APP.DATA_CHUNKS; i++) heads.push('_data' + i);
  return tbl_(form, sub, heads);
}
function recData_(row) {
  var s = '';
  for (var i = 1; i <= APP.DATA_CHUNKS; i++) { var v = row['_data' + i]; if (v) s += String(v).replace(/^J/, ''); }
  if (!s) return {};
  try { return JSON.parse(s); } catch (e) { return { _parseError: true }; }
}
function recOut_(row) {
  var o = {};
  REC_BASE.forEach(function (k) { o[k] = row[k] === undefined ? '' : row[k]; });
  o.version = Number(o.version || 0);
  o.data = recData_(row);
  return o;
}
function recSave_(r, user) {
  if (['Enumerator', 'Koordinator', 'SuperAdmin'].indexOf(user.role) < 0) throw err_('Peran ini tidak dapat mengisi formulir');
  if ((SUBS[r.form] || []).indexOf(r.sub) < 0) throw err_('Sub-formulir tidak dikenal');
  checkBlind_(r.form, r.sub, r.unit, user);
  if (r.sub === 'C6P' && ['Koordinator', 'SuperAdmin'].indexOf(user.role) < 0) throw err_('Lembar panel diisi koordinator WP5');
  var k = key_(r.form, r.sub, r.unit);
  var T = recTbl_(r.form, r.sub); var row = T.find('unit', r.unit);
  var L = tbl_('MASTER', 'Locks'); var l = L.find('key', k);
  var conflict = null;
  if (l && l.email !== user.email && !expired_(l)) conflict = 'Unit sedang dikerjakan ' + l.name;
  else if (row && Number(row.version || 0) > Number(r.baseVersion || 0) && row.updated_by !== user.email) conflict = 'Versi di server lebih baru (diubah ' + row.updated_name + ' ' + fmtTime_(row.updated_at) + ')';
  if (row && (row.status === STATUS.VALID || row.status === STATUS.SENT) && ['Koordinator', 'SuperAdmin'].indexOf(user.role) < 0)
    conflict = conflict || ('Rekaman berstatus ' + row.status + '; perubahan memerlukan pengembalian oleh koordinator');
  if (conflict) {
    var id = Utilities.getUuid().slice(0, 8);
    tbl_('MASTER', 'Konflik').append({ id: id, ts: now_(), form: r.form, sub: r.sub, unit: r.unit, email: user.email, name: user.name, reason: conflict,
      base_version: r.baseVersion || 0, server_version: row ? row.version : 0, status: 'Terbuka', _data: 'J' + JSON.stringify(r.data || {}) });
    audit_(user.email, 'rec.conflict', k, conflict);
    notifyCoords_(user, r.form, r.sub, r.unit, 'Versi cadangan dari ' + user.name + ' disimpan sebagai konflik: ' + conflict);
    return { conflict: true, id: id, message: conflict + '. Isian Anda disimpan sebagai versi cadangan untuk dipilih koordinator.' };
  }
  // refresh / acquire lock
  var t = now_();
  if (l) L.update(l, { last_beat: t, last_act: t }); else L.append({ key: k, email: user.email, name: user.name, since: t, last_beat: t, last_act: t });
  var status = row ? (row.status || STATUS.DRAFT) : STATUS.DRAFT;
  if (r.submit) {
    if (status === STATUS.VALID) throw err_('Rekaman sudah Valid');
    status = STATUS.SENT;
  }
  var saved = writeRec_(r.form, r.sub, r.unit, row, r.data || {}, { status: status, user: user, progress: r.progress, submit: !!r.submit, action: r.submit ? 'kirim' : 'simpan' });
  if (r.submit) {
    L.remove(L.find('key', k));
    notifyCoords_(user, r.form, r.sub, r.unit, user.name + ' mengirim ' + r.sub + ' ' + r.unit + ' untuk diperiksa');
  }
  return { rec: recOut_(saved) };
}
function writeRec_(form, sub, unit, row, data, o) {
  var T = recTbl_(form, sub);
  var meta = unitMeta_(form, sub, unit);
  var js = JSON.stringify(data);
  var max = APP.CHUNK * APP.DATA_CHUNKS;
  if (js.length > max) throw err_('Data terlalu besar (' + js.length + ' karakter). Kurangi lampiran teks atau pecah unit.');
  var upd = { unit: unit, sub: sub, fac: meta.fac || '', kk: meta.kk || '', prov: meta.prov || '', status: o.status,
              version: row ? Number(row.version || 0) + 1 : 1, updated_by: o.user.email, updated_name: o.user.name, updated_at: now_() };
  if (o.progress !== undefined) upd.progress = o.progress;
  if (!row || !row.owner) { upd.owner = o.user.email; upd.owner_name = o.user.name; }
  if (o.submit) { upd.submitted_at = now_(); upd.return_note = row ? row.return_note : ''; }
  for (var i = 1; i <= APP.DATA_CHUNKS; i++) {
    var part = js.substr((i - 1) * APP.CHUNK, APP.CHUNK);
    upd['_data' + i] = part ? 'J' + part : '';
  }
  // kolom datar (mudah dibaca di Spreadsheet)
  var flat = flatten_(data);
  T.ensureCols(Object.keys(flat));
  Object.keys(flat).forEach(function (kf) { upd[kf] = flat[kf]; });
  var out;
  if (row) { T.update(row, upd); out = T.find('unit', unit); }
  else { out = T.append(upd); }
  history_(form, sub, unit, o.user.email, o.action || 'simpan', o.status, upd.version, '', o.submit ? js : null);
  return out;
}
function flatten_(data) {
  var o = {};
  Object.keys(data || {}).forEach(function (k) {
    var v = data[k];
    if (k.charAt(0) === '_') return;
    if (v === null || v === undefined || v === '') return;
    if (Array.isArray(v)) {
      if (v.length && typeof v[0] === 'object') o['[tabel] ' + k] = v.length + ' baris';
      else o[k] = v.join('; ');
    } else if (typeof v === 'object') {
      Object.keys(v).forEach(function (rk) {
        var rv = v[rk];
        if (rv && typeof rv === 'object') Object.keys(rv).forEach(function (ck) {
          var cv = rv[ck]; if (cv !== '' && cv !== null && cv !== undefined) o[k + '.' + rk + '.' + ck] = Array.isArray(cv) ? cv.join('; ') : cv;
        });
      });
    } else o[k] = v;
  });
  return o;
}
function history_(form, sub, unit, email, action, status, version, note, snapshot) {
  var snap = snapshot ? 'J' + snapshot.slice(0, 48000) : '';
  tbl_(form === 'C2' ? 'C2' : form, 'Riwayat').append({ ts: now_(), sub: sub, unit: unit, email: email, action: action, status: status, version: version, note: clean_(note, 500), snapshot: snap });
}
function anonymize_(x) {
  var d = JSON.parse(JSON.stringify(x.data || {}));
  ['U01', 'U02', 'R_B', 'kode_pasien', 'kode_kasus', 'kode_unit_c3', 'kode_baris', 'kode_sesi'].forEach(function (k) { delete d[k]; });
  ['cocok', 'peserta', 'kronologi', 'sumber', 'A2', 'A5', 'foto'].forEach(function (k) { if (Array.isArray(d[k])) d[k] = d[k].map(function (r) { var o = Object.assign({}, r); delete o.kode_pasien; delete o.kode; delete o.kode_baris; return o; }); });
  return { unit: Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, x.unit)).slice(0, 8), sub: x.sub, fac: x.fac, kk: x.kk, prov: x.prov, status: x.status, data: d };
}

/* ============================================================ UNITS */
function unitsList_(form, user) {
  var R = regions_(); var units = [];
  var kkMap = {}; R.kk.forEach(function (k) { kkMap[k.code] = k; });
  var facMap = {}; R.fac.forEach(function (f) { facMap[f.code] = f; });
  function add(sub, unit, fac, kk, label, meta) {
    var k = kkMap[kk] || {}; units.push({ sub: sub, unit: unit, fac: fac || '', kk: kk || '', prov: k.prov || '', label: label, meta: meta || {} });
  }
  if (form === 'C1') R.kk.forEach(function (k) { add('C1', k.code, '', k.code, k.name, { capaian: k.capaian }); });
  if (form === 'C3') c2SelectedAll_().forEach(function (s) {
    add(FRAME_SUB[s.frame], s.kode_unit, s.fac, s.kk, s.kode_unit + ' · ' + s.pilihan, s);
  });
  if (form === 'C4') R.fac.forEach(function (f) { add('C4', f.code, f.code, f.kk, f.name, { type: f.type, sentinel: f.sentinel }); });
  if (form === 'C5') R.fac.filter(function (f) { return f.sentinel === 'Ya'; }).forEach(function (f) {
    SUBS.C5.forEach(function (s) { add(s, f.code, f.code, f.kk, f.name); });
  });
  if (form === 'C6') {
    var need = c6SecondReview_();
    calonList_().filter(function (x) { return x.dipilih === 'Ya' && x.kode_kasus; }).forEach(function (x) {
      var fac = facMap[x.fasyankes] || {};
      var meta = { kode_pasien: x.kode_pasien, kode_unit_c3: x.kode_unit_c3, pen1: x.pen1, pen2: x.pen2, second: need[x.kode_kasus] || '' };
      SUBS.C6.forEach(function (s) {
        if (s === 'C6C' && !(need[x.kode_kasus] || '').match(/^(Wajib|Ya)/)) return;
        if (s === 'C6B' && x.pen2 === user.email) return;
        if (s === 'C6C' && x.pen1 === user.email) return;
        add(s, x.kode_kasus, x.fasyankes, x.kk || fac.kk, x.kode_kasus + (x.kode_unit_c3 ? ' · C3 ' + x.kode_unit_c3 : ''), meta);
      });
    });
  }
  if (form === 'C7') {
    tbl_('C2', 'Sesi_C7').rows.forEach(function (s) { add('C7S', s.code, '', /^[A-Z]{3}$/.test(s.kk) ? s.kk : '', s.code + ' · ' + s.target, { target: s.target, prov7: s.prov, kk7: s.kk }); });
    R.kk.forEach(function (k) { add('C7K', k.code, '', k.code, 'Cakupan ' + k.name); });
  }
  // join status & locks
  var recs = {};
  (SUBS[form] || []).forEach(function (s) { recTbl_(form, s).rows.forEach(function (row) {
    recs[s + '|' + row.unit] = { status: row.status, version: Number(row.version || 0), updated_name: row.updated_name, updated_at: row.updated_at,
      owner_name: row.owner_name, progress: row.progress, return_note: row.return_note, validated_at: row.validated_at }; }); });
  var locks = {}; tbl_('MASTER', 'Locks').rows.forEach(function (l) { if (!expired_(l)) locks[l.key] = lockOut_(l); });
  units.forEach(function (u) {
    var rr = recs[u.sub + '|' + u.unit]; u.rec = rr || null; u.status = rr ? rr.status : 'Belum';
    u.lock = locks[key_(form, u.sub, u.unit)] || null;
  });
  if (user.role === 'Pembaca') units.forEach(function (u) { u.lock = u.lock ? { active: true } : null; u.meta = {}; });
  return units;
}
function unitMeta_(form, sub, unit) {
  var R = regions_();
  var kkOf = function (kk) { var k = R.kk.filter(function (x) { return x.code === kk; })[0]; return k ? k.prov : ''; };
  if (form === 'C1' || sub === 'C7K') return { kk: unit, prov: kkOf(unit) };
  if (form === 'C4' || form === 'C5') { var f = facByCode_(unit) || {}; return { fac: unit, kk: f.kk, prov: kkOf(f.kk) }; }
  if (form === 'C3') { var s = c2SelectedAll_().filter(function (x) { return x.kode_unit === unit; })[0] || {}; return { fac: s.fac, kk: s.kk, prov: kkOf(s.kk) }; }
  if (form === 'C6') { var c = calonList_().filter(function (x) { return x.kode_kasus === unit; })[0] || {}; return { fac: c.fasyankes, kk: c.kk, prov: kkOf(c.kk) }; }
  if (sub === 'C7S') { var ss = tbl_('C2', 'Sesi_C7').find('code', unit) || {}; return { kk: /^[A-Z]{3}$/.test(ss.kk) ? ss.kk : '', prov: ss.prov }; }
  return {};
}
function related_(form, sub, unit, user) {
  var o = {};
  if (form === 'C5' && sub !== 'C5ID') { var r = recTbl_('C5', 'C5ID').find('unit', unit); o.C5ID = r ? recData_(r) : {}; }
  if (form === 'C6' && (sub === 'C6B' || sub === 'C6C' || sub === 'C6P')) { var a = recTbl_('C6', 'C6A').find('unit', unit); o.C6A = a ? recData_(a) : {}; }
  if (form === 'C6' && sub === 'C6P') {
    var b = recTbl_('C6', 'C6B').find('unit', unit), cc = recTbl_('C6', 'C6C').find('unit', unit);
    o.C6B = b ? recData_(b) : {}; o.C6C = cc ? recData_(cc) : {};
  }
  if (form === 'C6') {
    var cal = calonList_().filter(function (x) { return x.kode_kasus === unit; })[0];
    if (cal && cal.kode_unit_c3) { // pakai kembali fakta C3 bila kasus sama
      var sel = c2SelectedAll_().filter(function (x) { return x.kode_unit === cal.kode_unit_c3; })[0];
      if (sel) { var cr = recTbl_('C3', FRAME_SUB[sel.frame]).find('unit', cal.kode_unit_c3); o.C3 = cr ? { sub: FRAME_SUB[sel.frame], data: recData_(cr) } : null; }
    }
    o.calon = cal || null;
  }
  if (form === 'C4') {
    var c1 = recTbl_('C1', 'C1').find('unit', (facByCode_(unit) || {}).kk); o.C1 = c1 ? recData_(c1) : {};
    o.C3 = {}; ['C3A', 'C3B', 'C3CP3'].forEach(function (s) {
      o.C3[s] = recTbl_('C3', s).rows.filter(function (x) { return x.fac === unit && (x.status === STATUS.VALID || x.status === STATUS.SENT); }).map(recOut_);
    });
  }
  if (form === 'C3') { var sx = c2SelectedAll_().filter(function (x) { return x.kode_unit === unit; })[0]; o.unit = sx || null; }
  return o;
}
function checkBlind_(form, sub, unit, user) {
  if (form !== 'C6') return;
  var cal = calonList_().filter(function (x) { return x.kode_kasus === unit; })[0];
  if (!cal) return;
  if (sub === 'C6B' && cal.pen2 && cal.pen2 === user.email) throw err_('Penilaian pertama disembunyikan untuk penelaah kedua (penilaian tersamar)');
  if (sub === 'C6C' && cal.pen1 && cal.pen1 === user.email) throw err_('Penelaah pertama tidak mengisi penilaian kedua');
  if (sub === 'C6C' && cal.pen2 && cal.pen2 !== user.email && ['Koordinator', 'SuperAdmin'].indexOf(user.role) < 0) throw err_('Lembar penilaian kedua hanya untuk penelaah kedua yang ditugaskan');
}
function isPen2_(unit, email) {
  var cal = calonList_().filter(function (x) { return x.kode_kasus === unit; })[0];
  return !!(cal && cal.pen2 && cal.pen2 === email);
}

/* ============================================================ C2 LOGIC (port Excel C2b) */
var C2_COLS = ['id', 'fac', 'kk', 'frame', 'no', 'c_B', 'c_C', 'c_D', 'c_E', 'c_F', 'c_G', 'c_H', 'c_I', 'c_J', 'c_K', 'c_L', 'c_M', 'c_N', 'c_O',
               's_pilihan', 's_alasan', 's_keterangan', 's_akses', 's_telaah', 's_diganti', 's_catatan'];
function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return v;
  var s = String(v).trim(), m;
  if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})/))) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  if ((m = s.match(/^(\d{4})[\/.](\d{1,2})[\/.](\d{1,2})$/))) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  if ((m = s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2}|\d{4})$/))) return new Date(Date.UTC(m[3].length === 2 ? 2000 + Number(m[3]) : +m[3], +m[2] - 1, +m[1]));
  if (/^\d{5}$/.test(s)) return new Date(Date.UTC(1899, 11, 30) + Number(s) * 86400000);
  return null;
}
function ymd_(d) { return d ? d.toISOString().slice(0, 10) : ''; }
function periode_(frame, x) {
  if (frame === 'B' && x.c_G === 'ODHIV lama (sebelum 2025)') return 'ODHIV lama';
  var d = toDate_(x.c_F);
  if (!x.c_F) return 'Tanggal kosong';
  if (!d) return 'Format tanggal salah';
  var y = d.getUTCFullYear();
  if (y === 2025) return '2025';
  if (d >= new Date(Date.UTC(2026, 0, 1)) && d <= new Date(Date.UTC(2026, 5, 30))) return 'Tambahan 2026';
  return 'Di luar periode';
}
function layak_(frame, x, per) {
  if (!x.c_C || per !== '2025') return 0;
  if (frame === 'B') return (x.c_G === 'Baru pertama kali ARV' || x.c_G === 'Belum pasti') ? 1 : 0;
  if (frame === 'CP3') return (x.c_I === 'Positif' || x.c_I === 'Negatif') ? 1 : 0;
  return 1;
}
function frac_(v) { return v - Math.floor(v); }
function c2Compute_(fac, frame, rows, und, perluasan) {
  var U = und && und.tanggal_undian ? Number(und.U) : null;
  rows.forEach(function (x) { x.periode = periode_(frame, x); x.layak = layak_(frame, x, x.periode); x._d = toDate_(x.c_F); });
  var el = rows.filter(function (x) { return x.layak; });
  el.sort(function (a, b) { var d = (a._d - b._d); return d !== 0 ? d : String(a.c_C).localeCompare(String(b.c_C)); });
  el.forEach(function (x, i) { x.no_urut = i + 1; });
  var N = el.length;
  var n2025 = rows.filter(function (x) { return x.periode === '2025'; }).length;
  var sensus = frame !== 'CP3' && rows.length > 0 && n2025 <= 6;
  var P = {};
  var ceil = function (v) { return Math.max(1, Math.ceil(Math.round(v * 1e9) / 1e9)); };
  if (U !== null && !sensus && N >= 4) {
    P = { P1: ceil((U + 0) * N / 3), P2: ceil((frac_(U + 0.5) + 0) * N / 3), P3: ceil((U + 1) * N / 3), P4: ceil((frac_(U + 0.5) + 1) * N / 3),
          P5: ceil((U + 2) * N / 3), P6: ceil((frac_(U + 0.5) + 2) * N / 3),
          P7: ceil((frac_(U + 0.25) + 0) * N / 3), P8: ceil((frac_(U + 0.75) + 0) * N / 3), P9: ceil((frac_(U + 0.25) + 1) * N / 3),
          P10: ceil((frac_(U + 0.75) + 1) * N / 3), P11: ceil((frac_(U + 0.25) + 2) * N / 3), P12: ceil((frac_(U + 0.75) + 2) * N / 3) };
  }
  var cad = [P.P7, P.P8, P.P9, P.P10, P.P11, P.P12];
  rows.forEach(function (x) {
    var a = '';
    if (!x.c_C) a = '';
    else if (sensus && und && und.tanggal_undian && x.periode === '2025') a = 'Sensus';
    else if (x.layak && U !== null) {
      if (N <= 3) a = 'Acak inti';
      else if ([P.P1, P.P3, P.P5].indexOf(x.no_urut) >= 0) a = 'Acak inti';
      else if ([P.P2, P.P4, P.P6].indexOf(x.no_urut) >= 0) {
        a = (perluasan === 'Ya' && frame !== 'CP3' && N >= 6) ? 'Acak perluasan' : 'Cadangan acak ' + (x.no_urut === P.P2 ? 1 : x.no_urut === P.P4 ? 2 : 3);
      } else if (cad.indexOf(x.no_urut) >= 0) a = 'Cadangan acak ' + (3 + cad.indexOf(x.no_urut) + 1);
    }
    x.acak = a;
    var isi = x.s_pilihan || '';
    var st = (a.indexOf('Cadangan') === 0 && isi) ? isi : (a && isi ? 'Cek: ganda acak dan isian' : (a || isi));
    x.status_pilih = st;
    x.terpilih = (st && st.indexOf('Cadangan') !== 0 && st.indexOf('Cek:') !== 0) ? 1 : 0;
    x.kode_unit = x.terpilih ? fac + '-' + x.c_C : '';
    x.penanda = penanda_(frame, x);
  });
  return { N: N, n2025: n2025, ntambah: rows.filter(function (x) { return x.periode === 'Tambahan 2026'; }).length, sensus: sensus, P: P, U: U };
}
function penanda_(frame, x) {
  var s = '';
  if (frame === 'A') {
    var batas = x.c_H === 'TB RO' ? 56 : 14, g = toDate_(x.c_G), k = toDate_(x.c_K);
    var lewat = x.c_J === 'Mulai ARV selama pengobatan TB' && g && k && (k - g) / 86400000 > batas;
    if (['Belum ARV', 'Tidak diketahui', ''].indexOf(x.c_J || '') >= 0) s += 'ARV belum/tidak tercatat; ';
    if (lewat) s += 'ARV melewati batas juknis; ';
    if (x.c_F && !g) s += 'OAT belum tercatat dimulai; ';
    if (['Meninggal', 'Putus berobat', 'Gagal', 'Tidak dievaluasi'].indexOf(x.c_L) >= 0) s += 'Luaran ' + x.c_L + '; ';
    if (['Sembuh', 'Pengobatan lengkap'].indexOf(x.c_L) >= 0 && ['Sudah ARV sebelum TB', 'Mulai ARV selama pengobatan TB'].indexOf(x.c_J) >= 0 && !lewat) s += 'Kandidat praktik baik; ';
  } else if (frame === 'B') {
    if (x.c_H === 'Tidak tercatat') s += 'Skrining TB tidak tercatat; ';
    if (x.c_I !== 'Ya' && ['Tidak mulai', 'Tidak diketahui'].indexOf(x.c_J) >= 0) s += 'TPT tidak dimulai; ';
    if (['Putus', 'Berhenti (efek samping/TB)'].indexOf(x.c_L) >= 0) s += 'TPT tidak selesai; ';
    if (['Putus (LFU)', 'Meninggal', 'Berhenti'].indexOf(x.c_M) >= 0) s += 'ARV ' + x.c_M + '; ';
    if (x.c_I === 'Ya') s += 'TB aktif terdiagnosis; ';
    if (x.c_G === 'Belum pasti') s += 'Status inisiasi belum pasti; ';
    if (x.c_L === 'Lengkap' && x.c_M === 'Masih ARV') s += 'Kandidat praktik baik; ';
  } else {
    if (['Tidak diketahui', 'Kosong', ''].indexOf(x.c_I || '') >= 0) s += 'Status HIV tidak diketahui/kosong; ';
    if (x.c_I === 'Positif') s += 'HIV positif: cek kerangka A; ';
  }
  return s;
}
function c2Get_(facCode) {
  var fac = facByCode_(facCode); if (!fac) throw err_('Fasyankes tidak dikenal');
  var per = JSON.parse(cfg_('perluasan') || '{}')[kkByCode_(fac.kk).prov] || 'Tidak';
  var K = tbl_('C2', 'Kerangka').rows.filter(function (x) { return x.fac === facCode; });
  var D = tbl_('C2', 'Undian').rows.filter(function (x) { return x.fac === facCode; });
  var out = { fac: fac, perluasan: per, frames: {} };
  ['A', 'B', 'CP3'].forEach(function (fr) {
    var rows = K.filter(function (x) { return x.frame === fr; }).map(strip_);
    rows.sort(function (a, b) { return Number(a.no) - Number(b.no); });
    var und = D.filter(function (x) { return x.frame === fr; })[0] || null;
    var info = c2Compute_(facCode, fr, rows, und, und && und.perluasan || per);
    // pasien terpilih di kerangka lain
    out.frames[fr] = { rows: rows.map(function (x) { delete x._d; return x; }), und: und ? strip_(und) : null, info: info,
                       Ukey: fac.kk + '|' + fac.slot + '|' + fr, Useed: SEED.angka_acak[fac.kk + '|' + fac.slot + '|' + fr] };
  });
  var selA = {}; out.frames.A.rows.forEach(function (x) { if (x.terpilih) selA[x.c_B] = 1; });
  var selB = {}; out.frames.B.rows.forEach(function (x) { if (x.terpilih) selB[x.c_B] = 1; });
  ['A', 'B', 'CP3'].forEach(function (fr) {
    var codes = {}; out.frames[fr].rows.forEach(function (x) { codes[x.c_C] = (codes[x.c_C] || 0) + 1; });
    out.frames[fr].rows.forEach(function (x) {
      var cek = '';
      if (codes[x.c_C] > 1) cek += 'Kode ganda; ';
      if (!x.c_B) cek += 'Kode pasien kosong; ';
      if (x.periode !== '2025') cek += 'Periode: ' + x.periode + '; ';
      if (x.terpilih && (fr === 'B' ? selA[x.c_B] : (fr === 'A' ? selB[x.c_B] : selA[x.c_B]))) cek += 'Pasien juga terpilih di kerangka ' + (fr === 'A' ? 'B' : 'A') + '; ';
      x.cek = cek;
    });
  });
  return out;
}
function c2SelectedAll_() {
  var K = tbl_('C2', 'Kerangka').rows; var D = tbl_('C2', 'Undian').rows;
  var per = JSON.parse(cfg_('perluasan') || '{}');
  var res = [];
  var groups = {};
  K.forEach(function (x) { var g = x.fac + '|' + x.frame; (groups[g] = groups[g] || []).push(strip_(x)); });
  Object.keys(groups).forEach(function (g) {
    var p = g.split('|'), fac = p[0], fr = p[1];
    var und = D.filter(function (x) { return x.fac === fac && x.frame === fr; })[0];
    var f = facByCode_(fac); if (!f) return;
    var rows = groups[g].sort(function (a, b) { return Number(a.no) - Number(b.no); });
    c2Compute_(fac, fr, rows, und, und && und.perluasan || per[kkByCode_(f.kk).prov] || 'Tidak');
    rows.forEach(function (x) {
      if (!x.terpilih) return;
      res.push({ kode_unit: x.kode_unit, fac: fac, kk: f.kk, frame: fr, pilihan: x.status_pilih, alasan: x.s_alasan || (x.status_pilih.match(/purposif/i) ? '' : 'Tidak berlaku (acak/sensus)'),
                 kode_pasien: x.c_B, kode_lokal: x.c_C, periode: x.periode === 'ODHIV lama' ? '2025' : x.periode, akses: x.s_akses || '', telaah: x.s_telaah || '',
                 hiv_status: fr === 'CP3' ? x.c_I : '', tb_dx: fr !== 'B' ? ymd_(toDate_(x.c_F)) : '', diganti: x.s_diganti || '',
                 petunjuk: { tgl: ymd_(toDate_(x.c_F)), jk: x.c_D || '', umur: x.c_E || '', sumber: fr === 'CP3' ? (x.c_K || '') : (x.c_N || '') } });
    });
  });
  return res;
}
function c2Summary_(anon) {
  var sel = c2SelectedAll_();
  var D = tbl_('C2', 'Undian').rows.map(strip_);
  var K = tbl_('C2', 'Kerangka').rows;
  var byFac = {};
  K.forEach(function (x) { var k = x.fac + '|' + x.frame; byFac[k] = (byFac[k] || 0) + 1; });
  var cal = calonList_();
  return {
    selected: anon ? sel.map(function (s) { return { fac: s.fac, kk: s.kk, frame: s.frame, pilihan: s.pilihan, periode: s.periode, akses: s.akses, telaah: s.telaah, alasan: s.alasan, pid: md5_(s.fac + s.kode_pasien) }; })
                   : sel.map(function (s) { s.pid = md5_(s.fac + s.kode_pasien); return s; }),
    undian: D, frameRows: byFac,
    calon: anon ? cal.map(function (c) { return { kk: c.kk, fasyankes: c.fasyankes, eligible: c.eligible, dipilih: c.dipilih, status: c.status, reg_rs: c.reg_rs, periode: c.periode }; }) : cal,
    sesi: tbl_('C2', 'Sesi_C7').rows.map(strip_)
  };
}


/* ============================================================ C2a → semua bagian C2 */
function uploadFrame_(facCode, frame, rowsIn, newVersion, reason, user) {
  var fac = facByCode_(facCode); if (!fac) throw err_('Fasyankes tidak dikenal');
  if (['A', 'B', 'CP3'].indexOf(frame) < 0) throw err_('Kerangka tidak dikenal');
  var D = tbl_('C2', 'Undian'); var d = D.rows.filter(function (x) { return x.fac === facCode && x.frame === frame; })[0];
  if (d && d.tanggal_undian && !newVersion) throw err_('Undian kerangka ' + frame + ' sudah dilakukan (' + d.tanggal_undian + '). Unggah ulang hanya sebagai versi baru dengan alasan.');
  var K = tbl_('C2', 'Kerangka');
  var keep = K.rows.filter(function (x) { return x.fac === facCode && x.frame === frame; });
  if (keep.length) K.removeMany(keep);
  var rows = (rowsIn || []).filter(function (x) { return x.C; });
  var seen = {};
  rows.forEach(function (x, i) {
    var o = { id: facCode + '|' + frame + '|' + x.C + (seen[x.C] ? '#' + i : ''), fac: facCode, kk: fac.kk, frame: frame, no: i + 1 };
    seen[x.C] = 1;
    var dc = { A: 'FGKM', B: 'FK', CP3: 'FJ' }[frame];
    'BCDEFGHIJKLMNO'.split('').forEach(function (col) {
      if (x[col] === undefined) return;
      var v = x[col];
      if (dc.indexOf(col) >= 0 && v !== '') { var dd = toDate_(v); if (dd) v = ymd_(dd); } // simpan tanggal seragam yyyy-mm-dd
      o['c_' + col] = v;
    });
    K.append(o);
  });
  var versi = d ? Number(d.versi || 1) + (newVersion ? 1 : 0) : 1;
  if (d) D.update(d, { tanggal_undian: newVersion ? '' : d.tanggal_undian, versi: versi, catatan: newVersion ? clean_(reason, 300) : d.catatan });
  else D.append({ fac: facCode, frame: frame, versi: 1 });
  audit_(user.email, 'c2.upload', facCode + '|' + frame, rows.length + ' baris');
  return rows.length;
}
/** Kematian tercatat di kerangka C2a (A: hasil akhir Meninggal; B: status ARV Meninggal) → calon C6 (belum terverifikasi). */
function c6AutoFromC2_(facCode, user) {
  var fac = facByCode_(facCode); var C = tbl_('C2', 'Calon_C6');
  var have = {}; C.rows.forEach(function (x) { if (x.kode_pasien) have[x.kode_pasien] = x; });
  var K = tbl_('C2', 'Kerangka').rows.filter(function (x) { return x.fac === facCode; });
  var added = 0, linked = 0, found = 0;
  K.forEach(function (x) {
    var dead = (x.frame === 'A' && x.c_L === 'Meninggal') || (x.frame === 'B' && x.c_M === 'Meninggal');
    if (!dead || !x.c_B) return;
    found++;
    var kp = facCode + '-' + x.c_B;
    var ref = facCode + '-' + x.c_C;
    var src = 'Kerangka C2a ' + x.frame + ' (' + x.c_C + ')';
    if (have[kp]) {
      var cur = have[kp];
      if (String(cur.asal || '').indexOf(src) < 0) { C.update(cur, { asal: (cur.asal ? cur.asal + '; ' : '') + src, ref_c2: cur.ref_c2 || ref }); linked++; }
      return;
    }
    var o = { id: Utilities.getUuid().slice(0, 8), kk: fac.kk, fasyankes: facCode, kode_pasien: kp, sumber: 'SITB/SIHA lokal',
      reg_rs: 'Tidak', duplikasi: 'Belum diperiksa', tb: x.frame === 'A' ? 'Ya' : (x.c_I === 'Ya' ? 'Ya' : 'Belum diperiksa'), hiv: 'Ya',
      mati: 'Belum diperiksa', tgl_mati: x.frame === 'A' ? ymd_(toDate_(x.c_M)) : '', kecukupan: '', dipilih: '', status: 'Belum',
      asal: 'Otomatis dari ' + src, ref_c2: ref, updated_by: user.email, updated_at: now_() };
    o.kode_calon = nextCalonCode_(fac.kk, C);
    have[kp] = C.append(o); added++;
  });
  if (added || linked) audit_(user.email, 'c6.auto', facCode, added + ' calon baru, ' + linked + ' ditautkan');
  return { kematian_terdeteksi: found, calon_baru: added, ditautkan: linked };
}
/** Fasyankes sentinel: baris kerangka C2a dalam triwulan verifikasi → daftar sistem C5 (TB/HIV-5 dari CP3_TB, -6 dari A_TBHIV, -4.1a dari B_ARV). */
function c5AutoFromC2_(facCode, user, explicit) {
  var fac = facByCode_(facCode);
  if (!fac || fac.sentinel !== 'Ya') { if (explicit) throw err_('Fasyankes ini belum ditandai sentinel'); return { status: 'bukan sentinel' }; }
  var idr = recTbl_('C5', 'C5ID').find('unit', facCode); var id = idr ? recData_(idr) : {};
  var aw = toDate_(id.tw_awal || '2025-07-01'), ak = toDate_(id.tw_akhir || '2025-09-30');
  var inP = function (v) { var d = toDate_(v); return d && d >= aw && d <= ak; };
  var sel = {}; c2SelectedAll_().forEach(function (s) { sel[s.kode_unit] = 1; });
  var K = tbl_('C2', 'Kerangka').rows.filter(function (x) { return x.fac === facCode; });
  var arvMap = function (v) { return ['Sudah ARV sebelum TB', 'Mulai ARV selama pengobatan TB', 'Belum ARV', 'Tidak diketahui'].indexOf(v) >= 0 ? v : (v ? 'Tidak diketahui' : ''); };
  var specs = { '5': { sub: 'C5_5', frame: 'CP3', src: 'c_K', map: function (x) { return { tgl_sis: ymd_(toDate_(x.c_F)), tipe_sis: x.c_H || '', hiv_sis: x.c_I || '' }; } },
                '6': { sub: 'C5_6', frame: 'A', src: 'c_N', map: function (x) { return { tgl_sis: ymd_(toDate_(x.c_F)), tipe_sis: x.c_I || '', hiv_sis: 'Positif', arv_sis: arvMap(x.c_J) }; } },
                '41a': { sub: 'C5_41a', frame: 'B', src: 'c_N', map: function (x) { return { tgl_sis: ymd_(toDate_(x.c_F)), masuk_sis: x.c_G === 'ODHIV lama (sebelum 2025)' ? '' : (x.c_G || ''), tpt_sis: ymd_(toDate_(x.c_K)) }; } } };
  var out = { periode: ymd_(aw) + ' s.d. ' + ymd_(ak), rincian: {} };
  if (!K.length) { out.catatan = 'Belum ada kerangka C2a untuk fasyankes ini. Unggah berkas C2a lebih dahulu.'; return out; }
  Object.keys(specs).forEach(function (ind) {
    var sp = specs[ind];
    var fr = K.filter(function (x) { return x.frame === sp.frame; });
    var bad = fr.filter(function (x) { return !toDate_(x.c_F); }).length;
    out.rincian[ind] = { baris_kerangka: fr.length, dalam_triwulan: fr.filter(function (x) { return inP(x.c_F); }).length, tanggal_tidak_terbaca: bad };
    var k = key_('C5', sp.sub, facCode); var l = lockInfo_(k);
    if (l && (!user || l.email !== user.email)) { out[ind] = 'dilewati: sedang dikerjakan ' + l.name; return; }
    var T = recTbl_('C5', sp.sub); var row = T.find('unit', facCode);
    var data = row ? recData_(row) : {};
    if (row && row.status === STATUS.VALID) { out[ind] = 'dilewati: sudah Valid'; return; }
    data.cocok = data.cocok || [];
    var have = {}; data.cocok.forEach(function (x) { have[x.kode_baris] = x; });
    var add = 0, link = 0;
    K.filter(function (x) { return x.frame === sp.frame && inP(x.c_F); }).forEach(function (x) {
      var kb = 'S' + ind.toUpperCase() + '-' + x.c_C, unit = facCode + '-' + x.c_C;
      if (have[kb]) { if (!have[kb].kode_unit_c3 && sel[unit]) { have[kb].kode_unit_c3 = unit; link++; } return; }
      var regOnly = /^Register/.test(x[sp.src] || '');
      var o = { kode_baris: kb, kode_pasien: x.c_B || '', kode_unit_c3: sel[unit] ? unit : '', asal: regOnly ? 'Telusur register' : 'Daftar sistem', ada_sistem: regOnly ? 'Tidak' : 'Ya' };
      var m = sp.map(x); if (regOnly) { Object.keys(m).forEach(function (kk) { o[kk.replace('_sis', '_src')] = m[kk]; }); o.ada_sumber = 'Ya'; } else Object.keys(m).forEach(function (kk) { o[kk] = m[kk]; });
      data.cocok.push(o); have[kb] = o; add++;
    });
    if (add || link || explicit) writeRec_('C5', sp.sub, facCode, row, data, { status: row ? row.status : STATUS.DRAFT, user: user || { email: 'sistem', name: 'Sistem' }, action: 'isi dari C2a (' + add + ' baris, ' + link + ' tautan C3)' });
    var rc = out.rincian[ind];
    out[ind] = add + ' baris baru, ' + link + ' tautan C3 (kerangka ' + sp.frame + ': ' + rc.baris_kerangka + ' baris, ' + rc.dalam_triwulan + ' dalam triwulan' + (rc.tanggal_tidak_terbaca ? ', ' + rc.tanggal_tidak_terbaca + ' tanggal tidak terbaca' : '') + ')';
  });
  return out;
}

/* ============================================================ C6 */
function calonEligible_(x) {
  var per = periodeMati_(x.tgl_mati);
  return (x.duplikasi === 'Ya' && !x.duplikat_dari && x.tb === 'Ya' && x.hiv === 'Ya' && x.mati === 'Ya' && (per === 'Utama' || per === 'Perluasan 2024')) ? 'Ya' : 'Tidak';
}
function periodeMati_(v) {
  var d = toDate_(v); if (!d) return '';
  if (d >= new Date(Date.UTC(2025, 0, 1)) && d <= new Date(Date.UTC(2026, 5, 30))) return 'Utama';
  if (d >= new Date(Date.UTC(2024, 0, 1)) && d < new Date(Date.UTC(2025, 0, 1))) return 'Perluasan 2024';
  return 'Di luar periode';
}
function calonList_() {
  var sel = null;
  return tbl_('C2', 'Calon_C6').rows.map(function (x) {
    var o = strip_(x); o.periode = periodeMati_(o.tgl_mati); o.eligible = calonEligible_(o);
    if (!o.kode_unit_c3 && o.ref_c2) {
      if (!sel) { sel = {}; c2SelectedAll_().forEach(function (s) { sel[s.kode_unit] = 1; }); }
      if (sel[o.ref_c2]) o.kode_unit_c3 = o.ref_c2;
    }
    return o;
  });
}
function nextCalonCode_(kk, C) {
  var n = C.rows.filter(function (x) { return x.kk === kk; }).length + 1; return (kk || 'XX') + '-K' + ('0' + n).slice(-2);
}
function nextCaseCode_(kk, C) {
  var used = {}; C.rows.forEach(function (x) { if (x.kode_kasus) used[x.kode_kasus] = 1; });
  for (var i = 1; i < 100; i++) { var c = 'C6-' + kk + '-' + ('0' + i).slice(-2); if (!used[c]) return c; }
  throw err_('Kode kasus habis');
}
/** Penentuan penilaian kedua: wajib bila peluang perbaikan = Ya; acak ≥30% dari kasus lain yang dokumennya memadai (angka acak tetap). */
function c6SecondReview_() {
  var A = {}, B = {};
  recTbl_('C6', 'C6A').rows.forEach(function (r) { A[r.unit] = recData_(r); });
  recTbl_('C6', 'C6B').rows.forEach(function (r) { B[r.unit] = recData_(r); });
  var cases = calonList_().filter(function (x) { return x.dipilih === 'Ya' && x.kode_kasus; })
    .sort(function (a, b) { return a.kode_kasus.localeCompare(b.kode_kasus); });
  var rnd = {}; cases.forEach(function (c, i) { rnd[c.kode_kasus] = SEED.c6_rand[i % SEED.c6_rand.length]; });
  var others = cases.filter(function (c) { var a = A[c.kode_kasus] || {}, b = B[c.kode_kasus] || {};
    return a.kecukupan === 'Memadai' && b.peluang && b.peluang !== 'Ya'; })
    .sort(function (x, y) { return rnd[x.kode_kasus] - rnd[y.kode_kasus]; });
  var take = Math.ceil(Number(SEED.c6_params['Proporsi sampel acak penilaian kedua'] || 0.3) * others.length);
  var out = {};
  cases.forEach(function (c) {
    var a = A[c.kode_kasus] || {}, b = B[c.kode_kasus] || {};
    if (a.kecukupan && a.kecukupan !== 'Memadai') out[c.kode_kasus] = 'Tidak (dokumen tidak memadai)';
    else if (b.peluang === 'Ya') out[c.kode_kasus] = 'Wajib (peluang perbaikan)';
    else if (!b.peluang) out[c.kode_kasus] = 'Tunggu penilaian pertama';
    else out[c.kode_kasus] = others.slice(0, take).some(function (o) { return o.kode_kasus === c.kode_kasus; }) ? 'Ya (sampel acak)' : 'Tidak';
  });
  return out;
}

/* ============================================================ AUTH & USERS */
function auth_(token) {
  if (!token) throw err_('Sesi tidak ada. Silakan masuk.', 'AUTH');
  var h = hash_(token, 'sess');
  var cache = CacheService.getScriptCache();
  var em = cache.get('t_' + h);
  if (!em) {
    var S = tbl_('MASTER', 'Sessions'); var s = S.find('token', h);
    if (!s || new Date(s.expires) < new Date()) throw err_('Sesi berakhir. Silakan masuk kembali.', 'AUTH');
    em = s.email; cache.put('t_' + h, em, 600);
    S.update(s, { last_seen: now_() });
  }
  var u = tbl_('MASTER', 'Users').find('email', em);
  if (!u || u.status !== 'Aktif') throw err_('Akun tidak aktif', 'AUTH');
  return { email: u.email, name: u.name, code: u.code, role: u.role, institution: u.institution };
}
function publicUser_(u) {
  return { email: u.email, name: u.name, code: u.code, role: u.role, role_req: u.role_req, status: u.status, institution: u.institution,
           phone: u.phone, created: u.created, approved_by: u.approved_by, last_login: u.last_login };
}
function userDirectory_(me) {
  return tbl_('MASTER', 'Users').rows.filter(function (u) { return u.status === 'Aktif'; })
    .map(function (u) { return { email: me.role === 'Pembaca' ? '' : u.email, name: u.name, code: u.code, role: u.role }; });
}
function killSessions_(email) {
  var S = tbl_('MASTER', 'Sessions'); S.removeMany(S.rows.filter(function (s) { return s.email === email; }));
}
function pruneSessions_(S) {
  var old = S.rows.filter(function (s) { return new Date(s.expires) < new Date(); });
  if (old.length) S.removeMany(old);
}
function notify_(to, from, form, sub, unit, msg) {
  if (!to) return;
  tbl_('MASTER', 'Notif').append({ id: Utilities.getUuid().slice(0, 8), to: to, from: from.email || '', from_name: from.name || '', created: now_(), form: form, sub: sub, unit: unit, msg: clean_(msg, 1000), read: '' });
}
function notifyCoords_(from, form, sub, unit, msg) {
  tbl_('MASTER', 'Users').rows.filter(function (u) { return u.status === 'Aktif' && u.role === 'Koordinator' && u.email !== from.email; })
    .forEach(function (u) { notify_(u.email, from, form, sub, unit, msg); });
}
function notifyAdmins_(msg) {
  tbl_('MASTER', 'Users').rows.filter(function (u) { return u.role === 'SuperAdmin'; }).forEach(function (u) { notify_(u.email, { email: 'sistem', name: 'Sistem' }, '', '', '', msg); });
}
function myNotif_(email) {
  return tbl_('MASTER', 'Notif').rows.filter(function (n) { return n.to === email && n.read !== 'Ya'; }).slice(-50).map(strip_);
}

/* ============================================================ LOCKS */
function key_(form, sub, unit) { return form + '|' + sub + '|' + unit; }
function expired_(l) {
  var t = new Date(l.last_act || l.since).getTime();
  return (Date.now() - t) > APP.LOCK_MIN * 60000;
}
function lockOut_(l) { return { email: l.email, name: l.name, since: l.since, last_beat: l.last_beat, last_act: l.last_act }; }
function lockInfo_(k) { var l = tbl_('MASTER', 'Locks').find('key', k); return l && !expired_(l) ? lockOut_(l) : null; }
function releaseAllLocks_(email) { var L = tbl_('MASTER', 'Locks'); L.removeMany(L.rows.filter(function (l) { return l.email === email; })); }

/* ============================================================ REGIONS */
var _regions = null;
function regions_() {
  if (_regions) return _regions;
  _regions = { prov: tbl_('MASTER', 'Provinsi').rows.map(strip_), kk: tbl_('MASTER', 'KabKota').rows.map(strip_), fac: tbl_('MASTER', 'Faskes').rows.map(strip_) };
  _regions.fac.forEach(function (f) { f.slot = Number(f.slot); });
  return _regions;
}
function facByCode_(c) { return regions_().fac.filter(function (f) { return f.code === c; })[0]; }
function kkByCode_(c) { return regions_().kk.filter(function (k) { return k.code === c; })[0] || {}; }

/* ============================================================ SHEET TABLE HELPER */
var _ss = {}, _tbl = {};
function prop_(k) { return PropertiesService.getScriptProperties().getProperty(k); }
function ss_(name) {
  if (_ss[name]) return _ss[name];
  var id = prop_('SS_' + name); if (!id) throw err_('Server belum disiapkan. Jalankan setup() di editor Apps Script.');
  return (_ss[name] = SpreadsheetApp.openById(id));
}
function tbl_(ssName, sheetName, headers) {
  var key = ssName + '/' + sheetName;
  if (_tbl[key]) return _tbl[key];
  var ss = ss_(ssName);
  var sh = ss.getSheetByName(sheetName);
  if (!sh) {
    sh = ss.insertSheet(sheetName);
    if (headers) { sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold'); sh.setFrozenRows(1); }
  }
  return (_tbl[key] = new Table_(sh, headers));
}
function Table_(sh, headers) {
  this.sh = sh;
  var lastCol = Math.max(sh.getLastColumn(), 1), lastRow = sh.getLastRow();
  var vals = lastRow > 0 ? sh.getRange(1, 1, lastRow, lastCol).getValues() : [[]];
  var hs0 = (vals[0] || []).map(String);
  while (hs0.length && hs0[hs0.length - 1] === '') hs0.pop();
  this.headers = hs0;
  if (headers) this.ensureCols(headers);
  var hs = this.headers;
  var tz = sheetTz_(sh);
  this.rows = [];
  for (var i = 1; i < vals.length; i++) {
    var o = { _row: i + 1 }, empty = true;
    for (var j = 0; j < hs.length; j++) {
      var v = vals[i][j];
      if (v instanceof Date) v = dateCell_(v, tz);
      o[hs[j]] = v === null || v === undefined ? '' : v;
      if (v !== '' && v !== null) empty = false;
    }
    if (!empty) this.rows.push(o);
  }
}
Table_.prototype.ensureCols = function (cols) {
  var miss = cols.filter(function (c) { return this.headers.indexOf(c) < 0; }, this);
  if (!miss.length) return;
  var start = this.headers.length + 1;
  if (this.sh.getMaxColumns() < start + miss.length - 1) this.sh.insertColumnsAfter(this.sh.getMaxColumns(), start + miss.length - 1 - this.sh.getMaxColumns());
  this.sh.getRange(1, start, 1, miss.length).setValues([miss]).setFontWeight('bold');
  this.headers = this.headers.concat(miss);
};
Table_.prototype.find = function (k, v) {
  for (var i = 0; i < this.rows.length; i++) if (String(this.rows[i][k]) === String(v)) return this.rows[i];
  return null;
};
Table_.prototype._vals = function (o) {
  return this.headers.map(function (h) { return cell_(o[h]); });
};
Table_.prototype.append = function (o) {
  var keys = Object.keys(o).filter(function (k) { return k !== '_row'; });
  this.ensureCols(keys);
  var r = this.sh.getLastRow() + 1;
  var vals = this._vals(o);
  this.sh.getRange(r, 1, 1, vals.length).setValues([vals]);
  var obj = {}; this.headers.forEach(function (h) { obj[h] = o[h] === undefined ? '' : o[h]; }); obj._row = r;
  this.rows.push(obj); return obj;
};
Table_.prototype.update = function (row, upd) {
  var keys = Object.keys(upd);
  this.ensureCols(keys);
  keys.forEach(function (k) { row[k] = upd[k]; });
  var vals = this._vals(row);
  this.sh.getRange(row._row, 1, 1, vals.length).setValues([vals]);
  return row;
};
Table_.prototype.remove = function (row) { if (row) this.removeMany([row]); };
Table_.prototype.removeMany = function (rows) {
  var nums = rows.map(function (r) { return r._row; }).sort(function (a, b) { return b - a; });
  var sh = this.sh;
  nums.forEach(function (n) { sh.deleteRow(n); });
  var set = {}; nums.forEach(function (n) { set[n] = 1; });
  this.rows = this.rows.filter(function (r) { return !set[r._row]; });
  this.rows.forEach(function (r) { var shift = nums.filter(function (n) { return n < r._row; }).length; r._row -= shift; });
};
function cell_(v) {
  if (v === undefined || v === null) return '';
  if (typeof v === 'string' && /^[=+\-@]/.test(v)) return "'" + v;
  if (typeof v === 'string' && /^0\d+$/.test(v)) return "'" + v;   // pertahankan nol di depan (kode, nomor)
  if (typeof v === 'string' && /^(\d{4}-\d{1,2}-\d{1,2}|\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4})$/.test(v.trim())) return "'" + v.trim();   // tanggal disimpan sebagai teks agar tidak ditafsirkan ulang oleh Sheets
  if (typeof v === 'object') return JSON.stringify(v);
  return v;
}
function sheetTz_(sh) {
  try { return sh.getParent().getSpreadsheetTimeZone() || Session.getScriptTimeZone(); } catch (e) { return Session.getScriptTimeZone(); }
}
/** Tanggal dari sel Sheets → 'yyyy-MM-dd' menurut zona waktu spreadsheet (mencegah geser satu hari). */
function dateCell_(v, tz) {
  var hms = Utilities.formatDate(v, tz, 'HH:mm:ss');
  return hms === '00:00:00' ? Utilities.formatDate(v, tz, 'yyyy-MM-dd') : v.toISOString();
}
function strip_(o) { var x = {}; Object.keys(o).forEach(function (k) { if (k !== '_row') x[k] = o[k]; }); return x; }

/* ============================================================ UTIL */
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function err_(m, code) { var e = new Error(m); e.code = code || ''; return e; }
function now_() { return new Date().toISOString(); }
function normEmail_(e) { return String(e || '').trim().toLowerCase(); }
function clean_(s, n) { s = s === undefined || s === null ? '' : String(s); return s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, n || 500).trim(); }
function safeName_(s) { return String(s).replace(/[^A-Za-z0-9_.-]/g, '_'); }
function hash_(pin, salt) {
  var raw = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + ':' + pin + ':' + (prop_('PEPPER') || ''), Utilities.Charset.UTF_8);
  return raw.map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}
function md5_(s) { return Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, String(s))).slice(0, 10); }
function fmtTime_(iso) { try { return Utilities.formatDate(new Date(iso), 'Asia/Makassar', 'dd/MM HH:mm'); } catch (e) { return iso; } }
function audit_(email, action, target, detail) {
  try { tbl_('MASTER', 'Audit').append({ ts: now_(), email: email, action: action, target: target, detail: clean_(detail, 500) }); } catch (e) { }
}
function cfg_(k) { var r = tbl_('MASTER', 'Config').find('key', k); return r ? String(r.value) : ''; }
function cfgSet_(k, v) { var C = tbl_('MASTER', 'Config'); var r = C.find('key', k); if (r) C.update(r, { value: v }); else C.append({ key: k, value: v }); }
