/** Data awal (dihasilkan otomatis dari instrumen). Jangan diubah setelah undian C2 dimulai. */
var SEED = {
 "regions": {
  "prov": [
   {
    "code": "SUT",
    "name": "Sumatera Utara"
   },
   {
    "code": "DKI",
    "name": "DKI Jakarta"
   },
   {
    "code": "JBR",
    "name": "Jawa Barat"
   },
   {
    "code": "JTM",
    "name": "Jawa Timur"
   },
   {
    "code": "BAL",
    "name": "Bali"
   },
   {
    "code": "PPA",
    "name": "Papua"
   }
  ],
  "kk": [
   {
    "code": "DLS",
    "name": "Kabupaten Deli Serdang",
    "prov": "SUT",
    "capaian": "Rendah"
   },
   {
    "code": "MDN",
    "name": "Kota Medan",
    "prov": "SUT",
    "capaian": "Tinggi"
   },
   {
    "code": "JTI",
    "name": "Kota Jakarta Timur",
    "prov": "DKI",
    "capaian": "Rendah"
   },
   {
    "code": "JPS",
    "name": "Kota Jakarta Pusat",
    "prov": "DKI",
    "capaian": "Tinggi"
   },
   {
    "code": "IDM",
    "name": "Kabupaten Indramayu",
    "prov": "JBR",
    "capaian": "Rendah"
   },
   {
    "code": "BGR",
    "name": "Kabupaten Bogor",
    "prov": "JBR",
    "capaian": "Tinggi"
   },
   {
    "code": "SDA",
    "name": "Kabupaten Sidoarjo",
    "prov": "JTM",
    "capaian": "Rendah"
   },
   {
    "code": "SBY",
    "name": "Kota Surabaya",
    "prov": "JTM",
    "capaian": "Tinggi"
   },
   {
    "code": "BLL",
    "name": "Kabupaten Buleleng",
    "prov": "BAL",
    "capaian": "Rendah"
   },
   {
    "code": "BDG",
    "name": "Kabupaten Badung",
    "prov": "BAL",
    "capaian": "Tinggi"
   },
   {
    "code": "KJP",
    "name": "Kota Jayapura",
    "prov": "PPA",
    "capaian": "Rendah"
   },
   {
    "code": "KBJ",
    "name": "Kabupaten Jayapura",
    "prov": "PPA",
    "capaian": "Tinggi"
   }
  ],
  "fac": [
   {
    "code": "DLS-RS",
    "name": "",
    "kk": "DLS",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "DLS-PKM",
    "name": "",
    "kk": "DLS",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "MDN-RS",
    "name": "",
    "kk": "MDN",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "MDN-PKM",
    "name": "",
    "kk": "MDN",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "JTI-RS",
    "name": "",
    "kk": "JTI",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "JTI-PKM",
    "name": "",
    "kk": "JTI",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "JPS-RS",
    "name": "",
    "kk": "JPS",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "JPS-PKM",
    "name": "",
    "kk": "JPS",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "IDM-RS",
    "name": "",
    "kk": "IDM",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "IDM-PKM",
    "name": "",
    "kk": "IDM",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "BGR-RS",
    "name": "",
    "kk": "BGR",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "BGR-PKM",
    "name": "",
    "kk": "BGR",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "SDA-RS",
    "name": "",
    "kk": "SDA",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "SDA-PKM",
    "name": "",
    "kk": "SDA",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "SBY-RS",
    "name": "",
    "kk": "SBY",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "SBY-PKM",
    "name": "",
    "kk": "SBY",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "BLL-RS",
    "name": "",
    "kk": "BLL",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "BLL-PKM",
    "name": "",
    "kk": "BLL",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "BDG-RS",
    "name": "",
    "kk": "BDG",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "BDG-PKM",
    "name": "",
    "kk": "BDG",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "KJP-RS",
    "name": "",
    "kk": "KJP",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "KJP-PKM",
    "name": "",
    "kk": "KJP",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   },
   {
    "code": "KBJ-RS",
    "name": "",
    "kk": "KBJ",
    "type": "RS",
    "slot": 1,
    "sentinel": false
   },
   {
    "code": "KBJ-PKM",
    "name": "",
    "kk": "KBJ",
    "type": "Puskesmas",
    "slot": 2,
    "sentinel": false
   }
  ]
 },
 "angka_acak": {
  "DLS|1|A": 0.6106,
  "DLS|1|B": 0.4125,
  "DLS|1|CP3": 0.8918,
  "DLS|2|A": 0.6521,
  "DLS|2|B": 0.6114,
  "DLS|2|CP3": 0.7561,
  "MDN|1|A": 0.4228,
  "MDN|1|B": 0.994,
  "MDN|1|CP3": 0.1392,
  "MDN|2|A": 0.1112,
  "MDN|2|B": 0.9401,
  "MDN|2|CP3": 0.1548,
  "JTI|1|A": 0.479,
  "JTI|1|B": 0.8545,
  "JTI|1|CP3": 0.703,
  "JTI|2|A": 0.2066,
  "JTI|2|B": 0.967,
  "JTI|2|CP3": 0.4706,
  "JPS|1|A": 0.6138,
  "JPS|1|B": 0.3687,
  "JPS|1|CP3": 0.5621,
  "JPS|2|A": 0.7149,
  "JPS|2|B": 0.2478,
  "JPS|2|CP3": 0.6036,
  "IDM|1|A": 0.8025,
  "IDM|1|B": 0.2811,
  "IDM|1|CP3": 0.7485,
  "IDM|2|A": 0.4555,
  "IDM|2|B": 0.9878,
  "IDM|2|CP3": 0.8409,
  "BGR|1|A": 0.0974,
  "BGR|1|B": 0.9353,
  "BGR|1|CP3": 0.0441,
  "BGR|2|A": 0.0497,
  "BGR|2|B": 0.3209,
  "BGR|2|CP3": 0.9928,
  "SDA|1|A": 0.2717,
  "SDA|1|B": 0.1206,
  "SDA|1|CP3": 0.7045,
  "SDA|2|A": 0.8028,
  "SDA|2|B": 0.0802,
  "SDA|2|CP3": 0.1721,
  "SBY|1|A": 0.2382,
  "SBY|1|B": 0.0406,
  "SBY|1|CP3": 0.6485,
  "SBY|2|A": 0.303,
  "SBY|2|B": 0.5293,
  "SBY|2|CP3": 0.2651,
  "BLL|1|A": 0.61,
  "BLL|1|B": 0.3599,
  "BLL|1|CP3": 0.4997,
  "BLL|2|A": 0.8261,
  "BLL|2|B": 0.5966,
  "BLL|2|CP3": 0.8064,
  "BDG|1|A": 0.4912,
  "BDG|1|B": 0.7985,
  "BDG|1|CP3": 0.0675,
  "BDG|2|A": 0.1833,
  "BDG|2|B": 0.2545,
  "BDG|2|CP3": 0.4962,
  "KJP|1|A": 0.3701,
  "KJP|1|B": 0.777,
  "KJP|1|CP3": 0.7463,
  "KJP|2|A": 0.3861,
  "KJP|2|B": 0.9776,
  "KJP|2|CP3": 0.4605,
  "KBJ|1|A": 0.3328,
  "KBJ|1|B": 0.8616,
  "KBJ|1|CP3": 0.5992,
  "KBJ|2|A": 0.8453,
  "KBJ|2|B": 0.1123,
  "KBJ|2|CP3": 0.9063
 },
 "c7_sessions": [
  {
   "code": "SUT-W1",
   "kk": "DLS",
   "target": "Pengelola program HIV Dinkes Kab. Deli Serdang"
  },
  {
   "code": "SUT-W2",
   "kk": "MDN",
   "target": "Pengelola program HIV Dinkes Kota Medan"
  },
  {
   "code": "SUT-W3",
   "kk": "DLS",
   "target": "DPJP atau penanggung jawab PDP RS Haji Medan"
  },
  {
   "code": "SUT-W4",
   "kk": "DLS",
   "target": "Pasien atau mantan pasien TB-HIV Deli Serdang (terlambat ARV, berobat lintas Medan, atau dirujuk untuk pemeriksaan TB)"
  },
  {
   "code": "SUT-W5",
   "kk": "MDN",
   "target": "Pendamping komunitas yang mendampingi pasien di Kota Medan dan Deli Serdang"
  },
  {
   "code": "SUT-F1",
   "kk": "Keduanya",
   "target": "Diskusi petugas pelaksana dari 4 fasyankes sampel (6–8 orang)"
  },
  {
   "code": "SUT-F2",
   "kk": "Keduanya",
   "target": "Diskusi komunitas (6–8 orang): ODHIV dengan riwayat TB atau penerima TPT; komposisi akhir menurut adendum"
  },
  {
   "code": "DKI-W1",
   "kk": "JTI",
   "target": "Pengelola program Suku Dinas Kesehatan Jakarta Timur"
  },
  {
   "code": "DKI-W2",
   "kk": "JPS",
   "target": "Pengelola program Suku Dinas Kesehatan Jakarta Pusat"
  },
  {
   "code": "DKI-W3",
   "kk": "JTI",
   "target": "DPJP atau penanggung jawab PDP RS Hermina Jatinegara; alternatif: Petugas klinik Lapas/Rutan Cipinang atau Rutan Pondok Bambu"
  },
  {
   "code": "DKI-W4",
   "kk": "JTI",
   "target": "Pasien atau mantan pasien Jakarta Timur (ditawari TPT, berhenti, atau terlambat ARV)"
  },
  {
   "code": "DKI-W5",
   "kk": "JPS",
   "target": "Pendamping atau petugas klinik komunitas populasi kunci di Jakarta Pusat"
  },
  {
   "code": "DKI-F1",
   "kk": "Keduanya",
   "target": "Diskusi petugas pelaksana dari 4 fasyankes sampel (6–8 orang)"
  },
  {
   "code": "DKI-F2",
   "kk": "Keduanya",
   "target": "Diskusi komunitas (6–8 orang): ODHIV populasi kunci yang ditawari atau menjalani TPT; komposisi akhir menurut adendum"
  },
  {
   "code": "JBR-W1",
   "kk": "IDM",
   "target": "Pengelola program HIV Dinkes Kab. Indramayu"
  },
  {
   "code": "JBR-W2",
   "kk": "BGR",
   "target": "Pengelola program TB atau HIV Dinkes Kab. Bogor"
  },
  {
   "code": "JBR-W3",
   "kk": "IDM",
   "target": "DPJP atau penanggung jawab TB RSUD M.A. Sentot Patrol"
  },
  {
   "code": "JBR-W4",
   "kk": "IDM",
   "target": "Pasien atau mantan pasien TB-HIV Indramayu (tes HIV, perjalanan ke layanan PDP, tidak mulai obat)"
  },
  {
   "code": "JBR-W5",
   "kk": "BGR",
   "target": "Penanggung jawab layanan PDP RSUD Cibinong (simpul jejaring PDP)"
  },
  {
   "code": "JBR-F1",
   "kk": "BGR",
   "target": "Diskusi petugas pelaksana dari 2 fasyankes sampel di kab/kota ini (6–8 orang)"
  },
  {
   "code": "JBR-F2",
   "kk": "IDM",
   "target": "Diskusi komunitas (6–8 orang): ODHIV dengan riwayat TB; komposisi akhir menurut adendum"
  },
  {
   "code": "JTM-W1",
   "kk": "SDA",
   "target": "Pengelola program HIV Dinkes Kab. Sidoarjo"
  },
  {
   "code": "JTM-W2",
   "kk": "SBY",
   "target": "Pengelola program HIV atau TB Dinkes Kota Surabaya"
  },
  {
   "code": "JTM-W3",
   "kk": "SDA",
   "target": "Penanggung jawab layanan TB-HIV RS Siti Khodijah Sepanjang; alternatif: Petugas klinik Rutan Medaeng atau Lapas Porong (bila alur rujukan RS sudah cukup tergali melalui C4)"
  },
  {
   "code": "JTM-W4",
   "kk": "SDA",
   "target": "Pasien atau mantan pasien TB-HIV Sidoarjo yang pernah dirujuk untuk ARV"
  },
  {
   "code": "JTM-W5",
   "kk": "SBY",
   "target": "Pendamping komunitas (misalnya PKBI Jawa Timur) yang mendampingi ODHIV di Surabaya dan Sidoarjo"
  },
  {
   "code": "JTM-F1",
   "kk": "Keduanya",
   "target": "Diskusi petugas pelaksana dari 4 fasyankes sampel (6–8 orang)"
  },
  {
   "code": "JTM-F2",
   "kk": "Keduanya",
   "target": "Diskusi komunitas (6–8 orang): ODHIV dengan riwayat TB atau populasi kunci yang ditawari TPT; komposisi akhir menurut adendum"
  },
  {
   "code": "BAL-W1",
   "kk": "BLL",
   "target": "Pengelola program HIV atau TB Dinkes Kab. Buleleng"
  },
  {
   "code": "BAL-W2",
   "kk": "BDG",
   "target": "Pengelola program Dinkes Kab. Badung"
  },
  {
   "code": "BAL-W3",
   "kk": "BLL",
   "target": "DPJP layanan TB-HIV RSUD Buleleng"
  },
  {
   "code": "BAL-W4",
   "kk": "BLL",
   "target": "Pasien atau mantan pasien TB-HIV Buleleng (terlambat ARV atau pernah putus)"
  },
  {
   "code": "BAL-W5",
   "kk": "BDG",
   "target": "Pendamping komunitas di Badung (pekerja pariwisata, pendatang, populasi kunci)"
  },
  {
   "code": "BAL-F1",
   "kk": "BDG",
   "target": "Diskusi petugas pelaksana dari 2 fasyankes sampel di kab/kota ini (6–8 orang)"
  },
  {
   "code": "BAL-F2",
   "kk": "BLL",
   "target": "Diskusi komunitas (6–8 orang): ODHIV dengan riwayat TB; komposisi akhir menurut adendum"
  },
  {
   "code": "PPA-W1",
   "kk": "KJP",
   "target": "Pengelola program HIV Dinkes Kota Jayapura"
  },
  {
   "code": "PPA-W2",
   "kk": "KBJ",
   "target": "Pengelola program TB atau HIV Dinkes Kab. Jayapura"
  },
  {
   "code": "PPA-W3",
   "kk": "KJP",
   "target": "Pengelola program atau farmasi Dinkes Provinsi Papua (logistik dan pasien lintas kabupaten)"
  },
  {
   "code": "PPA-W4",
   "kk": "KJP",
   "target": "Pasien atau mantan pasien TB-HIV Kota Jayapura (berpindah layanan, putus obat)"
  },
  {
   "code": "PPA-W5",
   "kk": "KBJ",
   "target": "Pendamping komunitas atau kader yang menjangkau kampung di Kab. Jayapura"
  },
  {
   "code": "PPA-F1",
   "kk": "Keduanya",
   "target": "Diskusi petugas pelaksana dari 4 fasyankes sampel (6–8 orang)"
  },
  {
   "code": "PPA-F2",
   "kk": "Keduanya",
   "target": "Diskusi komunitas (6–8 orang): ODHIV dengan riwayat TB; komposisi akhir menurut adendum"
  },
  {
   "code": "NAS-W1",
   "kk": "Nasional",
   "target": "Program TB (Timker TB)"
  },
  {
   "code": "NAS-W2",
   "kk": "Nasional",
   "target": "Program HIV (Timker HIV AIDS dan PIMS)"
  },
  {
   "code": "NAS-W3",
   "kk": "Nasional",
   "target": "Pengelola SITB"
  },
  {
   "code": "NAS-W4",
   "kk": "Nasional",
   "target": "Pengelola SIHA"
  },
  {
   "code": "NAS-W5",
   "kk": "Nasional",
   "target": "Perwakilan komunitas TB"
  },
  {
   "code": "NAS-W6",
   "kk": "Nasional",
   "target": "Perwakilan komunitas HIV atau pelaksana hibah"
  }
 ],
 "c6_rand": [
  0.3592,
  0.2352,
  0.6819,
  0.1097,
  0.7722,
  0.3838,
  0.272,
  0.0814,
  0.0907,
  0.4676,
  0.1817,
  0.1791,
  0.8188,
  0.0979,
  0.631,
  0.8727,
  0.3264,
  0.404,
  0.7015,
  0.984,
  0.1366,
  0.8047,
  0.3075,
  0.4902,
  0.2866,
  0.5469,
  0.5007,
  0.3596,
  0.4614,
  0.503,
  0.9569,
  0.6418,
  0.0535,
  0.4555,
  0.5418,
  0.0597,
  0.69,
  0.9305,
  0.5818,
  0.5978,
  0.4607,
  0.2828,
  0.0761,
  0.0785,
  0.5057,
  0.5188,
  0.2187,
  0.7185,
  0.3656,
  0.7715,
  0.0107,
  0.2516,
  0.1169,
  0.3609,
  0.6026,
  0.809,
  0.9325,
  0.1942,
  0.4501,
  0.1449,
  0.2801,
  0.7952,
  0.0459,
  0.8511,
  0.195,
  0.9886,
  0.3367,
  0.293,
  0.6075,
  0.7849
 ],
 "c6_params": {},
 "c3_params": {}
};
